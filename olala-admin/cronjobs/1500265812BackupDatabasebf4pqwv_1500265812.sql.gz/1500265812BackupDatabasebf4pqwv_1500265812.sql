-- [MySQL -  Database Backup] Created time: 17/07/2017 - 11:30:12

-- Host: localhost
-- Server version: 5.6.20
-- Collation: utf8_general_ci
-- Time zone: SE Asia Standard Time

-- Database: dnw_vstartup


CREATE TABLE `olala3w_article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT '0',
  `block` int(11) NOT NULL DEFAULT '0',
  `flat` int(11) NOT NULL DEFAULT '0',
  `open_sale` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `upload_id` bigint(20) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=950 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_article VALUES('922','455','Startup giá trị nhất Đông Nam Á chuẩn bị IPO tỷ USD','startup-gia-tri-nhat-dong-nam-a-chuan-bi-ipo-ty-usd','','','','startup-gia-tri-nhat-dong-nam-a-chuan-bi-ipo-ty-usd-1496816185.jpg','','','0','0','0','0','0','1872','Sea - hãng công nghệ với tên trước đây là Garena - có khả năng huy động được 1 tỷ USD sau khi IPO.','<p>Theo một nguồn tin thân cận,&nbsp;Sea đã nộp đơn xin IPO lên Uỷ ban Chứng khoán Mỹ (SEC). Hãng công nghệ này đang cân nhắc niêm yết vào đầu năm sau.</p>\r\n\r\n<p>Hiện tại, Sea đang hợp tác với 2 ngân hàng Goldman Sachs và Morgan Stanley để bàn về việc bán cổ phiếu. Theo một đạo luật của Mỹ, các doanh nghiệp có doanh thu dưới 1 tỷ USD một năm có thể tự nộp đơn IPO lên SEC và không cần công bố thông tin chi tiết ra bên ngoài.</p>\r\n\r\n<p>Sea dự kiến huy động được 1 tỷ USD đợt này. Đồng thời, đây có thể là thương vụ IPO công nghệ lớn nhất khu vực Đông Nam Á và cũng là cơ hội cho các cổ đông như Tencent.</p>\r\n\r\n<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align: center;\"><img alt=\"startup-gia-tri-nhat-dong-nam-a-chun-bi-ipo-ty-usd\" data-natural-width=\"500\" data-pwidth=\"660\" data-width=\"500\" src=\"http://img.f25.kinhdoanh.vnecdn.net/2017/05/24/Forrest-Li-5124-1495629209.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Forrest Li thành lập Garena từ năm 2009 trước khi doanh nghiệp này&nbsp;đổi tên thành Sea hồi đầu tháng này.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Đầu tháng này, Sea đã nhận được thêm 550 triệu USD trong vòng huy động vốn để cạnh tranh với gã khổng lồ Alibaba tại Indonesia. Các nhà đầu tư của Sea là các công ty giàu nhất trong khu vực như&nbsp;GDP Venture&nbsp;hay JG Summit Holdings.&nbsp;GDP Venture&nbsp;được điều hành bởi con trai ông trùm Indonesia - Budi Hartono, còn JG Summit được tỷ phú người Philippines - John Gokongwei sáng lập.</p>\r\n\r\n<p>Năm 2009, doanh nhân Forrest Li thành lập công ty này (tiền thân là Garena) với mục đích kinh doanh trò chơi trực tuyến. Sau đó, Sea đã phát triển sang lĩnh vực mua sắm trên di dộng và các dịch vụ thanh toán.</p>\r\n\r\n<p>Việc Sea niêm yết tại nước ngoài có thể là một đòn đánh mạnh vào tham vọng của Singapore. Quốc gia này đang rất muốn các hãng khởi nghiệp niêm yết tại thị trường trong nước để tạo thành một trung tâm cho các doanh nghiệp phát triển nhanh và sáng tạo. Hiện tại, sàn chứng khoán Singapore gần đạt được thoả thuận với các nhà quản lý để phát triển một hệ thống để kết nối các startup với các nhà đầu tư nhằm khuyến khích họ IPO tại đây.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Anh Tú</strong><br />\r\n<em>(Theo Bloomberg)</em></p>\r\n','1','0','1','1496816040','1496912947','1');
INSERT INTO olala3w_article VALUES('920','455','Những điểm đến khơi gợi ý tưởng kinh doanh cho startup','nhung-diem-den-khoi-goi-y-tuong-kinh-doanh-cho-startup','','','','nhung-diem-den-khoi-goi-y-tuong-kinh-doanh-cho-startup-1496815975.jpg','','','0','0','0','0','0','1870','Từng góc đường, con phố ở London, Singapore, Bắc Kinh hay dạo bộ trên biển, đến một nơi thật yên tĩnh... có thể mang lại cho bạn cảm hứng mới.','<p>“Tôi yêu thích công việc mình đang làm. Nhưng có những khoảnh khắc tôi cảm thấy mỏi mệt và buồn bã. Đó là lúc tôi biết mình nên dừng lại một chút và thừa nhận rằng có lẽ cần phải xả hơi”, Kara Pangilinan, nghệ sĩ kiêm nhà sáng lập thương hiệu nghệ thuật DetailsInk, Philippines chia sẻ.&nbsp;</p>\r\n\r\n<p>Với Neal Moore, nhà sáng lập và giám đốc nội dung của Click2View, một công ty marketing tại Singapore, thành phần cơ bản trong không gian sáng tạo là sự tương phản. “Nó có thể nằm trong con người, thời tiết, trang trí hoặc bất cứ thứ gì”, anh nói. Trong khi đó,&nbsp;Pangilinan cho biết chỉ cần một nơi tĩnh tâm để lắng nghe những suy nghĩ của chính mình và tập hít thở tốt hơn.&nbsp;</p>\r\n\r\n<p>Dưới đây là một vài điểm dừng chân mà các nhà sáng lập có thể thử nghĩ đến, theo&nbsp;Inc.</p>\r\n\r\n<p>London</p>\r\n\r\n<p>Đây là một trong những tâm điểm của thế giới về cả nghệ thuật, văn hóa lẫn tài chính. “London là thành phố hiện đại với 2.000 năm di sản, nơi có những toàn nhà lấp lánh cùng công trình kiến trúc cổ đại có tuổi đời hàng nghìn năm. Nơi đó đổi thay với thời tiết và thời tiết thì thay đổi mỗi ngày”, Moore nhận xét.&nbsp;</p>\r\n\r\n<p>Một số nơi được yêu thích như Bảo tàng quốc gia, Học viện hoàng gia và Học viện điện ảnh Anh. Những điểm đến không chỉ dành cho các cuộc triển lãm mà còn thu hút bởi môi trường sống. “Ngay cả những con phố cũng có thể trở thành nguồn cảm hứng cho bạn”, Moore nói thêm.&nbsp;</p>\r\n\r\n<p><strong>Singapore</strong></p>\r\n\r\n<p>Singapore chính là trung tâm của Đông Nam Á. “Nơi đây rất trẻ trung và mang chất ngạo mạn của tuổi trẻ, rất có thể sẽ giúp bạn tạo ra những điều mới mẻ. Thỉnh thoảng ở London bạn sẽ có cảm giác mọi thứ đều đã hoàn thiện nhưng tại đảo quốc sử tử thì tất cả mang đến cảm giác vẫn còn gì đó để tiếp tục thực hiện”, Moore chia sẻ.&nbsp;</p>\r\n\r\n<p>Roslyn Teng, nhà đồng sáng lập dịch vụ phong cách sống cho người Singapore mang tên Made Real kiếm tìm những không gian mở tại đây để nạp lại năng lượng. “Ý tưởng của Made Real xuất hiện khi chúng tôi ăn một bữa ngẫu hứng tại Living Cafe. Đó là một không gian tuyệt vời cho những cuộc thảo luận hay gặp gỡ trong ngày và trở thành điểm đến ấm cúng khi màn đêm buông xuống”, anh diễn giải.&nbsp;</p>\r\n\r\n<p>Teng cũng gợi ý đến thăm hòn đảo Sentosa và Tanjong Beach Club nổi tiếng ở đây. “Tôi đã có những cuộc trò chuyện rất thú vị về việc kinh doanh, các sản phẩm, tham vọng của bản thân và nguồn cảm hứng khi đi dạo dọc bờ biển xinh đẹp cùng những con người ngẫu hứng”.</p>\r\n\r\n<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align: center;\"><img alt=\"nhung-diem-den-khoi-goi-y-tuong-kinh-doanh-cho-startup\" data-natural-width=\"500\" data-pwidth=\"660\" data-width=\"500\" src=\"https://i-startup.vnecdn.net/2017/06/06/recharge-5906-1496712683.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>Nạp lại năng lượng là điều cần thiết đối với bất cứ nhà khởi nghiêp nào, bởi đó là một chặng đường dài đầy chông gai.&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>Bắc Kinh</strong></p>\r\n\r\n<p>Thủ đô này có các công trình kiến trúc nổi tiếng. Với những người lần đầu đến đây, khó có thể tượng tưởng giữa thành phố hiện đại và sầm uất lại có thể tồn tại không gian nghệ thuật mang tên 798 Art Zone.&nbsp;</p>\r\n\r\n<p>“Nơi này tạo cho tôi cảm giác tĩnh tâm và tập hợp các suy nghĩ, điều mà đôi lúc tôi không thể làm được khi ngồi trong văn phòng làm việc”, Yeoh Chen Chow, đồng sáng lập Fave, cho biết.</p>\r\n\r\n<p><strong>Hơn cả một điểm đến</strong></p>\r\n\r\n<p>Với Pangilinan, bất cứ nơi nào cách xa thành phố, đặc biệt là biển, sẽ là một lựa chọn hợp lý cho một chuyến xả hơi cần thiết. Cô nói không có một nơi đặc biệt khiến cô quay lại nhưng chuyến đi mỗi giữa năm luôn mang đến một nguồn năng lượng mới.</p>\r\n\r\n<p>“Còn nếu không thể rời khỏi Manila, tôi sẽ ‘hẹn hò’ với chính mình tại một nhà hàng yên tĩnh. Đó là khi bật chế độ cuộc sống, chuyển điện thoại sang chế độ máy bay, đắm mình trong các kế hoạch và biến mất trong một khoảnh khắc”, nhà sáng lập&nbsp;DetailsInk cho biết.&nbsp;</p>\r\n\r\n<p>Thăm thú các điểm đến mới có thể tạo ra những ý tưởng sáng tạo và thời gian nghỉ ngơi. Tuy nhiên, đôi khi cũng không đồng nghĩa phải đến một nơi thật đặc biệt, đó có thể là bất cứ đâu.&nbsp;</p>\r\n\r\n<p>Theo Philip Cheang, đồng sáng lập công ty thiết kế và phát triển phần mềm By Implication tại Philippines, việc chuyển động, đặc biệt là đi bộ, mang đến những sáng tạo trong suy nghĩ. \"Tôi thường ghi lại những sản phẩm, hành vi và thiết kế thú vị khi du lịch. Có lẽ đó cũng là lý do khiến tôi yêu thích việc đi bộ bởi nó mở ra cho bạn những hành trình khám phá rất ngẫu hứng”.&nbsp;</p>\r\n\r\n<p>CEO giải thích thêm là mỗi lần đi nước ngoài và du lịch, anh luôn tìm thấy cảm hứng một cách bất ngờ.&nbsp;Cheang&nbsp;thường chụp lại và ghi chép để tạo thành một album sống động của các bức ảnh về tàu hỏa, xe buýt, bảng hiệu, ảnh chụp màn hình của các ứng dụng, bản đồ và con đường.&nbsp;</p>\r\n\r\n<p>Với một số người, việc sạc năng lượng có thể chỉ đơn giản là thay đổi suy nghĩ theo hướng rộng mở và nắm bắt mọi nhịp điệu thay đổi của thế giới. Chỉ cần ra khỏi văn phòng, ít nhất là thoát khỏi những bức tường đã trói buộc suy nghĩ của bạn.</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Nhi Yến</strong><br />\r\n<em>(Theo V</em>nexpress.net<em>)</em></p>\r\n','1','0','32','1496803200','1496815975','1');
INSERT INTO olala3w_article VALUES('940','455','Startup Việt nhận 1 triệu USD từ quỹ đầu tư của Singapore','startup-viet-nhan-1-trieu-usd-tu-quy-dau-tu-cua-singapore','','','','startup-viet-nhan-1-trieu-usd-tu-quy-dau-tu-cua-singapore-1496913509.jpg','','','0','0','0','0','0','1899','Một startup Việt họat động trong lĩnh vực kinh doanh thực phẩm sạch vừa nhận 1 triệu USD từ quỹ đầu tư Singapore','<p>Công ty cổ phần phát triển Việt Nam toàn cầu (VNI) vừa tiếp nhận một triệu USD vốn đầu tư từ Công ty World Gold Investments PTE. LTD (World Gold) - một quỹ một quỹ đầu tư tài chính từ Singapore. World Gold Investments cho biết cam kết đầu tư vào VNI để cùng phát triển các hoạt động kinh doanh của VNI, đặc biệt là các dự án kinh doanh tiêu dùng, thực phẩm sạch, nhà hàng…&nbsp;</p>\r\n\r\n<p>World Gold cũng cam kết sẽ đầu tư thêm nguồn vốn theo từng giai đoạn phát triển của các dự án kinh doanh của VNI trong các năm tới tại Việt Nam và các quốc gia khác. Dự kiến tổng vốn đầu tư của quỹ đầu tư Singapore cho VNI sẽ lên tới 15 triệu USD trong giai đoạn 2017-2019 nếu các mô hình của đơn vị này hoạt động hiệu quả</p>\r\n\r\n<p>VNI là một doanh nghiệp khởi nghiệp, được thành lập tháng 10/2016, hoạt động theo mô hình holding. VNI đang đầu tư và quản lý 6 công ty con trong các lĩnh vực như công ty phát triển chuỗi, công ty thương mại, công ty luật, công ty đào tạo, công ty truyền thông và công ty công nghệ.</p>\r\n\r\n<p>Đại diện World Gold cũng cho biết, quỹ này dành sự quan tâm và đầu tư cho mô hình “từ nông trại đến bàn ăn” do VNI phát triển tại thị trường Việt Nam, bao gồm: chuỗi cửa hàng thực phẩm sạch Gonfarm và chuỗi Nhà hàng Gontasty. Hiện tại, đã có 5 cửa hàng thực phẩm sạch Gonfarm đi vào hoạt động tại Hà Nội, TP HCM và một nhà hàng. &nbsp;</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Ngọc Tuyên</strong></p>\r\n','1','0','36','1496913480','1496913509','1');
INSERT INTO olala3w_article VALUES('943','447','Khai Hoan Viet','khai-hoan-viet-28x52apfzk','','','','khai-hoan-viet-1497932513.png','','','0','0','0','0','0','1917','công ty thành viên Khai Hoan Viet','<p>đang cập nhập....</p>\r\n','1','0','1','1497932460','1497932806','1');
INSERT INTO olala3w_article VALUES('944','447','Tulip Restaurant','tulip-restaurant-rxzl7rp0be','','','','tulip-restaurant-1497932530.png','','','0','0','0','0','0','1918','Nhà hàng Tulip','<p>đang cập nhập....</p>\r\n','1','0','1','1497932460','1497943639','1');
INSERT INTO olala3w_article VALUES('945','447','Viet A','viet-a','','','','viet-a-1497932550.png','','','0','0','0','0','0','1919','công ty thành viên Viet A','<p>đang cập nhập....</p>\r\n','1','0','1','1497932520','1497932733','1');
INSERT INTO olala3w_article VALUES('946','447','Trường Mầm Non 29/3','truong-mam-non-29-3','','','','truong-mam-non-29-3-1497932570.png','','','0','0','0','0','0','1920','Ngôi trường có bề dày truyền thống, đạt chuẩn chất lượng cao, hiện là một trong những trường điểm của thành phố.','<p>đang cập nhập....</p>\r\n','1','0','1','1497932520','1497942973','1');
INSERT INTO olala3w_article VALUES('947','447','F.Home','f-home-6jzrk99bzg','','','','f-home-1497932586.png','','','0','0','0','0','0','1921','Chung cư cao cấp F.Home','<p>đang cập nhập....</p>\r\n','1','0','1','1497932520','1497943270','1');
INSERT INTO olala3w_article VALUES('948','447','Hai Van Long','hai-van-long-rtsacu39fe','','','','hai-van-long-1497932598.png','','','0','0','0','0','0','1922','công ty thành viên Hai Van Long','<p>đang cập nhập....</p>\r\n','1','0','2','1497932580','1497932675','1');
INSERT INTO olala3w_article VALUES('949','447','Zen Diamond','zen-diamond-g3qe7ipsu5','','','','zen-diamond-1497932616.png','','','0','0','0','0','0','1923','Zen Diamond Suites Danang hiện là “viên ngọc” sáng nhất với 290 phòng và căn hộ có hướng nhìn trực tiếp ra sông Hàn và cầu Thuận Phước.','<p>đang cập nhập....</p>\r\n','1','0','3','1497932580','1497942997','1');
INSERT INTO olala3w_article VALUES('924','455','Lý do ASEAN trở thành miền đất hứa cho lĩnh vực IoT','ly-do-asean-tro-thanh-mien-dat-hua-cho-linh-vuc-iot','','','','ly-do-asean-tro-thanh-mien-dat-hua-cho-linh-vuc-iot-1496816664.jpg','','','0','0','0','0','0','1874','Tiềm năng phát triển kinh tế, tăng trưởng doanh nghiệp vừa và nhỏ, sự vào cuộc của các công ty viễn thông thúc đẩy IoT ở Đông Nam Á phát triển.','<p>Với dân số hơn 600 triệu người, GDP đạt 2,31 nghìn tỷ USD năm 2016, Đông Nam Á được đánh giá là thị trường lớn, đặc biệt là lĩnh vực IoT (Internet of Things) - mạng lưới kết nối vạn vật qua Internet.</p>\r\n\r\n<p><strong>Tiềm năng phát triển kinh tế</strong></p>\r\n\r\n<p>Theo báo cáo tiềm năng phát triển kinh tế thế giới từ Quỹ tiền tệ quốc tế IMF năm 2016, Myanmar có tốc độ phát triển kinh tế nhanh. Hai quốc gia đại diện cho ASEAN cũng nằm trong top 10 là Lào và Campuchia.</p>\r\n\r\n<p>Bảy quốc gia còn lại trong khu vực gồm Brunei, Indonesia, Malaysia, Philippines, Singapore, Thái Lan và Việt Nam có mức tăng trưởng GDP bình quân trên 4%. Dự báo trong 2-3 năm tới, mức tăng trưởng tại Đông Nam Á dự kiến 5-6% so với mức tăng trưởng toàn cầu 3%.&nbsp;</p>\r\n\r\n<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt=\"ly-do-asean-tro-thanh-mien-dat-hua-cho-linh-vuc-iot\" data-natural-width=\"500\" data-pwidth=\"660\" data-width=\"500\" src=\"https://i-startup.vnecdn.net/2017/05/23/IoT1-7646-1495509622.jpg\" /></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>ASEAN là thị trường tiềm năng phát triển IoT.&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Tốc độ tăng trưởng nhanh trong khu vực đã thu hút nhiều nhà đầu tư trên thế giới. Năm 2016, ASEAN xuất hiện nhiều thành viên và công ty mới. Điển hình là Alibaba đã đầu tư 1 tỷ USD vào Lazada. Bên cạnh đó, Amazon đã đầu tư 600 triệu USD vào Indonesia để xây dựng hệ thống giao hàng trong khu vực.&nbsp;</p>\r\n\r\n<p><strong>Tăng trưởng các doanh nghiệp nhỏ và vừa</strong></p>\r\n\r\n<p>Thế giới đã chứng kiến những sản phẩm áp dụng công nghệ dựa trên nền tảng IoT của các doanh nghiệp nhỏ và vừa trong nhiều lĩnh vực. Từ việc thu hoạch sầu riêng dựa trên dữ liệu thời gian thực tế áp dụng IoT cho tới chăm sóc bệnh nhân bằng những phân tích y tế… Các doanh nghiệp nhỏ đang tạo ra tiềm năng thị trường lớn dành cho các nhà cung cấp giải pháp IoT.</p>\r\n\r\n<p>Tại Indonesia, nơi có gần 60 triệu doanh nghiệp nhỏ và vừa, mức tăng trưởng của các công ty này khoảng 10% từ năm 2009, chiếm &nbsp;99,9% tổng số doanh nghiệp trong nước và đóng góp &nbsp;hơn 60% tăng trưởng GDP. Theo ngân hàng phát triển châu Á ADB, số lượng các doanh nghiệp nhỏ tại Việt Nam và Philipines tăng hơn 45% và 20% trong giai đoạn 5 năm (2009-2014).</p>\r\n\r\n<p>Trong khảo sát về \"Lưu trữ đám mây” được thực hiện bởi Rightscale vào năm 2016, có 32% doanh nghiệp nhỏ và vừa sử dụng “đám mây tập trung” so với con số 25% doanh nghiệp lớn sử dụng công nghệ này. Đây chính là những điều đang diễn ra tại ASEAN, khi các công ty nhỏ đang trở nên nhanh nhạy, tích cực áp dụng giải pháp liên quan đến IoT trong mỗi ngành nghề tương ứng.&nbsp;</p>\r\n\r\n<p><strong>Sự vào cuộc của các công ty viễn thông&nbsp;</strong></p>\r\n\r\n<p>Các công ty viễn thông đại diện cho nhóm doanh nghiệp lớn tại Đông Nam Á đang tích cực đầu tư vào lĩnh vực IoT. Chẳng hạn Singtel và Starhub của Singapore đang triển khai Singtel Innov8 và i3 để hỗ trợ hệ sinh thái khởi nghiệp tại Singapore.</p>\r\n\r\n<p>Trong khu vực, các công ty viễn thông khác cũng có cùng mục đích tương tự như DTAC Accelerate của DTAC, Globe Telecom Kickstart Ventures hay FPT Ventures của FPT (Việt Nam).</p>\r\n\r\n<p>Trong vài năm qua, các công ty viễn thông cố gắng chào bán các sản phẩm IoT tới khách hàng. Có thể thấy Indosat đã nỗ lực xây dựng và cải thiện sản phẩm IoT trong suốt 2 năm từ 2014-2015. Tháng 11/2016, công ty này tung ra Nexthing, sản phẩm sử dụng nền tảng IoT để tập trung hỗ trợ phát triển lĩnh vực này cho các doanh nghiệp địa phương.&nbsp;</p>\r\n\r\n<p>2017 dự đoán là năm có nhiều khởi sắc đối với thị trường khu vực ASEAN. Đây có thể sẽ trở thành thị trường chiến lược dành cho các tập đoàn, doanh nghiệp có nền tảng IoT mạnh mẽ và đa dạng.&nbsp;</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Lạc Thảo</strong><br />\r\n<em>(Theo Tech in Asia)</em></p>\r\n','1','1','6','1496816460','1497943496','1');
INSERT INTO olala3w_article VALUES('925','446','Tổng quan','gioi-thieu-chung','','','','no','','','0','0','0','0','0','1875','','<table border=\"0\" cellpadding=\"1\" cellspacing=\"5\" style=\"width:100%;\">\r\n	<tbody>\r\n		<tr style=\"position:relative\">\r\n			<td>&nbsp;</td>\r\n			<td style=\"padding-right: 24px;\">\r\n			<p style=\"background-color: #ececec;\"><img alt=\"\" src=\"/uploads/images/120.png\" /></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"background-color: #2fb6cc;padding: 50px 45px;color: #fff;font-size: 14px;font-weight: 300;position: absolute;width: 55%;top: 154px;\">Công ty CP Đầu tư Tổng hợp Khởi nghiệp Việt (<span style=\"color:#fff;\">V.Star-tup</span>) xác lập giá trị tiên phong và khác biệt, dựa trên nền tảng: Con người - Công nghệ - Kết nối. V.Startup nhanh chóng trở thành một trong những công ty đa ngành đem lại nhiều lợi nhuận cùng các dự án tiêu biểu.</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"padding-right: 20px; padding-left: 45px;\">\r\n			<p style=\"margin-top: -60px;font-size: 14px;font-weight: 300;color: #000;\">Với sự hỗ trợ của các chuyên gia hàng đầu về công nghệ thông tin đến từ Thung lũng Silicon (Mỹ), sự vận dụng khéo léo công nghệ, sử dụng con người thông minh, kết nối con người thông minh, V.Startup trở thành một trong những doanh nghiệp có tiềm năng phát triển cao ở nhiều ngành nghề, nhiều lĩnh vực.</p>\r\n			</td>\r\n			<td>\r\n			<p style=\"margin-top:40px; font-size: 14px;font-weight: 300;color: #000;width: 93%; margin-left:0px;\">Có vốn điều lệ 100 tỉ đồng, dự kiến đến..2018 sẽ…(tương đương…USD). Chiến lược phát triển của V.Startup trong những năm tới sẽ tập trung vào phát triển bền vững, lấy con người làm trọng tâm để khẳng định thương hiệu của mình.</p>\r\n\r\n			<p style=\"font-size: 14px;font-weight: 300;color: #000;width: 93%; margin-left:0px;\"><span style=\"color: #000;\">V.Startup</span>&nbsp;với chiến lược phát triển khác biệt, tạo nên những sản phẩm thông minh mang lại giá trị kinh tế cao. Vì vậy, V.Startup được các đối tác trong và ngoài nước tin tưởng, đánh giá cao và chủ động liên kết, hợp tác. Đó là các mối quan hệ lâu bền mà V.Startup trân trọng và gìn giữ.&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','1','0','272','1496821320','1497933281','1');
INSERT INTO olala3w_article VALUES('941','470','Thông điệp HĐQT','thong-diep-hdqt-x37swdp8b0','','','','no','','','0','0','0','0','0','1906','','<div style=\"position: relative; margin-bottom: 27px;\">\r\n<div>\r\n<div>\r\n<div style=\"margin-right: 260px; text-align: right;\"><img alt=\"\" src=\"/uploads/images/manager_startup.png\" /></div>\r\n</div>\r\n\r\n<p style=\"margin-right: 260px; font-size: 14px; color: #000; padding-left: 10px;\">Được thành lập năm 2016 - Năm Khởi nghiệp Quốc gia, <span style=\"color: #2fb6cc;\">V.Startup</span> đáp ứng nhu cầu ngày càng cao của cộng đồng khởi nghiệp. Với tâm huyết kiến tạo môi trường sáng tạo, chuyên nghiệp, V.Startup là bệ phóng để các doanh nghiệp khởi nghiệp thành công với chuỗi liên kết.<br />\r\n<span style=\"font-size: 16px; font-style: italic;  text-align: right; display: block;color: #074a91;\">CON NGƯỜI - CÔNG NGHỆ - KẾT NỐI</span></p>\r\n\r\n<div style=\"position: absolute; bottom: 122px; right: 4px; background-color: #074a91; color: #fff; padding: 26px 35px; text-align: center;\">\r\n<strong style=\"font-size: 20px;\"><span>Ông: Phạm Tấn Củng</span></strong><br />\r\n<span style=\"font-size: 14px;\">Chủ tịch Hội Đồng Quản Trị V.STARTUP</span></div>\r\n</div>\r\n</div>\r\n\r\n<div style=\"position: relative;\">\r\n<div style=\"\r\n    background-color: #2fb6cc;\r\n    color: #fff;\r\n    padding: 30px 10px 20px 10px;\r\n    margin-bottom: 20px;\r\n\">\r\n<p style=\"\r\n    text-align: justify;\r\n    width: 68%;\r\n    float: left;\r\n\">V.Startup tiên phong trong kiến tạo các giá trị mới.Bằng bản lĩnh, tâm huyết, kinh nghiệm của mình V.Startup khao khát đem lại những giá trị tốt đẹp cho cộng đồng. Ở V.Startup, tinh thần kết nối luôn được đề cao. Chia sẻ kinh nghiệm, chia sẻ cơ hội, kết nối để thành công. Bằng nỗ lực của mình, V.Startup là minh chứng rõ nét cho giá trị cốt lõi của khởi nghiệp.</p>\r\n\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n\r\n<div>\r\n<div div=\"\" style=\"\r\n    float: left;\r\n    width: 40%;\r\n    padding: 10px 10px 20px 10px;\r\n    font-size: 14px;\r\n    color: #000;\r\n\">\r\n<p>Định hướng của V.Startup là luôn bắt kịp, hòa nhập và đón đầu những xu hướng kinh doanh mới trên thị trường. Với lợi thế am hiểu thị trường, luật pháp và đất đai, V.Startup sẽ giúp các tập đoàn, công ty trong và ngoài nước giảm thiểu rủi ro tài chính khi hợp tác, đầu tư tại Việt Nam.</p>\r\n</div>\r\n\r\n<div style=\"\r\n    float: left;\r\n    background-color: #2fb6cc;\r\n    width: 60%;\r\n    padding: 10px 0 10px 50px;\r\n\"><img alt=\"\" src=\"/uploads/images/v_star.png\" /></div>\r\n\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n\r\n<div style=\"\r\n    background-color: #074a91;\r\n    color: #fff;\r\n    padding: 30px 25px;\r\n    font-size: 14px;\r\n    text-align: justify;\r\n    position: absolute;\r\n    top: 40px;\r\n    max-width: 222px;\r\n    right: 20px;\r\n\">Tập thể V.Startup chung mục tiêu vì cộng đồng phát triển. Vì vậy, chúng tôi tôn trọng cổ đông, tôn trọng đồng nghiệp, nhân viên, khách hàng, cùng nhau cộng hưởng, kết nối để thành công.</div>\r\n</div>\r\n','1','0','133','1496992980','1497953493','1');
INSERT INTO olala3w_article VALUES('926','471','Tầm nhìn - Sứ mệnh - Giá trị ','tam-nhin-su-menh-gia-tri','','','','no','','','0','0','0','0','0','1876','','<table cellpadding=\"1\" cellspacing=\"5\" style=\"margin-left:-6px;width:100%;\">\r\n	<tbody>\r\n		<tr style=\"position: relative\">\r\n			<td style=\"padding-right:5px;\">\r\n			<p style=\"text-align: center;position: relative\"><img alt=\"\" src=\"/uploads/images/RpTvdhD5vxJA5p2O7pi9DBwdvision-mission%20for%20reference.jpg\" style=\"height: 226px;\" /> <strong style=\"position: absolute; top: 15px; right: 5px;\"><span style=\"color: #fff;font-size: 25px;font-weight: 300;\">TẦM NHÌN&nbsp;</span></strong></p>\r\n			</td>\r\n			<td style=\"padding-right:5px; padding-top: 15px;\">\r\n			<p style=\"font-size: 14px; color: #000; text-align: justify;margin-top: -95px;\">V.Startup định hướng trở thành một trong những công ty hàng đầu về quy mô và hiệu quả trong các lĩnh vực: Phát triển dự án, kinh doanh thương mại, Giáo dục, Công nghệ thông tin.</p>\r\n\r\n			<p style=\"text-align: right; \"><span style=\"color: #2fb6cc;\">V.Startup</span> kiến tạo môi trường khởi nghiệp&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align: top;  padding-left:5px; padding-top: 30px\">\r\n			<p style=\"font-size: 14px; color: #000; text-align: justify; margin-right: 12px;\">Luôn luôn mang lại giá trị cao nhất cho khách hàng bằng sản phẩm và dịch vụ tốt nhất. Đó là những sản phẩm thông minh tăng cường sự kết nối, đem lại lợi nhuận kinh tế cao.</p>\r\n			</td>\r\n			<td style=\"text-align: center; position: absolute; top: 235px;\">\r\n			<p><img alt=\"\" src=\"/uploads/images/su_menh.png\" style=\"height: 228px; width: 395px;\" /> <strong style=\"position: absolute; bottom: 60px; right: 5px;\"><span style=\"color: #fff;font-size: 25px;font-weight: 300;\">SỨ MỆNH&nbsp;</span></strong></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p style=\"text-align: center; margin-top: 55px;margin-left: -50px; position:relative;\"><img alt=\"\" src=\"/uploads/images/congnghe.jpg\" style=\"width: 822px; height: 138px;\" /><span style=\"position: absolute;top: 50%; left: 50%;color: #fff;transform: translate(-50%,-50%);font-size: 24px;font-weight: 300;\">CON NGƯỜI - CÔNG NGHỆ - KẾT NỐI.&nbsp;</span></p>\r\n\r\n<table border=\"0\" cellpadding=\"1\" cellspacing=\"0\" style=\"width:100%;\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align: center;background-color: #2fb6cc; padding: 15px;color:  #fff;font-size: 14px; width: 50%;\"><span style=\"font-size:16px;\"><strong style=\"text-align: center; color: #fff;font-size: 20px;\">CON NGƯỜI</strong></span>\r\n\r\n			<p style=\"text-align: justify;\">Khách hàng, đối tác và nguồn nhân lực là những yếu tố trọng tâm trong quá trình phát triển công ty CP Đầu tư Tổng hợp Khởi nghiệp Việt cũng như trong các cơ hội kinh doanh.</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align: center;background-color: #fff; padding: 15px;color:  #000;font-size: 14px; width: 50%;\"><strong style=\"text-align: center;\"><span style=\"color: #000; font-size: 20px;\">CÔNG NGHỆ</span></strong>\r\n			<p style=\"text-align: justify;\"><span style=\"color: #2fb6cc;\">V.Startup</span> luôn tiên phong ứng dụng những thành tựu công nghệ mới nhất vào kinh doanh. Đây vừa là công cụ, vừa là chìa khóa giúp V.Startup phát triển ngày càng mạnh mẽ.</p>\r\n			</td>\r\n			<td style=\"text-align: center;background-color: #074a91;padding: 15px;color:  #fff;font-size: 14px; width: 50%;\">\r\n			<p><span style=\"font-size:20px;\"><strong>GIÁ TRỊ CỐT LÕI<strong style=\"color: #fff; text-align: center; font-size:20px;\">&nbsp;</strong></strong></span></p>\r\n\r\n			<p>Công ty CP Đầu tư Tổng hợp Khởi nghiệp Việt (V.Startup)&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align: center;background-color: #2fb6cc;padding: 15px;color:  #fff;font-size: 14px; width: 50%;\"><strong style=\"color: #fff; text-align: center; font-size: 20px;\">KẾT NỐI</strong>\r\n			<p style=\"text-align: justify;\">V.Startup luôn chú trọng việc kết nối giữa con người với công nghệ, giữa doanh nghiệp với doanh nghiệp, từ đó tạo nên sức mạnh để doanh nghiệp phát triển bền vững.</p>\r\n			</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n','1','0','213','1496821620','1497953997','1');
INSERT INTO olala3w_article VALUES('927','460','Sơ đồ tổ chức','so-do-to-chuc-28qt137wop','','','','no','','','0','0','0','0','0','1879','','<p style=\" text-align: center; background-color: #2fb6cc; margin-bottom: 24px; padding: 10px;\"><img alt=\"\" src=\"/uploads/images/v_star.png\" style=\"width: 186px; height: 155px;\" /></p>\r\n\r\n<p style=\"padding-left: 160px;padding-right: 122px;font-size: 14px;\">Tên công ty :&nbsp;<span style=\"color:#2fb6cc;\"><strong>CÔNG TY CỔ PHẦN ĐẦU TƯ TỔNG HỢP KHỞI NGHIỆP VIỆT</strong></span>&nbsp;<br />\r\nTên viết tắt :&nbsp;<strong><span style=\"color:#2fb6cc;\">V.STARTUP</span></strong><br />\r\nNăm thành lập 2016<br />\r\nChủ tịch HĐQT: Phạm Tấn Hùng<br />\r\nTổng Giám đốc: Trần Chí Nghĩa<br />\r\nVốn điều lệ: 100 tỷ đồng<br />\r\n<img alt=\"\" src=\"/uploads/images/location.png\" style=\"float: left; margin-right: 10px; color: #2fb6cc;\r\n\" /><span>Trụ sở chính:<br />\r\n16 Lý Thường Kiệt, phường Thạch Thang, quận Hải Châu, Tp Đà Nẵng, Việt Nam.</span></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/sodo.png\" /></p>\r\n','1','0','88','1496822700','1497925586','1');
INSERT INTO olala3w_article VALUES('928','461','Ban lãnh đạo','ban-lanh-dao-l7ir9sx18n','','','','no','','','0','0','0','0','0','1880','','<div style=\"position: relative; margin-bottom: 60px;\">\r\n<div style=\" margin-bottom: 20px; background-color: #2fb6cc; padding: 30px 35px 50px 20px; color: #Fff;font-size: 14px;\">\r\n<p style=\"float: left; width: 72%; margin-bottom: 20px; \">Ông Phạm Tấn Củng là Chủ tịch Hội đồng quản trị Công ty Cổ phần Đầu tư Tổng hợp Khởi Nghiệp Việt.<br />\r\nÔng Củng có kinh nghiệm hơn 20 năm điều hành và quản lý doanh nghiệp. Hiện nay, ông Củng kiêm nhiệm các vai trò: Chủ tịch Hội đồng quản trị - Tổng Giám đốc Công ty Cổ phần Lương thực Đà Nẵng, Chủ tịch HĐQT Công ty CP Xuân Việt.<br />\r\nÔng Củng tốt nghiệp Cử nhân Kinh tế, Đại học Quản trị Kinh doanh Tp.HCM.</p>\r\n\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n\r\n<div style=\"position: absolute; bottom: -24px; right: 20px;\"><img alt=\"\" src=\"/uploads/images/Untitled-1.jpg\" style=\" max-width: 200px; height: 278px;\" /></div>\r\n\r\n<div style=\"position: absolute; bottom: -17px; right: 207px; background-color: #074a91; color: #fff;padding: 20px 60px; text-align: center; \"><strong style=\" font-size: 16px; \">PHẠM TẤN CỦNG</strong><br />\r\n<span style=\"font-size: 14px;\">Chủ tịch Hội đồng quản trị</span></div>\r\n</div>\r\n\r\n<div style=\"position: relative; margin-bottom: 60px;\">\r\n<div style=\" margin-bottom: 20px; background-color: #2fb6cc; padding: 30px 35px 50px 30px; color: #Fff;font-size: 14px;\">\r\n<p style=\"float: right; width: 73%; margin-bottom: 20px; \">Ông Trần Chí Nghĩa là Thành viên HĐQT kiêm Tổng Giám đốc Công ty Cổ phần Đầu tư Tổng hợp Khởi Nghiệp Việt.<br />\r\nÔng Nghĩa đồng thời là Thành viên Hội đồng Quản trị, Phó Tổng Giám đốc Công ty CP Lương thực Đà Nẵng.<br />\r\nÔng Nghĩa tốt nghiệp Thạc sĩ Chuyên ngành Quản trị Kinh doanh, Đại học Bách Khoa Tp Hồ Chí Minh.</p>\r\n\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n\r\n<div style=\"position: absolute; bottom: -29px; left: 22px;\"><img alt=\"\" src=\"/uploads/images/14.png\" style=\" max-width: 200px; height: 283px;\" /></div>\r\n\r\n<div style=\"position: absolute; bottom: -22px; left: 222px; background-color: #074a91; color: #fff;padding: 20px 60px; text-align: center; \"><strong style=\" font-size: 16px; \">Ths. TRẦN CHÍ NGHĨA</strong><br />\r\n<span style=\"font-size: 14px;\">Tổng Giám đốc</span></div>\r\n</div>\r\n\r\n<div style=\"position: relative; margin-bottom: 60px;\">\r\n<div style=\" margin-bottom: 20px; background-color: #2fb6cc; padding: 30px 35px 50px 20px; color: #Fff;font-size: 14px;\">\r\n<p style=\"float: left; width: 72%; margin-bottom: 20px; \">Ông Chương là thành viên HĐQT Công ty Cổ phần Đầu tư Tổng hợp Khởi Nghiệp Việt.<br />\r\nÔng Chương tốt nghiệp Cử nhân Quản trị kinh doanh Đại học Portsmouth, Singapore kiêm qua vị trí Giám đốc Công ty TNHH MTV Hải Vân Long, Phó Giám đốc Công ty CP Du lịch Dịch vụ và Đầu tư xây dựng Hội An, thành viên HĐQT Công ty CP Lương thực Đà Nẵng</p>\r\n\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n</div>\r\n\r\n<div style=\"position: absolute; bottom: -75px; right: 20px;\"><img alt=\"\" src=\"/uploads/images/Untitled-3.jpg\" style=\" max-width: 200px; height: 283px;\" /></div>\r\n\r\n<div style=\"position: absolute; bottom: -60px; right: 219px; background-color: #074a91; color: #fff;padding: 20px 60px; text-align: center; \"><strong style=\" font-size: 16px; \">LÊ CÔNG CHƯƠNG</strong><br />\r\n<span style=\"font-size: 14px;\">Thành viên HĐQT</span></div>\r\n</div>\r\n','1','0','125','1496822820','1497954967','1');
INSERT INTO olala3w_article VALUES('929','469','Phát triển dự án','phat-trien-du-an-gv6kx369eh','','','','phat-trien-du-an-1496894431.jpg','','','0','0','0','0','0','1881','','<p>&nbsp; &nbsp;Đây là một trong những ngành nghề mũi nhọn của V.Startup. Công ty hiện đang làm chủ đầu tư nhiều dự án bất động sản tại Đà Nẵng và các tỉnh miền Trung.<br />\r\n&nbsp; &nbsp;Với mục tiêu đem đến cho khách hàng những trải nghiệm và dịch vụ tốt nhất cùng không gian sống đẳng cấp, V.Startup chú trọng đầu tư và phát triển các dự án bất động sản có vị trí trung tâm, đắc địa, khả năng sinh lời cao, đem lại lợi nhuận cho các nhà đầu tư của V.Startup.<br />\r\n<strong>Xây dựng và kinh doanh </strong>khách sạn, nhà ở, văn phòng làm việc, V.Startup đã tạo một chuỗi phát triển liên hoàn, đem lại giá trị kinh tế cao.<br />\r\n<strong>Tư vấn, quản lí bất động sản:</strong> Đội ngũ chuyên viên tư vấn tận tâm, giàu kinh nghiệm sẽ giúp quý khách quản lí và giao dịch bất động sản phù hợp với nhu cầu, làm gia tăng giá trị các bất động sản của khách hàng, bao gồm các dịch vụ: môi giới, định giá, sàn giao dịch, quảng cáo bất động sản.<br />\r\n<strong>Phát triển dự án</strong></p>\r\n\r\n<p style=\"text-align: center;\"><strong><img alt=\"\" src=\"/uploads/images/Full%20060617-8.jpg\" /></strong></p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"color:#0000FF;\"><strong>Phối cảnh dự án Nguyễn Tri Phương do V.Startup là chủ đầu tư</strong></span></p>\r\n\r\n<p>&nbsp; &nbsp;V.Startup có đội ngũ nhân lực giàu kinh nghiệm, có tầm nhìn chiến lược, am hiểu thị trường bất động sản, tìm kiếm và phát triển các dự án mang tính vượt trội so với các dự án đang hiện hữu trên thị trường. V.Startup xem trọng hiệu quả đầu tư, đảm bảo nguồn thu và lợi nhuận, xem quyền lợi và thành công của khách hàng là thành công của chính mình.<br />\r\n&nbsp; &nbsp;V.Startup hiện sở hữu các dự án siêu lợi nhuận: vị trí đắc địa, được quản lí, chăm sóc và vận hành bởi các công ty uy tín của Nhật Bản, khả năng sinh lời cao nhất.</p>\r\n','1','0','82','1496823840','1496911503','1');
INSERT INTO olala3w_article VALUES('930','450','Thương mại & Dịch vụ','thuong-mai-dich-vu-xaf62oxuea','','','','no','','','0','0','0','0','0','1882',' ','<p>Sáng lập và điều hành V.Startup là những người có kinh nghiệm dày dạn trong kinh doanh thương mại. V.Startup xây dựng được mạng lưới giao thương rộng khắp, đảm bảo cho hoạt động sản xuất, hoạt động kinh doanh xuất nhập khẩu. Dịch vụ của V.Startup luôn mang đến cho khách hàng sự tín nhiệm cao nhất, thuận tiện, tiết kiệm thời gian với chi phí cạnh tranh. V.Startup luôn có những khách hàng truyền thống, những người bạn đồng hành cùng các hoạt động kinh doanh của công ty.</p>\r\n\r\n<p>V.Startup chú trọng phát triển các ngành dịch vụ như nhà hàng, khách sạn, hostel, spa, cà phê, trung tâm thương mại, văn phòng cho thuê... nhằm mục đích đem đến cho khách hàng những trải nghiệm tốt nhất. Đây là mảng kinh doanh khẳng định vị thế kiến tạo một không gian sống mang tính nhân văn mà V.Startup luôn mong muốn đem đến cho quý khách hàng.</p>\r\n','1','0','34','1496823960','1496907395','1');
INSERT INTO olala3w_article VALUES('931','451','Công nghệ thông tin','cong-nghe-thong-tin-3ibnxi7zbo','','','','cong-nghe-thong-tin-1496906449.png','','','0','0','0','0','0','1883','','<p>&nbsp;&nbsp; Với sự hỗ trợ công nghệ thông tin từ các chuyên gia hàng đầu từ Thung lũng Silicon (Mỹ), V.Startup cung cấp các giải pháp công nghệ thông tin giúp doanh nghiệp ứng dụng, mang lại hiệu quả cao. Mô hình V.Startup vận dụng là mô hình công ty thông minh bằng cách vận dụng công nghệ, sử dụng con người thông minh và kết nối con người thông minh.</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/Untitled-4.png\" style=\"background-color: rgb(255, 255, 255); text-align: center;\" /></p>\r\n\r\n<p>&nbsp; &nbsp;Tại cộng đồng khởi nghiệp do V.Startup xây dựng, công nghệ thông tin là mũi nhọn quan trọng để kiến tạo thành công cho doanh nghiệp. Từ công nghệ thông tin, V.Startup giúp doanh nghiệp kết nối với thế giới, mang lại cơ hội kinh doanh mới.&nbsp;</p>\r\n','1','0','19','1496823960','1496906449','1');
INSERT INTO olala3w_article VALUES('932','452','Giáo dục','giao-duc','','','','giao-duc-1496907557.png','','','0','0','0','0','0','1884','','<p>Một trong những giá trị cốt lõi của V.Startup chính là con người. Vì vậy lĩnh vực giáo dục luôn được doanh nghiệp quan tâm đầu tư phát triển ngay từ những ngày đầu thành lập.</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/Untitled-5(1).png\" /></p>\r\n\r\n<p>Với phương châm ấy, V.Startup đang xây dựng hệ thống trường các cấp từ mầm non tới trung học phổ thông theo tiêu chuẩn quốc tế.</p>\r\n\r\n<p>&nbsp;</p>\r\n','1','0','33','1496824020','1496907557','1');
INSERT INTO olala3w_article VALUES('933','472','Văn hoá doanh nghiệp','van-hoa-doanh-nghiep-8dt94kyl83','','','','van-hoa-doanh-nghiep-1496895752.png','','','0','0','0','0','0','1885','','<meta charset=\"UTF-8\">\r\n<title></title>\r\n<div style=\"float: left; width: 48%; margin-right: 15px;\">\r\n<div style=\"margin-bottom: 15px\"><img alt=\"\" src=\"/uploads/images/van_hoa.png\" style=\"width: 100%; height: auto;\" /></div>\r\n\r\n<div style=\"position: relative; margin-bottom: 15px;\"><img alt=\"\" src=\"/uploads/images/sang_tao.png\" style=\"width: 100%; height: auto;\" /> <span style=\"\r\n    position: absolute;\r\n    bottom: 35px;\r\n    right: 40px;\r\n    font-size: 25px;\r\n    color: #074a91;\r\n    font-weight: 300;\r\n\">SÁNG TẠO</span></div>\r\n\r\n<div><span style=\"font-size: 25px; color: #000; text-align: center; display: block; margin-bottom: 10px;\">TRÁCH NHIỆM</span>\r\n\r\n<p style=\"font-size:14px; color: #000;\">-Trách nhiệm của mỗi <span style=\"color: #2fb6cc;\">cá nhân với công ty</span><br />\r\n-Trách nhiệm của <span style=\"color: #2fb6cc;\">công ty đối với cộng đồng khởi nghiệp</span><br />\r\n-Trách nhiệm của <span style=\"color: #2fb6cc;\">công ty đối với xã hội</span></p>\r\n</div>\r\n</div>\r\n\r\n<div style=\"float: left; width: 48%;\">\r\n<div style=\"margin-bottom: 15px;padding: 15px 15px 7px 15px;background-color: #2fb6cc;color: #fff;font-size: 14px;\">\r\n<p>- Bản lĩnh để đối đầu với các làn sóng đầu tư mới<br />\r\n- Bản lĩnh bứt phá tạo dấu ấn riêng<br />\r\n- Bản lĩnh biến hoài bão, dự án thành hiện thực. Bản lĩnh để đối đầu với các làn sóng đầu tư mới<br />\r\n- Bản lĩnh bứt phá tạo dấu ấn riêng</p>\r\n</div>\r\n\r\n<div style=\"margin-bottom: 8px; position: relative;\"><img alt=\"\" src=\"/uploads/images/ban_linh.png\" style=\"width: 100%; height: auto;\" /> <span style=\"\r\n    position: absolute;\r\n    bottom: 35px;\r\n    right: 20px;\r\n    font-size: 25px;\r\n    color: #fff;\r\n\">BẢN LĨNH</span></div>\r\n\r\n<div style=\"margin-bottom: 15px\">\r\n<p style=\"\r\n    padding: 25px 15px;\r\n    background-color: #074a91;\r\n    color: #fff;\r\n    font-size: 14px;\r\n\">- Mỗi dự án, mỗi công việc đều là một dấu ấn sáng tạo khác biệt.<br />\r\n- Sáng tạo là không ngừng, là mấu chốt, trong chuỗi vận động, phát triển của V.Startup.</p>\r\n</div>\r\n\r\n<div><img alt=\"\" src=\"/uploads/images/trach_nhiem.png\" style=\"width: 100%; height: auto;\" /></div>\r\n</div>\r\n\r\n<div style=\"clear: both;\">&nbsp;</div>\r\n','1','0','115','1496824080','1497924628','1');
INSERT INTO olala3w_article VALUES('934','467','Tổ Hợp Văn Phòng V.S','to-hop-van-phong','','','','to-hop-van-phong-1496909993.png','','','0','0','0','0','0','1886','V.Startup Office là khu tổ hợp văn phòng tích hợp nhiều tiện ích bậc nhất thành phố với hơn 18.000 m2 văn phòng cho thuê.','<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/to-hop-van-phong-1496909993.png\" />&nbsp; &nbsp; &nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp;Nằm trong tòa nhà F.HOME với 2 block cao 26 tầng, khu tổ hợp văn phòng V.Startup tích hợp nhiều chức năng dịch vụ cao cấp, tạo điều kiện cho các doanh nghiệp và các nhà khởi nghiệp trẻ phát triển. Bên cạnh việc cung cấp diện tích sàn cho thuê, nơi đây còn có khu vực Co-working Space đem lại cho khách hàng nhiều sự lựa chọn cũng như phong cách làm việc mới mẻ, sáng tạo.</p>\r\n\r\n<p>&nbsp;</p>\r\n','1','0','7','1496909700','1497942340','1');
INSERT INTO olala3w_article VALUES('935','467','Khách Sạn Zen Diamond ','khach-san','','','','khach-san-1496910091.png','','','0','0','0','0','0','1888','Zen Diamond Suites Danang hiện là “viên ngọc” sáng nhất với 290 phòng và căn hộ có hướng nhìn trực tiếp ra sông Hàn và cầu Thuận Phước.','<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/11.png\" /></p>\r\n\r\n<p>&nbsp; &nbsp;Tọa lạc ngay tại trung tâm thành phố biển xinh đẹp Đà Nẵng, Zen Diamond Suites Danang gồm 290 phòng và căn hộ có hướng nhìn toàn cảnh thành phố cùng sông Hàn thơ mộng và những cây cầu lung linh. Với tổng vốn đầu tư lên đến ... tỷ đồng, cao 26 tầng, Zen Diamond Suites Danang là một trong những công trình nổi bật và là nơi dừng chân lý tưởng để khám phá những điểm đến hấp dẫn của thànhphố cũng như những di sản văn hóa thế giới như Hội An, Mỹ Sơn...</p>\r\n','1','0','19','1496910000','1497942468','1');
INSERT INTO olala3w_article VALUES('936','467','Trường Mầm Non','truong-mam-non','','','','truong-mam-non-1496910318.png','','','0','0','0','0','0','1889','Ngôi trường có bề dày truyền thống, đạt chuẩn chất lượng cao, hiện là một trong những trường điểm của thành phố.','<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/image041.png\" /></p>\r\n\r\n<p>Đây là dự án vừa đáp ứng được nhu cầu ngày càng tăng về trường mầm non, vừa mang tính xã hội rất cao. Với số vốn đầu tư hơn ... tỉ đồng, trường mầm non 29/3 được cải tạo thành ngôi trường đạt tiêu chuẩn chất lượng cao, đáp ứng nhu cầu dạy và học tại TP. Đà Nẵng. Trẻ em sẽ được phát triển toàn diện các lĩnh vực đồng thời chuẩn bị đầy đủ kĩ năng và tâm thế trước khi bước vào lớp 1.</p>\r\n\r\n<p>&nbsp;</p>\r\n','1','0','6','1496910180','1497942117','1');
INSERT INTO olala3w_article VALUES('937','467','Dự Án Khu Phức Hợp','du-an-khu-phuc-hop','','','','du-an-khu-phuc-hop-1496911071.png','','','0','0','0','0','0','1891','5 Stars Complex có vị trí tuyệt đẹp, cách sông Hàn 1 km, cách biển 2 km về phía Đông, nằm trên trục đường chính Nguyễn Tri Phương-Lê Đình Lý.','<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/12(1).png\" /></p>\r\n\r\n<p>Chủ đầu tư: <strong>CÔNG TY CỔ PHẦN ĐẦU TƯ TỔNG HỢP KHỞI NGHIỆP VIỆT (V.STARTUP)</strong><br />\r\nLập dự án đầu tư: <strong>CÔNG TY CỔ PHẦN ĐẦU TƯ TỔNG HỢP KHỞI NGHIỆP VIỆT (V.STARTUP)</strong><br />\r\n<strong>Địa điểm:</strong> 271 Nguyễn Tri Phương, phường Hòa Thuận Tây, quận Hải Châu, Tp.Đà Nẵng<br />\r\n<strong>Vị trí:</strong> 5 Stars Complex có vị trí tuyệt đẹp, cách sông Hàn 1km, cách biển 2km về phía Đông, chỉ mất 5 phút đến sân bay quốc tế Đà Nẵng. 5 Start Complex nằm ở giao điểm trục đường chính Nguyễn Tri Phương-Lê Đình Lý, nằm trong tuyến kết nối với Nguyễn Văn Linh, tuyến phố thương mại, tài chính được mệnh danh là “phố Wall” của Đà Nẵng, trục đường 30-4, Nguyễn Hữu Thọ, tuyến dịch vụ, nhà hàng, khách sạn. 5 Stars Complex hội đủ các điều kiện trở thành khu Shopping Mall lớn nhất Đà Nẵng.<br />\r\n<strong>Mục tiêu xây dựng:</strong> Xây dựng Khu phức hợp Nguyễn Tri Phương - 5 Stars Complex thành khu Shopping Mall lớn nhất Đà Nẵng.<br />\r\n<strong>Tổng mức đầu tư dự kiến:</strong>5 Start Complex có tổng diện tích đất xây dựng 18.215m2 gồm 15 tầng cao<br />\r\n- Từ tầng 1-6: Trung tâm thương mại. Diện tích sàn 44.400m2<br />\r\n- Tầng 7-15: Khu văn phòng cho thuê.Diện tích sàn:40.542,5m2<br />\r\n- Tiểu dự án: Xây dựng trường cấp 1,2,3 đạt chuẩn Quốc tế<br />\r\nDự án sẽ khởi động vào quý III/2017 và hoàn thành 2020.</p>\r\n\r\n<p>&nbsp;</p>\r\n','1','0','10','1496910900','1497942087','1');
INSERT INTO olala3w_article VALUES('938','467','Dự Án Khách Sạn 5 sao Đà Nẵng','du-an-khach-san-5-sao-da-nang','','','','du-an-khach-san-5-sao-da-nang-1496911271.png','','','0','0','0','0','0','1892','Nằm ở vị trí “kim cương” ngay bên bờ sông Hàn thơ mộng, hiện là một trong những điểm sáng nhất bất động sản miền Trung.','<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/Ss53R0MsRlq_x6gxpBUL6w.png\" /></p>\r\n\r\n<p>Chủ đầu tư: <strong>CÔNG TY CỔ PHẦN ĐẦU TƯ TỔNG HỢP KHỞI NGHIỆP VIỆT (V.STARTUP)</strong><br />\r\nLập dự án đầu tư:<strong> CÔNG TY CỔ PHẦN ĐẦU TƯ TỔNG HỢP KHỞI NGHIỆP VIỆT (V.STARTUP)</strong><br />\r\n<strong>Địa điểm:</strong> Đường Như Nguyệt, Quận Hải Châu, TP.Đà Nẵng<br />\r\n<strong>Vị trí:&nbsp;</strong>5 Stars Hotel nằm ở vị trí “kim cương” ngay bên bờ sông Hàn, cách bờ biển 1km, sân bay quốc tế Đà Nẵng 3km, 5 Stars Hotel hiện là một trong những điểm sáng nhất của bất động sản Đà Nẵng. 5 Stars Hotel Đà Nẵng có 400 phòng tiêu chuẩn 5 sao. Dự kiến sẽ khởi công trong năm 2017.<br />\r\n<strong>Mục tiêu xây dựng: </strong>Xây dựng 5 Stars Hotel với quy mô 400 phòng đạt tiêu chuẩn 5 sao.<br />\r\n<strong>Tổng mức đầu tư dự kiến: </strong>45.000.000 USD trên diện tích 2.746m2 gồm 30 tầng nổi, 2 tầng hầm.</p>\r\n','1','0','50','1496911080','1497942502','1');
INSERT INTO olala3w_article VALUES('939','455','Startup của Mỹ gọi vốn thành công 1,5 tỷ USD','startup-cua-my-goi-von-thanh-cong-1-5-ty-usd','','','','startup-cua-my-goi-von-thanh-cong-1-5-ty-usd-1496978070.png','','','0','0','0','0','0','1893','Pinterest huy động gần 1,5 tỷ USD từ các nhà đầu tư như Rakuten, Andreessen Horowitz, Bessemer Venture Partners và SV Angel.','<p>Qua lần gọi vốn 150 triệu USD vừa diễn ra, giá trị công ty đạt 12,3 tỷ USD. Lần gần nhất vào tháng 4/2015, Pinterest gọi vốn thành công vòng Series G với 367 triệu USD, được các nhà đầu tư định giá 11 tỷ USD.</p>\r\n\r\n<p>Pinterest cho biết sẽ dùng nguồn vốn mới mở rộng công nghệ hiện thời nhằm gia tăng tính năng tìm kiếm hình ảnh và cải thiện tương thích của các quảng cáo tự nhiên đến thị giác của người dùng.&nbsp;</p>\r\n\r\n<p>Theo Pitchbook, tập đoàn tư vấn tài chính Hartford, nhà đầu tư định giá mỗi cổ phiếu của Pinterest 32,31 USD.</p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/Pinterest-2536-1496832318.png\" /></p>\r\n\r\n<p>Pinterest thành lập vào năm 2010, chuyên phát triển công nghệ tìm kiếm thị giác và cho phép người dùng lưu hình ảnh trên website. Công ty tự định danh mình là \"danh mục số của các ý tưởng\".&nbsp;</p>\r\n\r\n<p>Startup có trụ sở tại San Francisco (Mỹ) hiện có 175 triệu người dùng thường xuyên mỗi tháng. Ứng dụng cho phép người dùng thu thập và giữ các hình ảnh liên quan đến phong cách sống, thiết kế, du lịch và nhiều lĩnh vực được yêu thích trên website.&nbsp;</p>\r\n\r\n<p>Chức năng mua sắm của Pinterest tạo thuận lợi để người dùng mua hàng trên website này và công ty thu lợi nhuận từ các hoạt động quảng cáo. Mục tiêu doanh thu của Pinterest trong năm nay là 500 triệu USD. Doanh thu năm 2015 là 100 triệu USD và năm ngoái là 300 triệu USD.&nbsp;</p>\r\n\r\n<p>Vào tháng 2 vừa qua, Pinterest giới thiệu công cụ tìm kiếm mới mang tên Lens với mục đích đẩy mạnh doanh thu quảng cáo. Lens giúp người dùng tìm kiếm hình ảnh bằng chính camera của chiếc smartphone. Hiện lượng tìm kiếm của Pinterest qua thiết bị di động tăng trưởng 40% mỗi năm.&nbsp;</p>\r\n\r\n<p>60% người dùng của Pinterest đến từ ngoài biên giới nước Mỹ. Công ty cho biết đang làm việc để gia tăng trải nghiệm mang tính vùng miền cho người dùng.&nbsp;</p>\r\n\r\n<p style=\"text-align: right;\"><strong>Nhi Yến</strong></p>\r\n','1','1','12','1496912520','1497943494','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_article_menu` (
  `article_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `comment` text NOT NULL,
  `icon` text NOT NULL,
  `plus` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=473 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_article_menu VALUES('446','89','Tổng quan','ve-chung-toi','','','','0','1','','','','1','0','no','1496780628','1496992810','1');
INSERT INTO olala3w_article_menu VALUES('447','90','Công ty thành viên','v1-startup','','','','0','1','','','','1','0','no','1496780655','1496820565','1');
INSERT INTO olala3w_article_menu VALUES('448','90','Công ty liên kết','v2-startup','','','','0','2','','','','1','0','no','1496780665','1496820574','1');
INSERT INTO olala3w_article_menu VALUES('449','94','Phát triển dự án','phat-trien-du-an','','','','0','1','','','','1','0','no','1496780680','1496780680','1');
INSERT INTO olala3w_article_menu VALUES('450','94','Thương mại & Dịch vụ','linh-vuc-giao-duc','','','','0','2','','','','1','0','no','1496780693','1496995541','1');
INSERT INTO olala3w_article_menu VALUES('451','94','Công nghệ thông tin','cong-nghe-thong-tin','','','','0','3','','','','1','0','no','1496780710','1496780710','1');
INSERT INTO olala3w_article_menu VALUES('452','94','Lĩnh vực giáo dục','thuong-mai-dich-vu','','','','0','4','','','','1','0','no','1496780727','1496995535','1');
INSERT INTO olala3w_article_menu VALUES('453','97','Báo cáo tài chính','nha-dau-tu-01','','','','0','1','','','','1','0','no','1496780745','1496820611','1');
INSERT INTO olala3w_article_menu VALUES('454','97','Thông tin cổ đông','nha-dau-tu-02','','','','0','2','','','','1','0','no','1496780750','1496820621','1');
INSERT INTO olala3w_article_menu VALUES('455','98','Sự kiện & hoạt động','tin-hoat-dong','','','','0','1','','','','1','0','no','1496780766','1496820738','1');
INSERT INTO olala3w_article_menu VALUES('456','98','Tin thị trường','su-kien-noi-bat','','','','0','2','','','','1','0','no','1496780775','1496820749','1');
INSERT INTO olala3w_article_menu VALUES('457','98','Quan hệ với báo chí','blog','','','','0','3','','','','1','0','no','1496780782','1496820767','1');
INSERT INTO olala3w_article_menu VALUES('458','98','Tuyển dụng','tuyen-dung','','','','0','4','','','','0','0','no','1496780800','1496994007','1');
INSERT INTO olala3w_article_menu VALUES('470','89','Thông điệp HĐQT','thong-diep-hdqt','','','','0','2','','','','1','0','no','1496992953','1496992958','1');
INSERT INTO olala3w_article_menu VALUES('460','89','Sơ đồ tổ chức','so-do-to-chuc','','','','0','4','','','','1','0','no','1496820480','1496824097','1');
INSERT INTO olala3w_article_menu VALUES('461','89','Ban lãnh đạo','ban-lanh-dao','','','','0','4','','','','1','0','no','1496820497','1496820497','1');
INSERT INTO olala3w_article_menu VALUES('462','89','Cơ hội nghề nghiệp','co-hoi-nghe-nghiep','','','','0','5','','','','1','0','no','1496820535','1496994002','1');
INSERT INTO olala3w_article_menu VALUES('463','89','Media','media','','','','0','6','','','','1','0','no','1496820546','1496820546','1');
INSERT INTO olala3w_article_menu VALUES('464','97','Báo cáo thường niên','bao-cao-thuong-nien','','','','0','3','','','','1','0','no','1496820638','1496820638','1');
INSERT INTO olala3w_article_menu VALUES('465','97','Công bố thông tin','cong-bo-thong-tin','','','','0','4','','','','1','0','no','1496820678','1496820678','1');
INSERT INTO olala3w_article_menu VALUES('467','94','Dự án tiêu biểu','du-an-tieu-bieu','','','','449','2','','','','1','0','no','1496909670','1497943485','1');
INSERT INTO olala3w_article_menu VALUES('469','94','Chiến lược','phat-trien-du-an-jd5801gx44-w3pnl19pdu','','','','449','1','','','','1','0','no','1496911488','1496995269','1');
INSERT INTO olala3w_article_menu VALUES('472','89','Văn hóa doanh nghiệp','van-hoa-doanh-nghiep-d59owk39qi','','','','0','3','','','','1','0','no','1497003614','1497003624','1');
INSERT INTO olala3w_article_menu VALUES('471','89','Sứ mệnh - Tầm nhìn','su-menh-tam-nhin-yvohic5frh','','','','0','2','','','','1','0','no','1497003551','1497003569','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_car` (
  `car_id` int(11) NOT NULL AUTO_INCREMENT,
  `car_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `model` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `seat` varchar(255) NOT NULL,
  `seat_sort` int(11) NOT NULL DEFAULT '0',
  `color` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL,
  `sale` int(3) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`car_id`)
) ENGINE=MyISAM AUTO_INCREMENT=312 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_car_menu` (
  `car_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `comment` text NOT NULL,
  `icon` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`car_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `menu_main` int(1) NOT NULL DEFAULT '0',
  `sort_hide` int(11) NOT NULL DEFAULT '1',
  `menu_sm` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `icon` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_category VALUES('89','1','Giới thiệu','gioi-thieu','','','','','','1','1','1','1','2','0','gioi-thieu-1496823590.jpg','','0','1496823590','1');
INSERT INTO olala3w_category VALUES('90','1','Công ty thành viên & Liên kết','cong-ty-thanh-vien-lien-ket','','','','','','1','0','2','1','6','0','cong-ty-thanh-vien-lien-ket-1497944413.jpg','','0','1497944413','1');
INSERT INTO olala3w_category VALUES('91','2','Slider','slider','','','','','','1','0','1','0','1','0','no','','0','0','0');
INSERT INTO olala3w_category VALUES('97','1','Thông tin nhà đầu tư','thong-tin-nha-dau-tu','','','','','','1','1','4','1','1','0','thong-tin-nha-dau-tu-1496824299.jpg','','0','1496824299','1');
INSERT INTO olala3w_category VALUES('94','1','Sản phẩm và dịch vụ','san-pham-dich-vu','','','','','','1','0','3','1','1','0','san-pham-va-dich-vu-1496823783.jpg','','0','1496823783','1');
INSERT INTO olala3w_category VALUES('98','1','Tin tức','tin-tuc','','','','','','1','1','5','1','1','0','tin-tuc-1496824412.jpg','','0','1496824412','1');
INSERT INTO olala3w_category VALUES('102','2','Công ty thành viên & liên kết','partners','','','','','','1','0','1','0','1','0','no','','0','0','0');

-- --------------------------------------------------------

CREATE TABLE `olala3w_category_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(30) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_category_type VALUES('1','Bài viết','article_manager','1','1');
INSERT INTO olala3w_category_type VALUES('2','Hình ảnh','gallery_manager','2','1');
INSERT INTO olala3w_category_type VALUES('7','Đăng ký email','register_email','9','1');
INSERT INTO olala3w_category_type VALUES('6','Sản phẩm','product_manager','3','0');
INSERT INTO olala3w_category_type VALUES('8','Booking online','order_list','7','0');
INSERT INTO olala3w_category_type VALUES('9','Tour du lịch','tour_manager','5','0');
INSERT INTO olala3w_category_type VALUES('10','Đồ lưu niệm','gift_manager','0','0');
INSERT INTO olala3w_category_type VALUES('11','Thuê xe','car_manager','6','0');
INSERT INTO olala3w_category_type VALUES('12','Vị trí địa lý','location_manager','0','0');
INSERT INTO olala3w_category_type VALUES('13','Dữ liệu đường phố','street_manager','0','0');
INSERT INTO olala3w_category_type VALUES('14','Dữ liệu phương hướng','direction_manager','0','0');
INSERT INTO olala3w_category_type VALUES('15','Dữ liệu khác','others_manager','4','0');
INSERT INTO olala3w_category_type VALUES('16','Chiều rộng đường','road_manager','0','0');
INSERT INTO olala3w_category_type VALUES('17','Dự án','project_manager','0','0');
INSERT INTO olala3w_category_type VALUES('18','BĐS kinh doanh','bds_business_manager','0','0');
INSERT INTO olala3w_category_type VALUES('19','Dữ liệu tên dự án','prjname_manager','0','0');
INSERT INTO olala3w_category_type VALUES('20','Thư liên hệ','contact_list','8','1');
INSERT INTO olala3w_category_type VALUES('21','Văn bản / Tài liệu','document_manager','3','0');

-- --------------------------------------------------------

CREATE TABLE `olala3w_constant` (
  `constant_id` int(11) NOT NULL AUTO_INCREMENT,
  `constant` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` int(2) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`constant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_constant VALUES('1','date','d/m/Y','Kiểu hiển thị ngày tháng năm','3','1');
INSERT INTO olala3w_constant VALUES('2','time','H:i','Kiểu hiển thị giờ phút','3','2');
INSERT INTO olala3w_constant VALUES('3','timezone','Asia/Bangkok','Múi giờ','3','4');
INSERT INTO olala3w_constant VALUES('4','title','V Startup','Title (trang chủ)','0','1');
INSERT INTO olala3w_constant VALUES('5','description','V Startup','Description (trang chủ)','0','2');
INSERT INTO olala3w_constant VALUES('6','keywords','V Startup','Keywords (trang chủ)','0','3');
INSERT INTO olala3w_constant VALUES('74','script_body','<div id=\"fb-root\"></div>\r\n<script>(function(d, s, id) {\r\n  var js, fjs = d.getElementsByTagName(s)[0];\r\n  if (d.getElementById(id)) return;\r\n  js = d.createElement(s); js.id = id;\r\n  js.src = \"//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.5\";\r\n  fjs.parentNode.insertBefore(js, fjs);\r\n}(document, \'script\', \'facebook-jssdk\'));</script>\r\n','Script sau body','4','6');
INSERT INTO olala3w_constant VALUES('76','link_linkedin','https://www.linkedin.com','LinkedIn','5','5');
INSERT INTO olala3w_constant VALUES('7','email_contact','info@vstartup.com.vn','Email','0','8');
INSERT INTO olala3w_constant VALUES('8','tell_contact','(+84) 236 3888 626','Điện thoại','0','9');
INSERT INTO olala3w_constant VALUES('9','fulldate','D, d/m/Y','Kiểu hiển ngày đầy đủ','3','3');
INSERT INTO olala3w_constant VALUES('10','SMTP_username','mail.danaweb@gmail.com','Tài khoản email','1','0');
INSERT INTO olala3w_constant VALUES('11','SMTP_password','123456987abc','Mật khẩu email','1','0');
INSERT INTO olala3w_constant VALUES('12','error_page','<p>Vì lý do kỹ&nbsp;thuật website tạm ngưng&nbsp;hoạt động. Thành thật xin lỗi các bạn&nbsp;vì sự bất tiện này!</p>\r\n','Thông báo ngừng hoạt động','0','19');
INSERT INTO olala3w_constant VALUES('13','file_logo','/uploads/images/site/logo.png','Logo front-end','0','4');
INSERT INTO olala3w_constant VALUES('14','SMTP_secure','ssl','Sử dụng xác thực','1','0');
INSERT INTO olala3w_constant VALUES('15','SMTP_host','smtp.gmail.com','Máy chủ (SMTP) Thư gửi đi','1','0');
INSERT INTO olala3w_constant VALUES('16','SMTP_port','465','Cổng gửi mail','1','0');
INSERT INTO olala3w_constant VALUES('17','backup_auto','','Tự động sao lưu','2','0');
INSERT INTO olala3w_constant VALUES('18','backup_filetype','sql.gz','Định dạng lưu file CSDL','2','0');
INSERT INTO olala3w_constant VALUES('19','backup_filecount','5','Số file CSDL lưu lại','2','0');
INSERT INTO olala3w_constant VALUES('20','backup_email','olala.3w@gmail.com','Email nhận thông báo và file','2','0');
INSERT INTO olala3w_constant VALUES('21','SMTP_mailname','V.Startup','Tên tài khoản email','1','0');
INSERT INTO olala3w_constant VALUES('22','link_facebook','https://www.facebook.com','Facebook','5','1');
INSERT INTO olala3w_constant VALUES('23','link_googleplus','https://plus.google.com','Google+','5','2');
INSERT INTO olala3w_constant VALUES('24','link_twitter','https://twitter.com','Twitter','5','3');
INSERT INTO olala3w_constant VALUES('25','address_contact','Đà Nẵng, Việt Nam','Địa chỉ','0','11');
INSERT INTO olala3w_constant VALUES('73','script_bottom','<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?\'http\':\'https\';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+\'://platform.twitter.com/widgets.js\';fjs.parentNode.insertBefore(js,fjs);}}(document, \'script\', \'twitter-wjs\');</script>\r\n<script src=\"https://apis.google.com/js/platform.js\" async defer>\r\n  {lang: \'vi\'}\r\n</script>\r\n','Script cuối trang','4','7');
INSERT INTO olala3w_constant VALUES('26','content_registertry','','Email đăng ký học thử','13','17');
INSERT INTO olala3w_constant VALUES('27','author_google','','ID profile Google+','4','1');
INSERT INTO olala3w_constant VALUES('28','google_analytics','','Google analytics','4','4');
INSERT INTO olala3w_constant VALUES('29','chat_online','','Script Chat Online','4','5');
INSERT INTO olala3w_constant VALUES('30','english_test','','Kiểm tra tiếng Anh của bạn','13','18');
INSERT INTO olala3w_constant VALUES('31','google_calendar','','Google Calendar (Account)','4','3');
INSERT INTO olala3w_constant VALUES('32','help_address','killlllme@gmail.com,0974.779.085,huy.to.bsn,mr.killlllme','Tư vấn - Địa chỉ','13','8');
INSERT INTO olala3w_constant VALUES('33','help_icon','fa-envelope-o,fa-phone,fa-skype,fa-facebook','Tư vấn - Icon','13','9');
INSERT INTO olala3w_constant VALUES('34','link_youtube','https://www.youtube.com','Youtube','5','4');
INSERT INTO olala3w_constant VALUES('35','search_destination','Hà Nội,Đà Nẵng,Hồ Chí Minh,Phú Quốc,Nha Trang,Hạ Long,Đà Lạt,Phong Nha Kẻ Bàng,Côn đảo Vũng Tàu,Thái Lan,Singapore,Malaysia,Campuchia,Trung Quốc,Nhật Bản,Hàn Quốc,Hà Lan,Myanmar,Úc,Hong Kong,Philippines,Indonesia,Đài Loan,Châu Á,Châu Âu,Châu Mỹ,Châu Phi,Châu Úc','Điểm đến (Tìm kiếm tour)','13','8');
INSERT INTO olala3w_constant VALUES('36','search_day','1 Ngày,1 Ngày 1 Đêm,2 Ngày,2 Ngày 1 Đêm,3 Ngày,3 Ngày 2 Đêm,4 Ngày,4 Ngày 3 Đêm,5 Ngày,5 Ngày 4 Đêm,6 Ngày,6 Ngày 5 Đêm,7 Ngày,7 Ngày 6 Đêm,8 Ngày,8 Ngày 7 Đêm,9 Ngày,9 Ngày 8 Đêm,10 Ngày,10 Ngày 9 Đêm,11 Ngày,11 Ngày 10 Đêm,12 Ngày,12 Ngày 11 Đêm,1 Tuần,2 Tuần,3 Tuần,1 Tháng,2 Tháng,3 Tháng','Thời gian (Tìm kiếm tour)','13','9');
INSERT INTO olala3w_constant VALUES('75','fb_app_id','','Facebook App ID','4','2');
INSERT INTO olala3w_constant VALUES('77','upload_img_max_w','1900','Kích thước ảnh tối đa','6','1');
INSERT INTO olala3w_constant VALUES('78','upload_max_size','52428800','Dung lượng tối đa','6','2');
INSERT INTO olala3w_constant VALUES('79','upload_checking_mode','mild','Kiểu kiểm tra file tải lên','6','3');
INSERT INTO olala3w_constant VALUES('80','upload_type','1,4,5,6,7,8,9,10,11','Loại files cho phép','6','4');
INSERT INTO olala3w_constant VALUES('81','upload_ext','','Phần mở rộng bị cấm','6','5');
INSERT INTO olala3w_constant VALUES('82','upload_mime','','Loại mime bị cấm','6','6');
INSERT INTO olala3w_constant VALUES('83','upload_img_max_h','594','Kích thước ảnh tối đa','6','1');
INSERT INTO olala3w_constant VALUES('84','upload_auto_resize','1','Tự động resize ảnh','6','1');
INSERT INTO olala3w_constant VALUES('85','article_author','','Property = article:author','4','2');
INSERT INTO olala3w_constant VALUES('86','meta_author','V Startup','Meta author','0','4');
INSERT INTO olala3w_constant VALUES('88','meta_site_name','V Startup','Meta site name','0','5');
INSERT INTO olala3w_constant VALUES('89','meta_copyright','© Copyright 2017 V Startup','Meta copyright','0','6');
INSERT INTO olala3w_constant VALUES('90','image_thumbnailUrl','/uploads/images/site/V-Startup.jpg','Image : thumbnailUrl','0','7');
INSERT INTO olala3w_constant VALUES('91','skype_contact','','Skype','0','10');
INSERT INTO olala3w_constant VALUES('92','link_instagram','https://www.instagram.com','Instagram','5','6');

-- --------------------------------------------------------

CREATE TABLE `olala3w_contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `ip` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'fa-send-o',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_core_privilege` (
  `privilege_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL,
  `privilege_slug` varchar(50) NOT NULL,
  PRIMARY KEY (`privilege_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4805 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_privilege VALUES('2250','1','direction','direction_del');
INSERT INTO olala3w_core_privilege VALUES('2249','1','direction','direction_edit');
INSERT INTO olala3w_core_privilege VALUES('2248','1','direction','direction_add');
INSERT INTO olala3w_core_privilege VALUES('2255','1','pages','plugin_page_edit');
INSERT INTO olala3w_core_privilege VALUES('1071','1','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('1545','1','config','config_search');
INSERT INTO olala3w_core_privilege VALUES('1531','1','tool','tool_ipdie');
INSERT INTO olala3w_core_privilege VALUES('1530','1','tool','tool_keywords');
INSERT INTO olala3w_core_privilege VALUES('2656','1','bds_business','bds_business_del;50');
INSERT INTO olala3w_core_privilege VALUES('2103','2','product','product_menu_add;37');
INSERT INTO olala3w_core_privilege VALUES('2102','2','product','category_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2101','2','article','article_del;13');
INSERT INTO olala3w_core_privilege VALUES('2100','2','article','article_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2099','2','article','article_add;13');
INSERT INTO olala3w_core_privilege VALUES('2098','2','article','article_list;13');
INSERT INTO olala3w_core_privilege VALUES('2097','2','article','article_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('2096','2','article','article_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2095','2','article','article_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('2094','2','article','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2093','2','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('2092','2','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2091','2','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('2090','2','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('2089','2','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('2088','2','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2087','2','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('2086','2','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('273','2','gallery','gallery_menu_add;6');
INSERT INTO olala3w_core_privilege VALUES('274','2','gallery','gallery_menu_edit;6');
INSERT INTO olala3w_core_privilege VALUES('275','2','gallery','gallery_menu_del;6');
INSERT INTO olala3w_core_privilege VALUES('276','2','gallery','gallery_add;6');
INSERT INTO olala3w_core_privilege VALUES('277','2','gallery','gallery_edit;6');
INSERT INTO olala3w_core_privilege VALUES('278','2','gallery','gallery_del;6');
INSERT INTO olala3w_core_privilege VALUES('279','2','pages','pages_add');
INSERT INTO olala3w_core_privilege VALUES('280','2','pages','pages_edit');
INSERT INTO olala3w_core_privilege VALUES('281','2','pages','pages_del');
INSERT INTO olala3w_core_privilege VALUES('287','2','backup','backup_data');
INSERT INTO olala3w_core_privilege VALUES('288','2','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('289','2','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('290','2','config','config_search');
INSERT INTO olala3w_core_privilege VALUES('291','2','config','config_ipdie');
INSERT INTO olala3w_core_privilege VALUES('292','2','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('293','2','tool','tool_delete');
INSERT INTO olala3w_core_privilege VALUES('294','2','tool','tool_site');
INSERT INTO olala3w_core_privilege VALUES('295','2','tool','tool_keywords');
INSERT INTO olala3w_core_privilege VALUES('296','2','tool','tool_update');
INSERT INTO olala3w_core_privilege VALUES('330','2','core','core_mail');
INSERT INTO olala3w_core_privilege VALUES('2655','1','bds_business','bds_business_edit;50');
INSERT INTO olala3w_core_privilege VALUES('2654','1','bds_business','bds_business_add;50');
INSERT INTO olala3w_core_privilege VALUES('1070','1','backup','backup_data');
INSERT INTO olala3w_core_privilege VALUES('1544','1','config','config_socialnetwork');
INSERT INTO olala3w_core_privilege VALUES('1529','1','tool','tool_site');
INSERT INTO olala3w_core_privilege VALUES('1528','1','tool','tool_delete');
INSERT INTO olala3w_core_privilege VALUES('3333','1','core','core_dashboard');
INSERT INTO olala3w_core_privilege VALUES('2653','1','bds_business','bds_business_list;50');
INSERT INTO olala3w_core_privilege VALUES('3331','1','core','core_role');
INSERT INTO olala3w_core_privilege VALUES('1543','1','config','config_plugins');
INSERT INTO olala3w_core_privilege VALUES('3332','1','core','core_user');
INSERT INTO olala3w_core_privilege VALUES('2254','1','pages','plugin_page_add');
INSERT INTO olala3w_core_privilege VALUES('2252','1','street','street_edit');
INSERT INTO olala3w_core_privilege VALUES('2251','1','street','street_add');
INSERT INTO olala3w_core_privilege VALUES('2208','1','location','location_del;40');
INSERT INTO olala3w_core_privilege VALUES('2207','1','location','location_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2206','1','location','location_add;40');
INSERT INTO olala3w_core_privilege VALUES('2205','1','location','location_list;40');
INSERT INTO olala3w_core_privilege VALUES('2204','1','location','location_menu_del;40');
INSERT INTO olala3w_core_privilege VALUES('2203','1','location','location_menu_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2202','1','location','location_menu_add;40');
INSERT INTO olala3w_core_privilege VALUES('2201','1','location','category_edit;40');
INSERT INTO olala3w_core_privilege VALUES('4749','1','article','article_add;97');
INSERT INTO olala3w_core_privilege VALUES('1532','1','tool','tool_update');
INSERT INTO olala3w_core_privilege VALUES('1542','1','config','config_datetime');
INSERT INTO olala3w_core_privilege VALUES('1541','1','config','config_smtp');
INSERT INTO olala3w_core_privilege VALUES('1540','1','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('1546','1','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('2200','1','location','location_del;39');
INSERT INTO olala3w_core_privilege VALUES('2198','1','location','location_add;39');
INSERT INTO olala3w_core_privilege VALUES('2199','1','location','location_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2197','1','location','location_list;39');
INSERT INTO olala3w_core_privilege VALUES('2195','1','location','location_menu_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2196','1','location','location_menu_del;39');
INSERT INTO olala3w_core_privilege VALUES('2194','1','location','location_menu_add;39');
INSERT INTO olala3w_core_privilege VALUES('4748','1','article','article_list;97');
INSERT INTO olala3w_core_privilege VALUES('3983','1','tour','tour_del;70');
INSERT INTO olala3w_core_privilege VALUES('3982','1','tour','tour_edit;70');
INSERT INTO olala3w_core_privilege VALUES('3981','1','tour','tour_add;70');
INSERT INTO olala3w_core_privilege VALUES('3980','1','tour','tour_list;70');
INSERT INTO olala3w_core_privilege VALUES('3979','1','tour','tour_menu_del;70');
INSERT INTO olala3w_core_privilege VALUES('3978','1','tour','tour_menu_edit;70');
INSERT INTO olala3w_core_privilege VALUES('3977','1','tour','tour_menu_add;70');
INSERT INTO olala3w_core_privilege VALUES('3976','1','tour','category_edit;70');
INSERT INTO olala3w_core_privilege VALUES('1712','1','gift','gift_add;22');
INSERT INTO olala3w_core_privilege VALUES('1711','1','gift','gift_list;22');
INSERT INTO olala3w_core_privilege VALUES('1710','1','gift','gift_menu_del;22');
INSERT INTO olala3w_core_privilege VALUES('1709','1','gift','gift_menu_edit;22');
INSERT INTO olala3w_core_privilege VALUES('1708','1','gift','gift_menu_add;22');
INSERT INTO olala3w_core_privilege VALUES('1707','1','gift','category_edit;22');
INSERT INTO olala3w_core_privilege VALUES('3838','1','car','car_list;67');
INSERT INTO olala3w_core_privilege VALUES('3837','1','car','car_menu_del;67');
INSERT INTO olala3w_core_privilege VALUES('3836','1','car','car_menu_edit;67');
INSERT INTO olala3w_core_privilege VALUES('3835','1','car','car_menu_add;67');
INSERT INTO olala3w_core_privilege VALUES('3834','1','car','category_edit;67');
INSERT INTO olala3w_core_privilege VALUES('1713','1','gift','gift_edit;22');
INSERT INTO olala3w_core_privilege VALUES('1714','1','gift','gift_del;22');
INSERT INTO olala3w_core_privilege VALUES('2193','1','location','category_edit;39');
INSERT INTO olala3w_core_privilege VALUES('3328','1','info','sys_info_expansion');
INSERT INTO olala3w_core_privilege VALUES('3327','1','info','sys_info_site');
INSERT INTO olala3w_core_privilege VALUES('4747','1','article','article_menu_del;97');
INSERT INTO olala3w_core_privilege VALUES('2085','2','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('4647','1','product','product_del;9');
INSERT INTO olala3w_core_privilege VALUES('4646','1','product','product_edit;9');
INSERT INTO olala3w_core_privilege VALUES('4645','1','product','product_add;9');
INSERT INTO olala3w_core_privilege VALUES('2253','1','street','street_del');
INSERT INTO olala3w_core_privilege VALUES('2256','1','pages','plugin_page_del');
INSERT INTO olala3w_core_privilege VALUES('2290','1','road','road_add');
INSERT INTO olala3w_core_privilege VALUES('2291','1','road','road_edit');
INSERT INTO olala3w_core_privilege VALUES('2292','1','road','road_del');
INSERT INTO olala3w_core_privilege VALUES('2780','1','project','project_list;13');
INSERT INTO olala3w_core_privilege VALUES('2779','1','project','project_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('2778','1','project','project_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2777','1','project','project_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('2776','1','project','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3841','1','car','car_del;67');
INSERT INTO olala3w_core_privilege VALUES('3840','1','car','car_edit;67');
INSERT INTO olala3w_core_privilege VALUES('3839','1','car','car_add;67');
INSERT INTO olala3w_core_privilege VALUES('4027','1','document','document_add;73');
INSERT INTO olala3w_core_privilege VALUES('2652','1','bds_business','bds_business_menu_del;50');
INSERT INTO olala3w_core_privilege VALUES('2651','1','bds_business','bds_business_menu_edit;50');
INSERT INTO olala3w_core_privilege VALUES('2650','1','bds_business','bds_business_menu_add;50');
INSERT INTO olala3w_core_privilege VALUES('2649','1','bds_business','category_edit;50');
INSERT INTO olala3w_core_privilege VALUES('2781','1','project','project_add;13');
INSERT INTO olala3w_core_privilege VALUES('2782','1','project','project_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2783','1','project','project_del;13');
INSERT INTO olala3w_core_privilege VALUES('2784','1','project','category_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2785','1','project','project_menu_add;53');
INSERT INTO olala3w_core_privilege VALUES('2786','1','project','project_menu_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2787','1','project','project_menu_del;53');
INSERT INTO olala3w_core_privilege VALUES('2788','1','project','project_list;53');
INSERT INTO olala3w_core_privilege VALUES('2789','1','project','project_add;53');
INSERT INTO olala3w_core_privilege VALUES('2790','1','project','project_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2791','1','project','project_del;53');
INSERT INTO olala3w_core_privilege VALUES('2792','9','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('2793','9','product','product_list;37');
INSERT INTO olala3w_core_privilege VALUES('2794','9','product','product_add;37');
INSERT INTO olala3w_core_privilege VALUES('2795','9','product','product_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2796','9','product','product_del;37');
INSERT INTO olala3w_core_privilege VALUES('2797','11','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('2798','11','category','gallery_manager');
INSERT INTO olala3w_core_privilege VALUES('2799','11','category','project_manager');
INSERT INTO olala3w_core_privilege VALUES('2800','11','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('2801','11','category','location_manager');
INSERT INTO olala3w_core_privilege VALUES('2802','11','category','street_manager');
INSERT INTO olala3w_core_privilege VALUES('2803','11','category','road_manager');
INSERT INTO olala3w_core_privilege VALUES('2804','11','category','direction_manager');
INSERT INTO olala3w_core_privilege VALUES('2805','11','category','others_manager');
INSERT INTO olala3w_core_privilege VALUES('2806','11','category','plugin_page');
INSERT INTO olala3w_core_privilege VALUES('3031','11','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('3030','11','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2809','11','config','config_socialnetwork');
INSERT INTO olala3w_core_privilege VALUES('2815','11','pages','plugin_page_del');
INSERT INTO olala3w_core_privilege VALUES('2814','11','pages','plugin_page_edit');
INSERT INTO olala3w_core_privilege VALUES('2813','11','pages','plugin_page_add');
INSERT INTO olala3w_core_privilege VALUES('2816','1','prjname','prjname_add');
INSERT INTO olala3w_core_privilege VALUES('2817','1','prjname','prjname_edit');
INSERT INTO olala3w_core_privilege VALUES('2818','1','prjname','prjname_del');
INSERT INTO olala3w_core_privilege VALUES('2830','12','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('2831','12','category','gallery_manager');
INSERT INTO olala3w_core_privilege VALUES('2832','12','category','project_manager');
INSERT INTO olala3w_core_privilege VALUES('2833','12','category','product_manager');
INSERT INTO olala3w_core_privilege VALUES('2834','12','category','location_manager');
INSERT INTO olala3w_core_privilege VALUES('2835','12','category','road_manager');
INSERT INTO olala3w_core_privilege VALUES('2836','12','category','street_manager');
INSERT INTO olala3w_core_privilege VALUES('2837','12','category','direction_manager');
INSERT INTO olala3w_core_privilege VALUES('2838','12','category','prjname_manager');
INSERT INTO olala3w_core_privilege VALUES('2839','12','category','others_manager');
INSERT INTO olala3w_core_privilege VALUES('2840','12','category','plugin_page');
INSERT INTO olala3w_core_privilege VALUES('2841','12','pages','plugin_page_add');
INSERT INTO olala3w_core_privilege VALUES('2842','12','pages','plugin_page_edit');
INSERT INTO olala3w_core_privilege VALUES('2843','12','pages','plugin_page_del');
INSERT INTO olala3w_core_privilege VALUES('2908','12','article','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2909','12','article','article_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('2910','12','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2911','12','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('2912','12','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('2913','12','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('2914','12','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('2915','12','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('2916','12','article','category_edit;51');
INSERT INTO olala3w_core_privilege VALUES('2917','12','article','article_menu_add;51');
INSERT INTO olala3w_core_privilege VALUES('2918','12','article','article_menu_edit;51');
INSERT INTO olala3w_core_privilege VALUES('2919','12','article','article_menu_del;51');
INSERT INTO olala3w_core_privilege VALUES('2920','12','article','article_list;51');
INSERT INTO olala3w_core_privilege VALUES('2921','12','article','article_add;51');
INSERT INTO olala3w_core_privilege VALUES('2922','12','article','article_edit;51');
INSERT INTO olala3w_core_privilege VALUES('2923','12','article','article_del;51');
INSERT INTO olala3w_core_privilege VALUES('2924','12','article','category_edit;7');
INSERT INTO olala3w_core_privilege VALUES('2925','12','article','article_menu_add;7');
INSERT INTO olala3w_core_privilege VALUES('2926','12','article','article_menu_edit;7');
INSERT INTO olala3w_core_privilege VALUES('2927','12','article','article_menu_del;7');
INSERT INTO olala3w_core_privilege VALUES('2928','12','article','article_list;7');
INSERT INTO olala3w_core_privilege VALUES('2929','12','article','article_add;7');
INSERT INTO olala3w_core_privilege VALUES('2930','12','article','article_edit;7');
INSERT INTO olala3w_core_privilege VALUES('2931','12','article','article_del;7');
INSERT INTO olala3w_core_privilege VALUES('2932','12','project','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2933','12','project','project_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('2934','12','project','project_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2935','12','project','project_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('2936','12','project','project_list;13');
INSERT INTO olala3w_core_privilege VALUES('2937','12','project','project_add;13');
INSERT INTO olala3w_core_privilege VALUES('2938','12','project','project_edit;13');
INSERT INTO olala3w_core_privilege VALUES('2939','12','project','project_del;13');
INSERT INTO olala3w_core_privilege VALUES('2940','12','project','category_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2941','12','project','project_menu_add;53');
INSERT INTO olala3w_core_privilege VALUES('2942','12','project','project_menu_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2943','12','project','project_menu_del;53');
INSERT INTO olala3w_core_privilege VALUES('2944','12','project','project_list;53');
INSERT INTO olala3w_core_privilege VALUES('2945','12','project','project_add;53');
INSERT INTO olala3w_core_privilege VALUES('2946','12','project','project_edit;53');
INSERT INTO olala3w_core_privilege VALUES('2947','12','project','project_del;53');
INSERT INTO olala3w_core_privilege VALUES('2948','12','gallery','category_edit;4');
INSERT INTO olala3w_core_privilege VALUES('2949','12','gallery','gallery_menu_add;4');
INSERT INTO olala3w_core_privilege VALUES('2950','12','gallery','gallery_menu_edit;4');
INSERT INTO olala3w_core_privilege VALUES('2951','12','gallery','gallery_menu_del;4');
INSERT INTO olala3w_core_privilege VALUES('2952','12','gallery','gallery_list;4');
INSERT INTO olala3w_core_privilege VALUES('2953','12','gallery','gallery_add;4');
INSERT INTO olala3w_core_privilege VALUES('2954','12','gallery','gallery_edit;4');
INSERT INTO olala3w_core_privilege VALUES('2955','12','gallery','gallery_del;4');
INSERT INTO olala3w_core_privilege VALUES('2956','12','gallery','category_edit;52');
INSERT INTO olala3w_core_privilege VALUES('2957','12','gallery','gallery_menu_add;52');
INSERT INTO olala3w_core_privilege VALUES('2958','12','gallery','gallery_menu_edit;52');
INSERT INTO olala3w_core_privilege VALUES('2959','12','gallery','gallery_menu_del;52');
INSERT INTO olala3w_core_privilege VALUES('2960','12','gallery','gallery_list;52');
INSERT INTO olala3w_core_privilege VALUES('2961','12','gallery','gallery_add;52');
INSERT INTO olala3w_core_privilege VALUES('2962','12','gallery','gallery_edit;52');
INSERT INTO olala3w_core_privilege VALUES('2963','12','gallery','gallery_del;52');
INSERT INTO olala3w_core_privilege VALUES('2964','12','product','category_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2965','12','product','product_menu_add;37');
INSERT INTO olala3w_core_privilege VALUES('2966','12','product','product_menu_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2967','12','product','product_menu_del;37');
INSERT INTO olala3w_core_privilege VALUES('2968','12','product','product_list;37');
INSERT INTO olala3w_core_privilege VALUES('2969','12','product','product_add;37');
INSERT INTO olala3w_core_privilege VALUES('2970','12','product','product_edit;37');
INSERT INTO olala3w_core_privilege VALUES('2971','12','product','product_del;37');
INSERT INTO olala3w_core_privilege VALUES('2985','12','location','location_add;39');
INSERT INTO olala3w_core_privilege VALUES('2984','12','location','location_list;39');
INSERT INTO olala3w_core_privilege VALUES('2983','12','location','location_menu_del;39');
INSERT INTO olala3w_core_privilege VALUES('2982','12','location','location_menu_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2981','12','location','location_menu_add;39');
INSERT INTO olala3w_core_privilege VALUES('2980','12','location','category_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2986','12','location','location_edit;39');
INSERT INTO olala3w_core_privilege VALUES('2987','12','location','location_del;39');
INSERT INTO olala3w_core_privilege VALUES('2988','12','location','category_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2989','12','location','location_menu_add;40');
INSERT INTO olala3w_core_privilege VALUES('2990','12','location','location_menu_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2991','12','location','location_menu_del;40');
INSERT INTO olala3w_core_privilege VALUES('2992','12','location','location_list;40');
INSERT INTO olala3w_core_privilege VALUES('2993','12','location','location_add;40');
INSERT INTO olala3w_core_privilege VALUES('2994','12','location','location_edit;40');
INSERT INTO olala3w_core_privilege VALUES('2995','12','location','location_del;40');
INSERT INTO olala3w_core_privilege VALUES('2996','12','road','road_add');
INSERT INTO olala3w_core_privilege VALUES('2997','12','road','road_edit');
INSERT INTO olala3w_core_privilege VALUES('2998','12','road','road_del');
INSERT INTO olala3w_core_privilege VALUES('2999','12','street','street_add');
INSERT INTO olala3w_core_privilege VALUES('3000','12','street','street_edit');
INSERT INTO olala3w_core_privilege VALUES('3001','12','street','street_del');
INSERT INTO olala3w_core_privilege VALUES('3002','12','direction','direction_add');
INSERT INTO olala3w_core_privilege VALUES('3003','12','direction','direction_edit');
INSERT INTO olala3w_core_privilege VALUES('3004','12','direction','direction_del');
INSERT INTO olala3w_core_privilege VALUES('3005','12','prjname','prjname_add');
INSERT INTO olala3w_core_privilege VALUES('3006','12','prjname','prjname_edit');
INSERT INTO olala3w_core_privilege VALUES('3007','12','prjname','prjname_del');
INSERT INTO olala3w_core_privilege VALUES('3008','12','backup','backup_data');
INSERT INTO olala3w_core_privilege VALUES('3009','12','backup','backup_config');
INSERT INTO olala3w_core_privilege VALUES('3010','12','config','config_general');
INSERT INTO olala3w_core_privilege VALUES('3011','12','config','config_smtp');
INSERT INTO olala3w_core_privilege VALUES('3012','12','config','config_datetime');
INSERT INTO olala3w_core_privilege VALUES('3013','12','config','config_plugins');
INSERT INTO olala3w_core_privilege VALUES('3014','12','config','config_socialnetwork');
INSERT INTO olala3w_core_privilege VALUES('3015','12','config','config_search');
INSERT INTO olala3w_core_privilege VALUES('3016','12','config','config_upload');
INSERT INTO olala3w_core_privilege VALUES('3017','12','tool','tool_delete');
INSERT INTO olala3w_core_privilege VALUES('3018','12','tool','tool_site');
INSERT INTO olala3w_core_privilege VALUES('3019','12','tool','tool_keywords');
INSERT INTO olala3w_core_privilege VALUES('3020','12','tool','tool_ipdie');
INSERT INTO olala3w_core_privilege VALUES('3021','12','tool','tool_update');
INSERT INTO olala3w_core_privilege VALUES('3022','12','core','core_role');
INSERT INTO olala3w_core_privilege VALUES('3023','12','core','core_user');
INSERT INTO olala3w_core_privilege VALUES('3024','12','core','core_dashboard');
INSERT INTO olala3w_core_privilege VALUES('3025','12','core','core_mail');
INSERT INTO olala3w_core_privilege VALUES('3026','12','info','Info_diary');
INSERT INTO olala3w_core_privilege VALUES('3027','12','info','Info_php');
INSERT INTO olala3w_core_privilege VALUES('3028','12','info','Info_site');
INSERT INTO olala3w_core_privilege VALUES('3029','12','info','Info_expansion');
INSERT INTO olala3w_core_privilege VALUES('3032','11','article','article_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('3033','11','article','article_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('3034','11','article','article_list;9');
INSERT INTO olala3w_core_privilege VALUES('3035','11','article','article_add;9');
INSERT INTO olala3w_core_privilege VALUES('3036','11','article','article_edit;9');
INSERT INTO olala3w_core_privilege VALUES('3037','11','article','article_del;9');
INSERT INTO olala3w_core_privilege VALUES('3038','11','article','category_edit;51');
INSERT INTO olala3w_core_privilege VALUES('3039','11','article','article_menu_add;51');
INSERT INTO olala3w_core_privilege VALUES('3040','11','article','article_menu_edit;51');
INSERT INTO olala3w_core_privilege VALUES('3041','11','article','article_menu_del;51');
INSERT INTO olala3w_core_privilege VALUES('3042','11','article','article_list;51');
INSERT INTO olala3w_core_privilege VALUES('3043','11','article','article_add;51');
INSERT INTO olala3w_core_privilege VALUES('3044','11','article','article_edit;51');
INSERT INTO olala3w_core_privilege VALUES('3045','11','article','article_del;51');
INSERT INTO olala3w_core_privilege VALUES('3046','11','article','category_edit;7');
INSERT INTO olala3w_core_privilege VALUES('3047','11','article','article_menu_add;7');
INSERT INTO olala3w_core_privilege VALUES('3048','11','article','article_menu_edit;7');
INSERT INTO olala3w_core_privilege VALUES('3049','11','article','article_menu_del;7');
INSERT INTO olala3w_core_privilege VALUES('3050','11','article','article_list;7');
INSERT INTO olala3w_core_privilege VALUES('3051','11','article','article_add;7');
INSERT INTO olala3w_core_privilege VALUES('3052','11','article','article_edit;7');
INSERT INTO olala3w_core_privilege VALUES('3053','11','article','article_del;7');
INSERT INTO olala3w_core_privilege VALUES('3054','11','gallery','category_edit;4');
INSERT INTO olala3w_core_privilege VALUES('3055','11','gallery','gallery_menu_add;4');
INSERT INTO olala3w_core_privilege VALUES('3056','11','gallery','gallery_menu_edit;4');
INSERT INTO olala3w_core_privilege VALUES('3057','11','gallery','gallery_menu_del;4');
INSERT INTO olala3w_core_privilege VALUES('3058','11','gallery','gallery_list;4');
INSERT INTO olala3w_core_privilege VALUES('3059','11','gallery','gallery_add;4');
INSERT INTO olala3w_core_privilege VALUES('3060','11','gallery','gallery_edit;4');
INSERT INTO olala3w_core_privilege VALUES('3061','11','gallery','gallery_del;4');
INSERT INTO olala3w_core_privilege VALUES('3062','11','gallery','category_edit;52');
INSERT INTO olala3w_core_privilege VALUES('3063','11','gallery','gallery_menu_add;52');
INSERT INTO olala3w_core_privilege VALUES('3064','11','gallery','gallery_menu_edit;52');
INSERT INTO olala3w_core_privilege VALUES('3065','11','gallery','gallery_menu_del;52');
INSERT INTO olala3w_core_privilege VALUES('3066','11','gallery','gallery_list;52');
INSERT INTO olala3w_core_privilege VALUES('3067','11','gallery','gallery_add;52');
INSERT INTO olala3w_core_privilege VALUES('3068','11','gallery','gallery_edit;52');
INSERT INTO olala3w_core_privilege VALUES('3069','11','gallery','gallery_del;52');
INSERT INTO olala3w_core_privilege VALUES('3070','11','project','category_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3071','11','project','project_menu_add;13');
INSERT INTO olala3w_core_privilege VALUES('3072','11','project','project_menu_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3073','11','project','project_menu_del;13');
INSERT INTO olala3w_core_privilege VALUES('3074','11','project','project_list;13');
INSERT INTO olala3w_core_privilege VALUES('3075','11','project','project_add;13');
INSERT INTO olala3w_core_privilege VALUES('3076','11','project','project_edit;13');
INSERT INTO olala3w_core_privilege VALUES('3077','11','project','project_del;13');
INSERT INTO olala3w_core_privilege VALUES('3078','11','project','category_edit;53');
INSERT INTO olala3w_core_privilege VALUES('3079','11','project','project_menu_add;53');
INSERT INTO olala3w_core_privilege VALUES('3080','11','project','project_menu_edit;53');
INSERT INTO olala3w_core_privilege VALUES('3081','11','project','project_menu_del;53');
INSERT INTO olala3w_core_privilege VALUES('3082','11','project','project_list;53');
INSERT INTO olala3w_core_privilege VALUES('3083','11','project','project_add;53');
INSERT INTO olala3w_core_privilege VALUES('3084','11','project','project_edit;53');
INSERT INTO olala3w_core_privilege VALUES('3085','11','project','project_del;53');
INSERT INTO olala3w_core_privilege VALUES('3137','11','product','owner_real;37');
INSERT INTO olala3w_core_privilege VALUES('3136','11','product','product_del;37');
INSERT INTO olala3w_core_privilege VALUES('3135','11','product','product_edit;37');
INSERT INTO olala3w_core_privilege VALUES('3134','11','product','product_add;37');
INSERT INTO olala3w_core_privilege VALUES('4644','1','product','product_list;9');
INSERT INTO olala3w_core_privilege VALUES('4643','1','product','product_menu_del;9');
INSERT INTO olala3w_core_privilege VALUES('4642','1','product','product_menu_edit;9');
INSERT INTO olala3w_core_privilege VALUES('3133','11','product','product_list;37');
INSERT INTO olala3w_core_privilege VALUES('3138','11','product','owner_cus;37');
INSERT INTO olala3w_core_privilege VALUES('3326','1','info','sys_info_php');
INSERT INTO olala3w_core_privilege VALUES('3325','1','info','sys_info_diary');
INSERT INTO olala3w_core_privilege VALUES('3334','1','core','core_mail');
INSERT INTO olala3w_core_privilege VALUES('4796','1','gallery','gallery_list;102');
INSERT INTO olala3w_core_privilege VALUES('4795','1','gallery','gallery_menu_del;102');
INSERT INTO olala3w_core_privilege VALUES('4794','1','gallery','gallery_menu_edit;102');
INSERT INTO olala3w_core_privilege VALUES('4793','1','gallery','gallery_menu_add;102');
INSERT INTO olala3w_core_privilege VALUES('4792','1','gallery','category_edit;102');
INSERT INTO olala3w_core_privilege VALUES('4791','1','gallery','gallery_del;91');
INSERT INTO olala3w_core_privilege VALUES('4790','1','gallery','gallery_edit;91');
INSERT INTO olala3w_core_privilege VALUES('4789','1','gallery','gallery_add;91');
INSERT INTO olala3w_core_privilege VALUES('4788','1','gallery','gallery_list;91');
INSERT INTO olala3w_core_privilege VALUES('4787','1','gallery','gallery_menu_del;91');
INSERT INTO olala3w_core_privilege VALUES('4786','1','gallery','gallery_menu_edit;91');
INSERT INTO olala3w_core_privilege VALUES('4785','1','gallery','gallery_menu_add;91');
INSERT INTO olala3w_core_privilege VALUES('4784','1','gallery','category_edit;91');
INSERT INTO olala3w_core_privilege VALUES('4695','1','others','others_del;88');
INSERT INTO olala3w_core_privilege VALUES('4026','1','document','document_list;73');
INSERT INTO olala3w_core_privilege VALUES('4025','1','document','document_menu_del;73');
INSERT INTO olala3w_core_privilege VALUES('4024','1','document','document_menu_edit;73');
INSERT INTO olala3w_core_privilege VALUES('4023','1','document','document_menu_add;73');
INSERT INTO olala3w_core_privilege VALUES('4022','1','document','category_edit;73');
INSERT INTO olala3w_core_privilege VALUES('4028','1','document','document_edit;73');
INSERT INTO olala3w_core_privilege VALUES('4029','1','document','document_del;73');
INSERT INTO olala3w_core_privilege VALUES('4803','1','category','register_email');
INSERT INTO olala3w_core_privilege VALUES('4802','1','category','contact_list');
INSERT INTO olala3w_core_privilege VALUES('4641','1','product','product_menu_add;9');
INSERT INTO olala3w_core_privilege VALUES('4640','1','product','category_edit;9');
INSERT INTO olala3w_core_privilege VALUES('4655','1','product','product_del;93');
INSERT INTO olala3w_core_privilege VALUES('4654','1','product','product_edit;93');
INSERT INTO olala3w_core_privilege VALUES('4653','1','product','product_add;93');
INSERT INTO olala3w_core_privilege VALUES('4652','1','product','product_list;93');
INSERT INTO olala3w_core_privilege VALUES('4651','1','product','product_menu_del;93');
INSERT INTO olala3w_core_privilege VALUES('4650','1','product','product_menu_edit;93');
INSERT INTO olala3w_core_privilege VALUES('4649','1','product','product_menu_add;93');
INSERT INTO olala3w_core_privilege VALUES('4648','1','product','category_edit;93');
INSERT INTO olala3w_core_privilege VALUES('4746','1','article','article_menu_edit;97');
INSERT INTO olala3w_core_privilege VALUES('4745','1','article','article_menu_add;97');
INSERT INTO olala3w_core_privilege VALUES('4744','1','article','category_edit;97');
INSERT INTO olala3w_core_privilege VALUES('4743','1','article','article_del;99');
INSERT INTO olala3w_core_privilege VALUES('4742','1','article','article_edit;99');
INSERT INTO olala3w_core_privilege VALUES('4741','1','article','article_add;99');
INSERT INTO olala3w_core_privilege VALUES('4740','1','article','article_list;99');
INSERT INTO olala3w_core_privilege VALUES('4739','1','article','article_menu_del;99');
INSERT INTO olala3w_core_privilege VALUES('4738','1','article','article_menu_edit;99');
INSERT INTO olala3w_core_privilege VALUES('4694','1','others','others_edit;88');
INSERT INTO olala3w_core_privilege VALUES('4693','1','others','others_add;88');
INSERT INTO olala3w_core_privilege VALUES('4692','1','others','others_list;88');
INSERT INTO olala3w_core_privilege VALUES('4691','1','others','others_menu_del;88');
INSERT INTO olala3w_core_privilege VALUES('4690','1','others','others_menu_edit;88');
INSERT INTO olala3w_core_privilege VALUES('4689','1','others','others_menu_add;88');
INSERT INTO olala3w_core_privilege VALUES('4688','1','others','category_edit;88');
INSERT INTO olala3w_core_privilege VALUES('4687','1','others','others_del;95');
INSERT INTO olala3w_core_privilege VALUES('4686','1','others','others_edit;95');
INSERT INTO olala3w_core_privilege VALUES('4685','1','others','others_add;95');
INSERT INTO olala3w_core_privilege VALUES('4684','1','others','others_list;95');
INSERT INTO olala3w_core_privilege VALUES('4683','1','others','others_menu_del;95');
INSERT INTO olala3w_core_privilege VALUES('4682','1','others','others_menu_edit;95');
INSERT INTO olala3w_core_privilege VALUES('4681','1','others','others_menu_add;95');
INSERT INTO olala3w_core_privilege VALUES('4680','1','others','category_edit;95');
INSERT INTO olala3w_core_privilege VALUES('4801','1','category','gallery_manager');
INSERT INTO olala3w_core_privilege VALUES('4800','1','category','article_manager');
INSERT INTO olala3w_core_privilege VALUES('4737','1','article','article_menu_add;99');
INSERT INTO olala3w_core_privilege VALUES('4736','1','article','category_edit;99');
INSERT INTO olala3w_core_privilege VALUES('4735','1','article','article_del;100');
INSERT INTO olala3w_core_privilege VALUES('4734','1','article','article_edit;100');
INSERT INTO olala3w_core_privilege VALUES('4733','1','article','article_add;100');
INSERT INTO olala3w_core_privilege VALUES('4732','1','article','article_list;100');
INSERT INTO olala3w_core_privilege VALUES('4731','1','article','article_menu_del;100');
INSERT INTO olala3w_core_privilege VALUES('4730','1','article','article_menu_edit;100');
INSERT INTO olala3w_core_privilege VALUES('4729','1','article','article_menu_add;100');
INSERT INTO olala3w_core_privilege VALUES('4728','1','article','category_edit;100');
INSERT INTO olala3w_core_privilege VALUES('4750','1','article','article_edit;97');
INSERT INTO olala3w_core_privilege VALUES('4751','1','article','article_del;97');
INSERT INTO olala3w_core_privilege VALUES('4752','1','article','category_edit;94');
INSERT INTO olala3w_core_privilege VALUES('4753','1','article','article_menu_add;94');
INSERT INTO olala3w_core_privilege VALUES('4754','1','article','article_menu_edit;94');
INSERT INTO olala3w_core_privilege VALUES('4755','1','article','article_menu_del;94');
INSERT INTO olala3w_core_privilege VALUES('4756','1','article','article_list;94');
INSERT INTO olala3w_core_privilege VALUES('4757','1','article','article_add;94');
INSERT INTO olala3w_core_privilege VALUES('4758','1','article','article_edit;94');
INSERT INTO olala3w_core_privilege VALUES('4759','1','article','article_del;94');
INSERT INTO olala3w_core_privilege VALUES('4760','1','article','category_edit;98');
INSERT INTO olala3w_core_privilege VALUES('4761','1','article','article_menu_add;98');
INSERT INTO olala3w_core_privilege VALUES('4762','1','article','article_menu_edit;98');
INSERT INTO olala3w_core_privilege VALUES('4763','1','article','article_menu_del;98');
INSERT INTO olala3w_core_privilege VALUES('4764','1','article','article_list;98');
INSERT INTO olala3w_core_privilege VALUES('4765','1','article','article_add;98');
INSERT INTO olala3w_core_privilege VALUES('4766','1','article','article_edit;98');
INSERT INTO olala3w_core_privilege VALUES('4767','1','article','article_del;98');
INSERT INTO olala3w_core_privilege VALUES('4768','1','article','category_edit;89');
INSERT INTO olala3w_core_privilege VALUES('4769','1','article','article_menu_add;89');
INSERT INTO olala3w_core_privilege VALUES('4770','1','article','article_menu_edit;89');
INSERT INTO olala3w_core_privilege VALUES('4771','1','article','article_menu_del;89');
INSERT INTO olala3w_core_privilege VALUES('4772','1','article','article_list;89');
INSERT INTO olala3w_core_privilege VALUES('4773','1','article','article_add;89');
INSERT INTO olala3w_core_privilege VALUES('4774','1','article','article_edit;89');
INSERT INTO olala3w_core_privilege VALUES('4775','1','article','article_del;89');
INSERT INTO olala3w_core_privilege VALUES('4776','1','article','category_edit;90');
INSERT INTO olala3w_core_privilege VALUES('4777','1','article','article_menu_add;90');
INSERT INTO olala3w_core_privilege VALUES('4778','1','article','article_menu_edit;90');
INSERT INTO olala3w_core_privilege VALUES('4779','1','article','article_menu_del;90');
INSERT INTO olala3w_core_privilege VALUES('4780','1','article','article_list;90');
INSERT INTO olala3w_core_privilege VALUES('4781','1','article','article_add;90');
INSERT INTO olala3w_core_privilege VALUES('4782','1','article','article_edit;90');
INSERT INTO olala3w_core_privilege VALUES('4783','1','article','article_del;90');
INSERT INTO olala3w_core_privilege VALUES('4797','1','gallery','gallery_add;102');
INSERT INTO olala3w_core_privilege VALUES('4798','1','gallery','gallery_edit;102');
INSERT INTO olala3w_core_privilege VALUES('4799','1','gallery','gallery_del;102');
INSERT INTO olala3w_core_privilege VALUES('4804','1','category','plugin_page');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_role VALUES('1','Administrator','Nhóm quản trị tối cao','1','1441786254','1');
INSERT INTO olala3w_core_role VALUES('2','Tester','Nhóm kiểm thử','1','1441851198','1');
INSERT INTO olala3w_core_role VALUES('9','Broker','Nhân viên môi giới. Chỉ nhập và quản lý thông tin BĐS.','1','1439055844','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_core_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_name` varchar(16) NOT NULL,
  `password` varchar(50) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `gender` int(1) NOT NULL DEFAULT '0',
  `birthday` int(11) NOT NULL DEFAULT '0',
  `apply` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `is_show` int(1) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `vote` bigint(20) NOT NULL DEFAULT '1',
  `click_vote` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id_edit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_core_user VALUES('1','1','admin','57cbdda0f79feb7801f28be1b80f4ac5','Administrator','1','694198800','Quản trị website','huyto.qng@gmail.com','0974779085','Thanh Khê - Đà Nẵng','','1','1','u_1488926690_2c2fdf897700774ab341f6f703fc1514.png','1','1','1','1408159832','1488926690','1');
INSERT INTO olala3w_core_user VALUES('25','1','dev','35622d129658338262443a22a9c7bac5','Tô Thái Huy','1','-25200','','huyto.qng@gmail.com','0974779805','','','1','1','u_1437075987_ffbbbf570157f5aa239cf98d7caa354a.jpg','1','1','1','0','1452217860','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_direction` (
  `direction_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`direction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_document` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `release_date` int(11) NOT NULL DEFAULT '0',
  `effective_date` int(11) NOT NULL DEFAULT '0',
  `file` varchar(255) NOT NULL DEFAULT 'no',
  `type` varchar(5) NOT NULL DEFAULT 'unk',
  `size` int(11) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_document_menu` (
  `document_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL DEFAULT 'not-found',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_gallery` (
  `gallery_id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `upload_id` bigint(20) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gallery_id`)
) ENGINE=MyISAM AUTO_INCREMENT=669 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_gallery VALUES('648','85','Kết nối để thành công','ket-noi-de-thanh-cong-307hlexpzx','','','','ket-noi-de-thanh-cong-1497941402.jpg','1867','V. Starup chú trọng phát triển các nghành dịch vụ như nhà hàng, hostel, spa, cà phê, trung tâm thương mại, văn phòng cho thuê... nhằm mục đích đem đến cho khách hàng những trải nghiệm tốt nhất.','','','1','0','1','1496791800','1497941408','1');
INSERT INTO olala3w_gallery VALUES('647','85','Kết nối để thành công','ket-noi-de-thanh-cong-ud9d71exv6','','','','ket-noi-de-thanh-cong-1497941288.jpg','1866','V. Starup chú trọng phát triển các nghành dịch vụ như nhà hàng, hostel, spa, cà phê, trung tâm thương mại, văn phòng cho thuê... nhằm mục đích đem đến cho khách hàng những trải nghiệm tốt nhất.','','','1','0','1','1496793600','1497941304','1');
INSERT INTO olala3w_gallery VALUES('646','85','Kết nối để thành công','-no-','','','','ket-noi-de-thanh-cong-1496795497.jpg','1865','V. Starup chú trọng phát triển các nghành dịch vụ như nhà hàng, hostel, spa, cà phê, trung tâm thương mại, văn phòng cho thuê... nhằm mục đích đem đến cho khách hàng những trải nghiệm tốt nhất.','','','1','1','1','1496881800','1497932744','1');
INSERT INTO olala3w_gallery VALUES('649','85','Kết nối để thành công','ket-noi-de-thanh-cong-dj18v5z7v6','','','','ket-noi-de-thanh-cong-1496822145.jpg','1877','','','','1','1','1','1496822040','1496822185','1');
INSERT INTO olala3w_gallery VALUES('650','85','KẾT NỐI ĐỂ THÀNH CÔNG','ket-noi-de-thanh-cong-r5a8a39240','','','','ket-noi-de-thanh-cong-1496822290.jpg','1878','','','','1','1','1','1496822220','1496822321','1');
INSERT INTO olala3w_gallery VALUES('661','85','.','','','','','1497941619.jpg','1905','','','','1','0','1','1496992200','1497941625','1');
INSERT INTO olala3w_gallery VALUES('662','90','Khai Hoan Viet','khai-hoan-viet','','','','khai-hoan-viet-1497932159.png','1910','','','','1','0','1','1497932100','1497932293','1');
INSERT INTO olala3w_gallery VALUES('663','90','Tulip Restaurant','tulip-restaurant','','','','tulip-restaurant-1497932239.png','1911','','','','1','0','1','1497932160','1497932238','1');
INSERT INTO olala3w_gallery VALUES('664','90','VietA','vieta','','','','vieta-1497932275.png','1912','','','','1','0','1','1497932220','1497932274','1');
INSERT INTO olala3w_gallery VALUES('665','90','29/3','29-3','','','','29-3-1497932328.png','1913','','','','1','0','1','1497932280','1497932328','1');
INSERT INTO olala3w_gallery VALUES('666','90','F.home','f-home','','','','f-home-1497932387.png','1914','','','','1','0','1','1497932280','1497932384','1');
INSERT INTO olala3w_gallery VALUES('667','90','Hai Van Long','hai-van-long','','','','hai-van-long-1497932408.png','1915','','','','1','0','1','1497932340','1497932408','1');
INSERT INTO olala3w_gallery VALUES('668','90','Zen Diamond','zen-diamond','','','','zen-diamond-1497932460.png','1916','','','','1','0','1','1497932400','1497932460','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_gallery_menu` (
  `gallery_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `comment` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gallery_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_gallery_menu VALUES('85','91','Slide home','slide-home','','','','0','1','','1','0','no','1495835085','1495835085','1');
INSERT INTO olala3w_gallery_menu VALUES('90','102','Thành viên','thanh-vien','','','','0','1','','1','0','no','1496912438','1496912438','1');
INSERT INTO olala3w_gallery_menu VALUES('91','102','Đối tác','doi-tac','','','','0','2','','1','0','no','1496912446','1496912446','1');
INSERT INTO olala3w_gallery_menu VALUES('93','102','Khách hàng','khach-hang','','','','0','3','','1','0','no','1496912462','1496912462','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_gift` (
  `gift_id` int(11) NOT NULL AUTO_INCREMENT,
  `gift_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL DEFAULT '0',
  `made` varchar(255) NOT NULL,
  `material` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gift_id`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_gift_menu` (
  `gift_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gift_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=144 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_link` (
  `link_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL,
  `category` int(11) NOT NULL DEFAULT '0',
  `menu` int(11) NOT NULL DEFAULT '0',
  `post` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=433 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_link VALUES('1','san-pham-dich-vu','94','0','0','1496823783');
INSERT INTO olala3w_link VALUES('2','slider','91','0','0','0');
INSERT INTO olala3w_link VALUES('5','gioi-thieu','89','0','0','1496823589');
INSERT INTO olala3w_link VALUES('6','cong-ty-thanh-vien-lien-ket','90','0','0','1497944413');
INSERT INTO olala3w_link VALUES('265','thong-tin-nha-dau-tu','97','0','0','1496824299');
INSERT INTO olala3w_link VALUES('266','tin-tuc','98','0','0','1496824412');
INSERT INTO olala3w_link VALUES('269','slide-home','91','85','0','1495835085');
INSERT INTO olala3w_link VALUES('345','lien-he','0','0','0','0');
INSERT INTO olala3w_link VALUES('346','ve-chung-toi','89','446','0','1496992810');
INSERT INTO olala3w_link VALUES('347','v1-startup','90','447','0','1496820565');
INSERT INTO olala3w_link VALUES('348','v2-startup','90','448','0','1496820574');
INSERT INTO olala3w_link VALUES('349','phat-trien-du-an','94','449','0','1496780680');
INSERT INTO olala3w_link VALUES('350','linh-vuc-giao-duc','94','450','0','1496907311');
INSERT INTO olala3w_link VALUES('351','cong-nghe-thong-tin','94','451','0','1496780710');
INSERT INTO olala3w_link VALUES('352','thuong-mai-dich-vu','94','452','0','1496907291');
INSERT INTO olala3w_link VALUES('353','nha-dau-tu-01','97','453','0','1496820611');
INSERT INTO olala3w_link VALUES('354','nha-dau-tu-02','97','454','0','1496820621');
INSERT INTO olala3w_link VALUES('355','tin-hoat-dong','98','455','0','1496820737');
INSERT INTO olala3w_link VALUES('356','su-kien-noi-bat','98','456','0','1496820749');
INSERT INTO olala3w_link VALUES('357','blog','98','457','0','1496820766');
INSERT INTO olala3w_link VALUES('358','tuyen-dung','98','458','0','1496780800');
INSERT INTO olala3w_link VALUES('359','ket-noi-de-thanh-cong','91','85','646','1496822538');
INSERT INTO olala3w_link VALUES('360','ket-noi-de-thanh-cong-ud9d71exv6','91','85','647','1497941288');
INSERT INTO olala3w_link VALUES('361','ket-noi-de-thanh-cong-307hlexpzx','91','85','648','1497941402');
INSERT INTO olala3w_link VALUES('363','nhung-diem-den-khoi-goi-y-tuong-kinh-doanh-cho-startup','98','455','920','1496815975');
INSERT INTO olala3w_link VALUES('365','startup-gia-tri-nhat-dong-nam-a-chuan-bi-ipo-ty-usd','98','455','922','1496816185');
INSERT INTO olala3w_link VALUES('367','ly-do-asean-tro-thanh-mien-dat-hua-cho-linh-vuc-iot','98','455','924','1496816664');
INSERT INTO olala3w_link VALUES('369','so-do-to-chuc','89','460','0','1496820480');
INSERT INTO olala3w_link VALUES('370','ban-lanh-dao','89','461','0','1496820497');
INSERT INTO olala3w_link VALUES('371','co-hoi-nghe-nghiep','89','462','0','1496820536');
INSERT INTO olala3w_link VALUES('372','media','89','463','0','1496820546');
INSERT INTO olala3w_link VALUES('373','bao-cao-thuong-nien','97','464','0','1496820638');
INSERT INTO olala3w_link VALUES('374','cong-bo-thong-tin','97','465','0','1496820678');
INSERT INTO olala3w_link VALUES('375','gioi-thieu-chung','89','446','925','1497933281');
INSERT INTO olala3w_link VALUES('376','tam-nhin-su-menh-gia-tri','89','471','926','1497953997');
INSERT INTO olala3w_link VALUES('377','ket-noi-de-thanh-cong-dj18v5z7v6','91','85','649','1496822145');
INSERT INTO olala3w_link VALUES('378','ket-noi-de-thanh-cong-r5a8a39240','91','85','650','1496822290');
INSERT INTO olala3w_link VALUES('379','so-do-to-chuc-28qt137wop','89','460','927','1497925586');
INSERT INTO olala3w_link VALUES('380','ban-lanh-dao-l7ir9sx18n','89','461','928','1497954967');
INSERT INTO olala3w_link VALUES('382','phat-trien-du-an-jd5801gx44-w3pnl19pdu','94','469','0','1496995268');
INSERT INTO olala3w_link VALUES('383','thuong-mai-dich-vu-xaf62oxuea','94','450','930','1496907395');
INSERT INTO olala3w_link VALUES('384','cong-nghe-thong-tin-3ibnxi7zbo','94','451','931','1496906449');
INSERT INTO olala3w_link VALUES('385','giao-duc','94','452','932','1496907557');
INSERT INTO olala3w_link VALUES('386','van-hoa-doanh-nghiep-8dt94kyl83','89','472','933','1497924628');
INSERT INTO olala3w_link VALUES('387','du-an-tieu-bieu','94','467','0','1497943485');
INSERT INTO olala3w_link VALUES('389','to-hop-van-phong','94','467','934','1497942340');
INSERT INTO olala3w_link VALUES('390','khach-san','94','467','935','1497942468');
INSERT INTO olala3w_link VALUES('391','truong-mam-non','94','467','936','1497942117');
INSERT INTO olala3w_link VALUES('392','du-an-khu-phuc-hop','94','467','937','1497942087');
INSERT INTO olala3w_link VALUES('393','du-an-khach-san-5-sao-da-nang','94','467','938','1497942502');
INSERT INTO olala3w_link VALUES('394','phat-trien-du-an-jd5801gx44','94','469','0','1496911488');
INSERT INTO olala3w_link VALUES('395','thanh-vien','102','90','0','1496912438');
INSERT INTO olala3w_link VALUES('396','doi-tac','102','91','0','1496912446');
INSERT INTO olala3w_link VALUES('398','khach-hang','102','93','0','1496912462');
INSERT INTO olala3w_link VALUES('399','startup-cua-my-goi-von-thanh-cong-1-5-ty-usd','98','455','939','1496978069');
INSERT INTO olala3w_link VALUES('405','startup-viet-nhan-1-trieu-usd-tu-quy-dau-tu-cua-singapore','98','455','940','1496913509');
INSERT INTO olala3w_link VALUES('409','danaweb','0','0','0','0');
INSERT INTO olala3w_link VALUES('412','','91','85','661','1497941618');
INSERT INTO olala3w_link VALUES('413','thong-diep-hdqt','89','470','0','1496992953');
INSERT INTO olala3w_link VALUES('414','thong-diep-hdqt-x37swdp8b0','89','470','941','1497953493');
INSERT INTO olala3w_link VALUES('415','su-menh-tam-nhin-yvohic5frh','89','471','0','1497003551');
INSERT INTO olala3w_link VALUES('416','van-hoa-doanh-nghiep-d59owk39qi','89','472','0','1497003614');
INSERT INTO olala3w_link VALUES('418','khai-hoan-viet','102','90','662','1497932292');
INSERT INTO olala3w_link VALUES('419','tulip-restaurant','102','90','663','1497932238');
INSERT INTO olala3w_link VALUES('420','vieta','102','90','664','1497932275');
INSERT INTO olala3w_link VALUES('421','29-3','102','90','665','1497932328');
INSERT INTO olala3w_link VALUES('422','f-home','102','90','666','1497932386');
INSERT INTO olala3w_link VALUES('423','hai-van-long','102','90','667','1497932408');
INSERT INTO olala3w_link VALUES('424','zen-diamond','102','90','668','1497932460');
INSERT INTO olala3w_link VALUES('425','khai-hoan-viet-28x52apfzk','90','447','943','1497932806');
INSERT INTO olala3w_link VALUES('426','tulip-restaurant-rxzl7rp0be','90','447','944','1497943639');
INSERT INTO olala3w_link VALUES('427','viet-a','90','447','945','1497932733');
INSERT INTO olala3w_link VALUES('428','truong-mam-non-29-3','90','447','946','1497942973');
INSERT INTO olala3w_link VALUES('429','f-home-6jzrk99bzg','90','447','947','1497943270');
INSERT INTO olala3w_link VALUES('430','hai-van-long-rtsacu39fe','90','447','948','1497932675');
INSERT INTO olala3w_link VALUES('431','zen-diamond-g3qe7ipsu5','90','447','949','1497942997');
INSERT INTO olala3w_link VALUES('432','home','0','0','0','0');

-- --------------------------------------------------------

CREATE TABLE `olala3w_location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_location_menu` (
  `location_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_online` (
  `online_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `site` varchar(255) NOT NULL,
  `agent` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`online_id`)
) ENGINE=InnoDB AUTO_INCREMENT=383 DEFAULT CHARSET=latin1;

INSERT INTO olala3w_online VALUES('382','127.0.0.1','1500265807','url=olala-admin/js/highcharts/graphics/loader.white.gif','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','0');

-- --------------------------------------------------------

CREATE TABLE `olala3w_online_daily` (
  `online_daily_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`online_daily_id`)
) ENGINE=MyISAM AUTO_INCREMENT=668 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_online_daily VALUES('1','2014-08-18','3');
INSERT INTO olala3w_online_daily VALUES('2','2014-08-17','1');
INSERT INTO olala3w_online_daily VALUES('3','2014-08-14','102');
INSERT INTO olala3w_online_daily VALUES('4','2014-08-06','100');
INSERT INTO olala3w_online_daily VALUES('5','2014-08-16','3');
INSERT INTO olala3w_online_daily VALUES('6','2014-08-13','10');
INSERT INTO olala3w_online_daily VALUES('7','2014-08-11','40');
INSERT INTO olala3w_online_daily VALUES('8','2014-08-09','90');
INSERT INTO olala3w_online_daily VALUES('9','2014-08-15','82');
INSERT INTO olala3w_online_daily VALUES('10','2014-08-12','207');
INSERT INTO olala3w_online_daily VALUES('11','2014-08-10','10');
INSERT INTO olala3w_online_daily VALUES('12','2014-08-08','7');
INSERT INTO olala3w_online_daily VALUES('13','2014-08-07','13');
INSERT INTO olala3w_online_daily VALUES('14','2014-08-19','13');
INSERT INTO olala3w_online_daily VALUES('15','2014-08-20','9');
INSERT INTO olala3w_online_daily VALUES('16','2014-08-21','135');
INSERT INTO olala3w_online_daily VALUES('17','2014-08-22','5');
INSERT INTO olala3w_online_daily VALUES('18','2014-09-27','7');
INSERT INTO olala3w_online_daily VALUES('19','2014-09-28','16');
INSERT INTO olala3w_online_daily VALUES('20','2014-09-29','5');
INSERT INTO olala3w_online_daily VALUES('21','2014-09-30','14');
INSERT INTO olala3w_online_daily VALUES('22','2014-10-01','16');
INSERT INTO olala3w_online_daily VALUES('23','2014-10-02','12');
INSERT INTO olala3w_online_daily VALUES('24','2014-10-03','7');
INSERT INTO olala3w_online_daily VALUES('25','2014-10-04','1');
INSERT INTO olala3w_online_daily VALUES('26','2014-10-05','2');
INSERT INTO olala3w_online_daily VALUES('27','2014-10-07','4');
INSERT INTO olala3w_online_daily VALUES('28','2014-10-08','11');
INSERT INTO olala3w_online_daily VALUES('29','2014-10-14','1');
INSERT INTO olala3w_online_daily VALUES('30','2014-10-20','1');
INSERT INTO olala3w_online_daily VALUES('31','2014-10-26','4');
INSERT INTO olala3w_online_daily VALUES('32','2014-10-27','9');
INSERT INTO olala3w_online_daily VALUES('33','2014-10-28','11');
INSERT INTO olala3w_online_daily VALUES('34','2014-10-29','13');
INSERT INTO olala3w_online_daily VALUES('35','2014-10-30','10');
INSERT INTO olala3w_online_daily VALUES('36','2014-10-31','14');
INSERT INTO olala3w_online_daily VALUES('37','2014-11-01','8');
INSERT INTO olala3w_online_daily VALUES('38','2014-11-02','12');
INSERT INTO olala3w_online_daily VALUES('39','2014-11-03','2');
INSERT INTO olala3w_online_daily VALUES('40','2014-11-05','4');
INSERT INTO olala3w_online_daily VALUES('41','2014-11-06','2');
INSERT INTO olala3w_online_daily VALUES('42','2014-11-07','4');
INSERT INTO olala3w_online_daily VALUES('43','2014-11-08','1');
INSERT INTO olala3w_online_daily VALUES('44','2014-11-09','1');
INSERT INTO olala3w_online_daily VALUES('45','2014-11-10','11');
INSERT INTO olala3w_online_daily VALUES('46','2014-11-11','8');
INSERT INTO olala3w_online_daily VALUES('47','2014-11-12','3');
INSERT INTO olala3w_online_daily VALUES('48','2014-11-13','5');
INSERT INTO olala3w_online_daily VALUES('49','2014-11-14','6');
INSERT INTO olala3w_online_daily VALUES('50','2014-11-15','1');
INSERT INTO olala3w_online_daily VALUES('51','2014-11-16','1');
INSERT INTO olala3w_online_daily VALUES('52','2014-11-17','4');
INSERT INTO olala3w_online_daily VALUES('53','2014-11-18','1');
INSERT INTO olala3w_online_daily VALUES('54','2014-11-19','4');
INSERT INTO olala3w_online_daily VALUES('55','2014-11-20','1');
INSERT INTO olala3w_online_daily VALUES('56','2014-11-21','4');
INSERT INTO olala3w_online_daily VALUES('57','2014-11-22','1');
INSERT INTO olala3w_online_daily VALUES('58','2014-11-23','16');
INSERT INTO olala3w_online_daily VALUES('59','2014-11-24','1');
INSERT INTO olala3w_online_daily VALUES('60','2014-11-25','5');
INSERT INTO olala3w_online_daily VALUES('61','2014-11-27','15');
INSERT INTO olala3w_online_daily VALUES('62','2014-11-28','18');
INSERT INTO olala3w_online_daily VALUES('63','2014-11-29','10');
INSERT INTO olala3w_online_daily VALUES('64','2014-11-30','10');
INSERT INTO olala3w_online_daily VALUES('65','2014-12-01','6');
INSERT INTO olala3w_online_daily VALUES('66','2014-12-02','13');
INSERT INTO olala3w_online_daily VALUES('67','2014-12-03','9');
INSERT INTO olala3w_online_daily VALUES('68','2014-12-04','9');
INSERT INTO olala3w_online_daily VALUES('69','2014-12-05','7');
INSERT INTO olala3w_online_daily VALUES('70','2014-12-06','1');
INSERT INTO olala3w_online_daily VALUES('71','2014-12-08','5');
INSERT INTO olala3w_online_daily VALUES('72','2014-12-09','2');
INSERT INTO olala3w_online_daily VALUES('73','2014-12-10','5');
INSERT INTO olala3w_online_daily VALUES('74','2014-12-11','13');
INSERT INTO olala3w_online_daily VALUES('75','2014-12-12','4');
INSERT INTO olala3w_online_daily VALUES('76','2014-12-16','2');
INSERT INTO olala3w_online_daily VALUES('77','2014-12-20','11');
INSERT INTO olala3w_online_daily VALUES('78','2014-12-21','6');
INSERT INTO olala3w_online_daily VALUES('79','2014-12-22','5');
INSERT INTO olala3w_online_daily VALUES('80','2014-12-23','3');
INSERT INTO olala3w_online_daily VALUES('81','2014-12-24','1');
INSERT INTO olala3w_online_daily VALUES('82','2014-12-26','2');
INSERT INTO olala3w_online_daily VALUES('83','2014-12-27','10');
INSERT INTO olala3w_online_daily VALUES('84','0000-00-00','1');
INSERT INTO olala3w_online_daily VALUES('85','2014-12-28','15');
INSERT INTO olala3w_online_daily VALUES('86','2014-12-29','11');
INSERT INTO olala3w_online_daily VALUES('87','2014-12-30','1');
INSERT INTO olala3w_online_daily VALUES('88','2015-01-02','11');
INSERT INTO olala3w_online_daily VALUES('89','2015-01-03','4');
INSERT INTO olala3w_online_daily VALUES('90','2015-01-04','2');
INSERT INTO olala3w_online_daily VALUES('91','2015-01-05','9');
INSERT INTO olala3w_online_daily VALUES('92','2015-01-06','7');
INSERT INTO olala3w_online_daily VALUES('93','2015-01-07','1');
INSERT INTO olala3w_online_daily VALUES('94','2015-01-08','7');
INSERT INTO olala3w_online_daily VALUES('95','2015-01-09','13');
INSERT INTO olala3w_online_daily VALUES('96','2015-01-10','2');
INSERT INTO olala3w_online_daily VALUES('97','2015-01-12','1');
INSERT INTO olala3w_online_daily VALUES('98','2015-01-19','2');
INSERT INTO olala3w_online_daily VALUES('99','2015-01-20','12');
INSERT INTO olala3w_online_daily VALUES('100','2015-01-21','8');
INSERT INTO olala3w_online_daily VALUES('101','2015-01-22','43');
INSERT INTO olala3w_online_daily VALUES('102','2015-01-23','36');
INSERT INTO olala3w_online_daily VALUES('103','2015-01-24','34');
INSERT INTO olala3w_online_daily VALUES('104','2015-01-24','34');
INSERT INTO olala3w_online_daily VALUES('105','2015-01-25','46');
INSERT INTO olala3w_online_daily VALUES('106','2015-01-26','51');
INSERT INTO olala3w_online_daily VALUES('107','2015-01-27','53');
INSERT INTO olala3w_online_daily VALUES('108','2015-01-28','46');
INSERT INTO olala3w_online_daily VALUES('109','2015-01-29','471');
INSERT INTO olala3w_online_daily VALUES('110','2015-01-30','191');
INSERT INTO olala3w_online_daily VALUES('111','2015-01-31','106');
INSERT INTO olala3w_online_daily VALUES('112','2015-02-01','61');
INSERT INTO olala3w_online_daily VALUES('113','2015-02-02','37');
INSERT INTO olala3w_online_daily VALUES('114','2015-02-03','53');
INSERT INTO olala3w_online_daily VALUES('115','2015-02-04','66');
INSERT INTO olala3w_online_daily VALUES('116','2015-02-05','63');
INSERT INTO olala3w_online_daily VALUES('117','2015-02-06','86');
INSERT INTO olala3w_online_daily VALUES('118','2015-02-07','63');
INSERT INTO olala3w_online_daily VALUES('119','2015-02-08','68');
INSERT INTO olala3w_online_daily VALUES('120','2015-02-09','64');
INSERT INTO olala3w_online_daily VALUES('121','2015-02-10','46');
INSERT INTO olala3w_online_daily VALUES('122','2015-02-11','53');
INSERT INTO olala3w_online_daily VALUES('123','2015-02-12','28');
INSERT INTO olala3w_online_daily VALUES('124','2015-02-13','155');
INSERT INTO olala3w_online_daily VALUES('125','2015-02-14','43');
INSERT INTO olala3w_online_daily VALUES('126','2015-02-15','27');
INSERT INTO olala3w_online_daily VALUES('127','2015-02-16','22');
INSERT INTO olala3w_online_daily VALUES('128','2015-02-17','20');
INSERT INTO olala3w_online_daily VALUES('129','2015-02-18','19');
INSERT INTO olala3w_online_daily VALUES('130','2015-02-19','16');
INSERT INTO olala3w_online_daily VALUES('131','2015-02-20','18');
INSERT INTO olala3w_online_daily VALUES('132','2015-02-21','33');
INSERT INTO olala3w_online_daily VALUES('133','2015-02-22','31');
INSERT INTO olala3w_online_daily VALUES('134','2015-02-23','34');
INSERT INTO olala3w_online_daily VALUES('135','2015-02-24','22');
INSERT INTO olala3w_online_daily VALUES('136','2015-02-25','26');
INSERT INTO olala3w_online_daily VALUES('137','2015-02-26','34');
INSERT INTO olala3w_online_daily VALUES('138','2015-02-27','19');
INSERT INTO olala3w_online_daily VALUES('139','2015-02-28','5');
INSERT INTO olala3w_online_daily VALUES('140','2015-03-01','12');
INSERT INTO olala3w_online_daily VALUES('141','2015-03-02','24');
INSERT INTO olala3w_online_daily VALUES('142','2015-03-03','48');
INSERT INTO olala3w_online_daily VALUES('143','2015-03-04','49');
INSERT INTO olala3w_online_daily VALUES('144','2015-03-05','43');
INSERT INTO olala3w_online_daily VALUES('145','2015-03-06','33');
INSERT INTO olala3w_online_daily VALUES('146','2015-03-07','52');
INSERT INTO olala3w_online_daily VALUES('147','2015-03-08','26');
INSERT INTO olala3w_online_daily VALUES('148','2015-03-09','46');
INSERT INTO olala3w_online_daily VALUES('149','2015-03-10','37');
INSERT INTO olala3w_online_daily VALUES('150','2015-03-11','47');
INSERT INTO olala3w_online_daily VALUES('151','2015-03-12','33');
INSERT INTO olala3w_online_daily VALUES('152','2015-03-13','28');
INSERT INTO olala3w_online_daily VALUES('153','2015-03-14','2');
INSERT INTO olala3w_online_daily VALUES('154','2015-03-16','5');
INSERT INTO olala3w_online_daily VALUES('155','2015-03-17','18');
INSERT INTO olala3w_online_daily VALUES('156','2015-03-18','11');
INSERT INTO olala3w_online_daily VALUES('157','2015-03-19','21');
INSERT INTO olala3w_online_daily VALUES('158','2015-03-20','18');
INSERT INTO olala3w_online_daily VALUES('159','2015-03-21','3');
INSERT INTO olala3w_online_daily VALUES('160','2015-05-06','5');
INSERT INTO olala3w_online_daily VALUES('161','2015-05-07','4');
INSERT INTO olala3w_online_daily VALUES('162','2015-05-08','3');
INSERT INTO olala3w_online_daily VALUES('163','2015-05-09','2');
INSERT INTO olala3w_online_daily VALUES('164','2015-05-10','8');
INSERT INTO olala3w_online_daily VALUES('165','2015-05-11','3');
INSERT INTO olala3w_online_daily VALUES('166','2015-05-12','4');
INSERT INTO olala3w_online_daily VALUES('167','2015-05-15','1');
INSERT INTO olala3w_online_daily VALUES('168','2015-05-16','2');
INSERT INTO olala3w_online_daily VALUES('169','2015-05-17','2');
INSERT INTO olala3w_online_daily VALUES('170','2015-05-18','1');
INSERT INTO olala3w_online_daily VALUES('171','2015-05-19','3');
INSERT INTO olala3w_online_daily VALUES('172','2015-05-23','1');
INSERT INTO olala3w_online_daily VALUES('173','2015-05-24','1');
INSERT INTO olala3w_online_daily VALUES('174','2015-05-25','2');
INSERT INTO olala3w_online_daily VALUES('175','2015-05-26','2');
INSERT INTO olala3w_online_daily VALUES('176','2015-05-27','4');
INSERT INTO olala3w_online_daily VALUES('177','2015-05-28','4');
INSERT INTO olala3w_online_daily VALUES('178','2015-05-29','3');
INSERT INTO olala3w_online_daily VALUES('179','2015-05-31','3');
INSERT INTO olala3w_online_daily VALUES('180','2015-06-01','1');
INSERT INTO olala3w_online_daily VALUES('181','2015-06-02','2');
INSERT INTO olala3w_online_daily VALUES('182','2015-06-03','3');
INSERT INTO olala3w_online_daily VALUES('183','2015-06-04','3');
INSERT INTO olala3w_online_daily VALUES('184','2015-06-05','1');
INSERT INTO olala3w_online_daily VALUES('185','2015-06-06','1');
INSERT INTO olala3w_online_daily VALUES('186','2015-06-08','1');
INSERT INTO olala3w_online_daily VALUES('187','2015-06-09','2');
INSERT INTO olala3w_online_daily VALUES('188','2015-06-10','1');
INSERT INTO olala3w_online_daily VALUES('189','2015-06-11','2');
INSERT INTO olala3w_online_daily VALUES('190','2015-06-12','3');
INSERT INTO olala3w_online_daily VALUES('191','2015-06-13','2');
INSERT INTO olala3w_online_daily VALUES('192','2015-06-14','1');
INSERT INTO olala3w_online_daily VALUES('193','2015-06-15','4');
INSERT INTO olala3w_online_daily VALUES('194','2015-06-16','1');
INSERT INTO olala3w_online_daily VALUES('195','2015-06-17','1');
INSERT INTO olala3w_online_daily VALUES('196','2015-06-18','1');
INSERT INTO olala3w_online_daily VALUES('197','2015-06-21','1');
INSERT INTO olala3w_online_daily VALUES('198','2015-06-22','3');
INSERT INTO olala3w_online_daily VALUES('199','2015-06-23','1');
INSERT INTO olala3w_online_daily VALUES('200','2015-06-24','8');
INSERT INTO olala3w_online_daily VALUES('201','2015-06-28','1');
INSERT INTO olala3w_online_daily VALUES('202','2015-06-29','3');
INSERT INTO olala3w_online_daily VALUES('203','2015-06-30','4');
INSERT INTO olala3w_online_daily VALUES('204','2015-07-01','4');
INSERT INTO olala3w_online_daily VALUES('205','2015-07-02','3');
INSERT INTO olala3w_online_daily VALUES('206','2015-07-03','3');
INSERT INTO olala3w_online_daily VALUES('207','2015-07-06','1');
INSERT INTO olala3w_online_daily VALUES('208','2015-07-07','1');
INSERT INTO olala3w_online_daily VALUES('209','2015-07-12','4');
INSERT INTO olala3w_online_daily VALUES('210','2015-07-13','6');
INSERT INTO olala3w_online_daily VALUES('211','2015-07-14','29');
INSERT INTO olala3w_online_daily VALUES('212','2015-07-15','190');
INSERT INTO olala3w_online_daily VALUES('213','2015-07-16','361');
INSERT INTO olala3w_online_daily VALUES('214','2015-07-17','354');
INSERT INTO olala3w_online_daily VALUES('215','2015-07-18','238');
INSERT INTO olala3w_online_daily VALUES('216','2015-07-19','343');
INSERT INTO olala3w_online_daily VALUES('217','2015-07-20','802');
INSERT INTO olala3w_online_daily VALUES('218','2015-07-21','1926');
INSERT INTO olala3w_online_daily VALUES('219','2015-07-22','1349');
INSERT INTO olala3w_online_daily VALUES('220','2015-07-23','1648');
INSERT INTO olala3w_online_daily VALUES('221','2015-07-24','2370');
INSERT INTO olala3w_online_daily VALUES('222','2015-07-25','4986');
INSERT INTO olala3w_online_daily VALUES('223','2015-07-26','2251');
INSERT INTO olala3w_online_daily VALUES('224','2015-07-27','3882');
INSERT INTO olala3w_online_daily VALUES('225','2015-07-28','3496');
INSERT INTO olala3w_online_daily VALUES('226','2015-07-29','3603');
INSERT INTO olala3w_online_daily VALUES('227','2015-07-30','2778');
INSERT INTO olala3w_online_daily VALUES('228','2015-07-31','5');
INSERT INTO olala3w_online_daily VALUES('229','2015-08-01','2');
INSERT INTO olala3w_online_daily VALUES('230','2015-08-02','3');
INSERT INTO olala3w_online_daily VALUES('231','2015-08-03','2');
INSERT INTO olala3w_online_daily VALUES('232','2015-08-05','5');
INSERT INTO olala3w_online_daily VALUES('233','2015-08-06','1');
INSERT INTO olala3w_online_daily VALUES('234','2015-08-07','5');
INSERT INTO olala3w_online_daily VALUES('235','2015-08-08','8');
INSERT INTO olala3w_online_daily VALUES('236','2015-08-09','7');
INSERT INTO olala3w_online_daily VALUES('237','2015-08-10','6');
INSERT INTO olala3w_online_daily VALUES('238','2015-08-11','1');
INSERT INTO olala3w_online_daily VALUES('239','2015-08-12','2');
INSERT INTO olala3w_online_daily VALUES('240','2015-08-13','3');
INSERT INTO olala3w_online_daily VALUES('241','2015-08-14','1');
INSERT INTO olala3w_online_daily VALUES('242','2015-08-16','2');
INSERT INTO olala3w_online_daily VALUES('243','2015-08-17','2');
INSERT INTO olala3w_online_daily VALUES('244','2015-08-18','1');
INSERT INTO olala3w_online_daily VALUES('245','2015-08-28','2');
INSERT INTO olala3w_online_daily VALUES('246','2015-08-29','1');
INSERT INTO olala3w_online_daily VALUES('247','2015-08-30','1');
INSERT INTO olala3w_online_daily VALUES('248','2015-08-31','3');
INSERT INTO olala3w_online_daily VALUES('249','2015-09-01','1');
INSERT INTO olala3w_online_daily VALUES('250','2015-09-04','1');
INSERT INTO olala3w_online_daily VALUES('251','2015-09-05','1');
INSERT INTO olala3w_online_daily VALUES('252','2015-09-06','1');
INSERT INTO olala3w_online_daily VALUES('253','2015-09-07','1');
INSERT INTO olala3w_online_daily VALUES('254','2015-09-08','1');
INSERT INTO olala3w_online_daily VALUES('255','2015-09-09','3');
INSERT INTO olala3w_online_daily VALUES('256','2015-09-10','3');
INSERT INTO olala3w_online_daily VALUES('257','2015-09-11','2');
INSERT INTO olala3w_online_daily VALUES('258','2015-09-17','1');
INSERT INTO olala3w_online_daily VALUES('259','2015-09-27','3');
INSERT INTO olala3w_online_daily VALUES('260','2015-09-28','2');
INSERT INTO olala3w_online_daily VALUES('261','2015-10-19','1');
INSERT INTO olala3w_online_daily VALUES('262','2015-10-20','4');
INSERT INTO olala3w_online_daily VALUES('263','2015-10-21','1');
INSERT INTO olala3w_online_daily VALUES('264','2015-10-24','1');
INSERT INTO olala3w_online_daily VALUES('265','2015-10-25','5');
INSERT INTO olala3w_online_daily VALUES('266','2015-10-26','22');
INSERT INTO olala3w_online_daily VALUES('267','2015-10-27','36');
INSERT INTO olala3w_online_daily VALUES('268','2015-11-10','1');
INSERT INTO olala3w_online_daily VALUES('269','2015-11-11','3');
INSERT INTO olala3w_online_daily VALUES('270','2015-11-12','22');
INSERT INTO olala3w_online_daily VALUES('271','2015-11-13','45');
INSERT INTO olala3w_online_daily VALUES('272','2015-11-14','9');
INSERT INTO olala3w_online_daily VALUES('273','2015-11-15','27');
INSERT INTO olala3w_online_daily VALUES('274','2015-11-16','36');
INSERT INTO olala3w_online_daily VALUES('275','2015-11-17','24');
INSERT INTO olala3w_online_daily VALUES('276','2015-11-18','10');
INSERT INTO olala3w_online_daily VALUES('277','2015-11-19','14');
INSERT INTO olala3w_online_daily VALUES('278','2015-11-20','7');
INSERT INTO olala3w_online_daily VALUES('279','2015-11-21','5');
INSERT INTO olala3w_online_daily VALUES('280','2015-11-22','1');
INSERT INTO olala3w_online_daily VALUES('281','2015-11-23','12');
INSERT INTO olala3w_online_daily VALUES('282','2015-11-24','5');
INSERT INTO olala3w_online_daily VALUES('283','2015-11-27','1');
INSERT INTO olala3w_online_daily VALUES('284','2015-11-28','2');
INSERT INTO olala3w_online_daily VALUES('285','2015-11-29','1');
INSERT INTO olala3w_online_daily VALUES('286','2015-11-30','4');
INSERT INTO olala3w_online_daily VALUES('287','2015-12-01','38');
INSERT INTO olala3w_online_daily VALUES('288','2015-12-02','34');
INSERT INTO olala3w_online_daily VALUES('289','2015-12-03','41');
INSERT INTO olala3w_online_daily VALUES('290','2015-12-04','34');
INSERT INTO olala3w_online_daily VALUES('291','2015-12-09','1');
INSERT INTO olala3w_online_daily VALUES('292','2015-12-19','1');
INSERT INTO olala3w_online_daily VALUES('293','2015-12-20','2');
INSERT INTO olala3w_online_daily VALUES('294','2015-12-21','7');
INSERT INTO olala3w_online_daily VALUES('295','2015-12-22','5');
INSERT INTO olala3w_online_daily VALUES('296','2015-12-23','52');
INSERT INTO olala3w_online_daily VALUES('297','2015-12-24','37');
INSERT INTO olala3w_online_daily VALUES('298','2015-12-25','39');
INSERT INTO olala3w_online_daily VALUES('299','2015-12-26','13');
INSERT INTO olala3w_online_daily VALUES('300','2015-12-27','2');
INSERT INTO olala3w_online_daily VALUES('301','2015-12-28','18');
INSERT INTO olala3w_online_daily VALUES('302','2015-12-29','9');
INSERT INTO olala3w_online_daily VALUES('303','2015-12-30','16');
INSERT INTO olala3w_online_daily VALUES('304','2015-12-31','6');
INSERT INTO olala3w_online_daily VALUES('305','2016-01-07','3');
INSERT INTO olala3w_online_daily VALUES('306','2016-01-08','3');
INSERT INTO olala3w_online_daily VALUES('307','2016-01-09','7');
INSERT INTO olala3w_online_daily VALUES('308','2016-01-10','1');
INSERT INTO olala3w_online_daily VALUES('309','2016-01-12','7');
INSERT INTO olala3w_online_daily VALUES('310','2016-01-13','4');
INSERT INTO olala3w_online_daily VALUES('311','2016-01-14','4');
INSERT INTO olala3w_online_daily VALUES('312','2016-01-15','14');
INSERT INTO olala3w_online_daily VALUES('313','2016-01-16','66');
INSERT INTO olala3w_online_daily VALUES('314','2016-01-17','45');
INSERT INTO olala3w_online_daily VALUES('315','2016-01-18','31');
INSERT INTO olala3w_online_daily VALUES('316','2016-01-19','7');
INSERT INTO olala3w_online_daily VALUES('317','2016-01-20','12');
INSERT INTO olala3w_online_daily VALUES('318','2016-01-21','5');
INSERT INTO olala3w_online_daily VALUES('319','2016-01-22','7');
INSERT INTO olala3w_online_daily VALUES('320','2016-01-23','4');
INSERT INTO olala3w_online_daily VALUES('321','2016-01-24','1');
INSERT INTO olala3w_online_daily VALUES('322','2016-01-25','25');
INSERT INTO olala3w_online_daily VALUES('323','2016-01-26','1');
INSERT INTO olala3w_online_daily VALUES('324','2016-01-27','11');
INSERT INTO olala3w_online_daily VALUES('325','2016-01-28','40');
INSERT INTO olala3w_online_daily VALUES('326','2016-01-29','35');
INSERT INTO olala3w_online_daily VALUES('327','2016-01-30','6');
INSERT INTO olala3w_online_daily VALUES('328','2016-02-01','14');
INSERT INTO olala3w_online_daily VALUES('329','2016-02-02','40');
INSERT INTO olala3w_online_daily VALUES('330','2016-02-03','163');
INSERT INTO olala3w_online_daily VALUES('331','2016-02-04','81');
INSERT INTO olala3w_online_daily VALUES('332','2016-02-05','63');
INSERT INTO olala3w_online_daily VALUES('333','2016-02-06','52');
INSERT INTO olala3w_online_daily VALUES('334','2016-02-07','38');
INSERT INTO olala3w_online_daily VALUES('335','2016-02-08','35');
INSERT INTO olala3w_online_daily VALUES('336','2016-02-09','48');
INSERT INTO olala3w_online_daily VALUES('337','2016-02-10','39');
INSERT INTO olala3w_online_daily VALUES('338','2016-02-11','34');
INSERT INTO olala3w_online_daily VALUES('339','2016-02-12','74');
INSERT INTO olala3w_online_daily VALUES('340','2016-02-13','56');
INSERT INTO olala3w_online_daily VALUES('341','2016-02-14','60');
INSERT INTO olala3w_online_daily VALUES('342','2016-02-15','104');
INSERT INTO olala3w_online_daily VALUES('343','2016-02-16','59');
INSERT INTO olala3w_online_daily VALUES('344','2016-02-17','58');
INSERT INTO olala3w_online_daily VALUES('345','2016-02-18','43');
INSERT INTO olala3w_online_daily VALUES('346','2016-02-19','2');
INSERT INTO olala3w_online_daily VALUES('347','2016-02-20','2');
INSERT INTO olala3w_online_daily VALUES('348','2016-02-22','3');
INSERT INTO olala3w_online_daily VALUES('349','2016-03-01','1');
INSERT INTO olala3w_online_daily VALUES('350','2016-03-04','3');
INSERT INTO olala3w_online_daily VALUES('351','2016-03-04','3');
INSERT INTO olala3w_online_daily VALUES('352','2016-03-07','1');
INSERT INTO olala3w_online_daily VALUES('353','2016-03-08','1');
INSERT INTO olala3w_online_daily VALUES('354','2016-03-09','14');
INSERT INTO olala3w_online_daily VALUES('355','2016-03-10','5');
INSERT INTO olala3w_online_daily VALUES('356','2016-03-11','6');
INSERT INTO olala3w_online_daily VALUES('357','2016-03-13','2');
INSERT INTO olala3w_online_daily VALUES('358','2016-03-14','1');
INSERT INTO olala3w_online_daily VALUES('359','2016-03-20','1');
INSERT INTO olala3w_online_daily VALUES('360','2016-03-26','8');
INSERT INTO olala3w_online_daily VALUES('361','2016-03-27','8');
INSERT INTO olala3w_online_daily VALUES('362','2016-03-28','46');
INSERT INTO olala3w_online_daily VALUES('363','2016-03-29','1');
INSERT INTO olala3w_online_daily VALUES('364','2016-03-30','11');
INSERT INTO olala3w_online_daily VALUES('365','2016-03-31','2');
INSERT INTO olala3w_online_daily VALUES('366','2016-04-02','1');
INSERT INTO olala3w_online_daily VALUES('367','2016-04-03','5');
INSERT INTO olala3w_online_daily VALUES('368','2016-04-04','10');
INSERT INTO olala3w_online_daily VALUES('369','2016-04-05','31');
INSERT INTO olala3w_online_daily VALUES('370','2016-04-06','65');
INSERT INTO olala3w_online_daily VALUES('371','2016-04-07','35');
INSERT INTO olala3w_online_daily VALUES('372','2016-04-08','15');
INSERT INTO olala3w_online_daily VALUES('373','2016-04-09','1');
INSERT INTO olala3w_online_daily VALUES('374','2016-04-20','2');
INSERT INTO olala3w_online_daily VALUES('375','2016-04-22','2');
INSERT INTO olala3w_online_daily VALUES('376','2016-04-23','7');
INSERT INTO olala3w_online_daily VALUES('377','2016-04-24','8');
INSERT INTO olala3w_online_daily VALUES('378','2016-04-25','1');
INSERT INTO olala3w_online_daily VALUES('379','2016-04-26','2');
INSERT INTO olala3w_online_daily VALUES('380','2016-04-27','4');
INSERT INTO olala3w_online_daily VALUES('381','2016-04-28','3');
INSERT INTO olala3w_online_daily VALUES('382','2016-05-05','1');
INSERT INTO olala3w_online_daily VALUES('383','2016-05-08','9');
INSERT INTO olala3w_online_daily VALUES('384','2016-05-09','3');
INSERT INTO olala3w_online_daily VALUES('385','2016-05-10','2');
INSERT INTO olala3w_online_daily VALUES('386','2016-05-11','5');
INSERT INTO olala3w_online_daily VALUES('387','2016-05-12','6');
INSERT INTO olala3w_online_daily VALUES('388','2016-05-13','11');
INSERT INTO olala3w_online_daily VALUES('389','2016-05-15','3');
INSERT INTO olala3w_online_daily VALUES('390','2016-05-16','8');
INSERT INTO olala3w_online_daily VALUES('391','2016-05-17','7');
INSERT INTO olala3w_online_daily VALUES('392','2016-05-19','3');
INSERT INTO olala3w_online_daily VALUES('393','2016-05-19','3');
INSERT INTO olala3w_online_daily VALUES('394','2016-05-20','2');
INSERT INTO olala3w_online_daily VALUES('395','2016-05-22','5');
INSERT INTO olala3w_online_daily VALUES('396','2016-05-23','1');
INSERT INTO olala3w_online_daily VALUES('397','2016-05-24','1');
INSERT INTO olala3w_online_daily VALUES('398','2016-05-30','5');
INSERT INTO olala3w_online_daily VALUES('399','2016-06-16','1');
INSERT INTO olala3w_online_daily VALUES('400','2016-06-24','5');
INSERT INTO olala3w_online_daily VALUES('401','2016-06-25','12');
INSERT INTO olala3w_online_daily VALUES('402','2016-06-26','5');
INSERT INTO olala3w_online_daily VALUES('403','2016-08-08','6');
INSERT INTO olala3w_online_daily VALUES('404','2016-08-09','4');
INSERT INTO olala3w_online_daily VALUES('405','2016-08-10','5');
INSERT INTO olala3w_online_daily VALUES('406','2016-08-11','2');
INSERT INTO olala3w_online_daily VALUES('407','2016-08-12','6');
INSERT INTO olala3w_online_daily VALUES('408','2016-08-14','1');
INSERT INTO olala3w_online_daily VALUES('409','2016-08-16','12');
INSERT INTO olala3w_online_daily VALUES('410','2016-08-17','39');
INSERT INTO olala3w_online_daily VALUES('411','2016-08-18','157');
INSERT INTO olala3w_online_daily VALUES('412','2016-08-19','196');
INSERT INTO olala3w_online_daily VALUES('413','2016-08-20','227');
INSERT INTO olala3w_online_daily VALUES('414','2016-08-21','190');
INSERT INTO olala3w_online_daily VALUES('415','2016-08-22','545');
INSERT INTO olala3w_online_daily VALUES('416','2016-08-23','367');
INSERT INTO olala3w_online_daily VALUES('417','2016-08-24','369');
INSERT INTO olala3w_online_daily VALUES('418','2016-08-25','418');
INSERT INTO olala3w_online_daily VALUES('419','2016-08-26','512');
INSERT INTO olala3w_online_daily VALUES('420','2016-08-27','614');
INSERT INTO olala3w_online_daily VALUES('421','2016-08-28','631');
INSERT INTO olala3w_online_daily VALUES('422','2016-08-29','728');
INSERT INTO olala3w_online_daily VALUES('423','2016-08-30','579');
INSERT INTO olala3w_online_daily VALUES('424','2016-08-31','333');
INSERT INTO olala3w_online_daily VALUES('425','2016-09-01','219');
INSERT INTO olala3w_online_daily VALUES('426','2016-09-02','108');
INSERT INTO olala3w_online_daily VALUES('427','2016-09-03','157');
INSERT INTO olala3w_online_daily VALUES('428','2016-09-04','156');
INSERT INTO olala3w_online_daily VALUES('429','2016-09-05','662');
INSERT INTO olala3w_online_daily VALUES('430','2016-09-06','744');
INSERT INTO olala3w_online_daily VALUES('431','2016-09-07','504');
INSERT INTO olala3w_online_daily VALUES('432','2016-09-08','571');
INSERT INTO olala3w_online_daily VALUES('433','2016-09-09','516');
INSERT INTO olala3w_online_daily VALUES('434','2016-09-10','484');
INSERT INTO olala3w_online_daily VALUES('435','2016-09-11','384');
INSERT INTO olala3w_online_daily VALUES('436','2016-09-12','332');
INSERT INTO olala3w_online_daily VALUES('437','2016-09-13','371');
INSERT INTO olala3w_online_daily VALUES('438','2016-09-14','338');
INSERT INTO olala3w_online_daily VALUES('439','2016-09-15','366');
INSERT INTO olala3w_online_daily VALUES('440','2016-09-16','536');
INSERT INTO olala3w_online_daily VALUES('441','2016-09-17','345');
INSERT INTO olala3w_online_daily VALUES('442','2016-09-18','363');
INSERT INTO olala3w_online_daily VALUES('443','2016-09-19','354');
INSERT INTO olala3w_online_daily VALUES('444','2016-09-20','359');
INSERT INTO olala3w_online_daily VALUES('445','2016-09-21','471');
INSERT INTO olala3w_online_daily VALUES('446','2016-09-22','405');
INSERT INTO olala3w_online_daily VALUES('447','2016-09-23','460');
INSERT INTO olala3w_online_daily VALUES('448','2016-09-24','461');
INSERT INTO olala3w_online_daily VALUES('449','2016-09-25','426');
INSERT INTO olala3w_online_daily VALUES('450','2016-09-26','432');
INSERT INTO olala3w_online_daily VALUES('451','2016-09-27','447');
INSERT INTO olala3w_online_daily VALUES('452','2016-09-28','324');
INSERT INTO olala3w_online_daily VALUES('453','2016-09-29','167');
INSERT INTO olala3w_online_daily VALUES('454','2016-09-30','265');
INSERT INTO olala3w_online_daily VALUES('455','2016-10-01','334');
INSERT INTO olala3w_online_daily VALUES('456','2016-10-02','272');
INSERT INTO olala3w_online_daily VALUES('457','2016-10-03','217');
INSERT INTO olala3w_online_daily VALUES('458','2016-10-04','214');
INSERT INTO olala3w_online_daily VALUES('459','2016-10-05','367');
INSERT INTO olala3w_online_daily VALUES('460','2016-10-06','462');
INSERT INTO olala3w_online_daily VALUES('461','2016-10-07','394');
INSERT INTO olala3w_online_daily VALUES('462','2016-10-08','321');
INSERT INTO olala3w_online_daily VALUES('463','2016-10-09','247');
INSERT INTO olala3w_online_daily VALUES('464','2016-10-10','268');
INSERT INTO olala3w_online_daily VALUES('465','2016-10-11','348');
INSERT INTO olala3w_online_daily VALUES('466','2016-10-12','471');
INSERT INTO olala3w_online_daily VALUES('467','2016-10-13','451');
INSERT INTO olala3w_online_daily VALUES('468','2016-10-14','502');
INSERT INTO olala3w_online_daily VALUES('469','2016-10-15','300');
INSERT INTO olala3w_online_daily VALUES('470','2016-10-16','228');
INSERT INTO olala3w_online_daily VALUES('471','2016-10-17','234');
INSERT INTO olala3w_online_daily VALUES('472','2016-10-18','272');
INSERT INTO olala3w_online_daily VALUES('473','2016-10-19','276');
INSERT INTO olala3w_online_daily VALUES('474','2016-10-20','366');
INSERT INTO olala3w_online_daily VALUES('475','2016-10-21','205');
INSERT INTO olala3w_online_daily VALUES('476','2016-10-22','228');
INSERT INTO olala3w_online_daily VALUES('477','2016-10-23','304');
INSERT INTO olala3w_online_daily VALUES('478','2016-10-24','286');
INSERT INTO olala3w_online_daily VALUES('479','2016-10-25','383');
INSERT INTO olala3w_online_daily VALUES('480','2016-10-26','338');
INSERT INTO olala3w_online_daily VALUES('481','2016-10-27','249');
INSERT INTO olala3w_online_daily VALUES('482','2016-10-28','295');
INSERT INTO olala3w_online_daily VALUES('483','2016-10-29','542');
INSERT INTO olala3w_online_daily VALUES('484','2016-10-30','468');
INSERT INTO olala3w_online_daily VALUES('485','2016-10-31','473');
INSERT INTO olala3w_online_daily VALUES('486','2016-11-01','300');
INSERT INTO olala3w_online_daily VALUES('487','2016-11-02','263');
INSERT INTO olala3w_online_daily VALUES('488','2016-11-03','369');
INSERT INTO olala3w_online_daily VALUES('489','2016-11-04','320');
INSERT INTO olala3w_online_daily VALUES('490','2016-11-05','202');
INSERT INTO olala3w_online_daily VALUES('491','2016-11-06','216');
INSERT INTO olala3w_online_daily VALUES('492','2016-11-07','243');
INSERT INTO olala3w_online_daily VALUES('493','2016-11-08','228');
INSERT INTO olala3w_online_daily VALUES('494','2016-11-09','200');
INSERT INTO olala3w_online_daily VALUES('495','2016-11-10','335');
INSERT INTO olala3w_online_daily VALUES('496','2016-11-11','189');
INSERT INTO olala3w_online_daily VALUES('497','2016-11-12','199');
INSERT INTO olala3w_online_daily VALUES('498','2016-11-13','476');
INSERT INTO olala3w_online_daily VALUES('499','2016-11-14','748');
INSERT INTO olala3w_online_daily VALUES('500','2016-11-15','384');
INSERT INTO olala3w_online_daily VALUES('501','2016-11-16','535');
INSERT INTO olala3w_online_daily VALUES('502','2016-11-17','669');
INSERT INTO olala3w_online_daily VALUES('503','2016-11-18','714');
INSERT INTO olala3w_online_daily VALUES('504','2016-11-19','778');
INSERT INTO olala3w_online_daily VALUES('505','2016-11-20','472');
INSERT INTO olala3w_online_daily VALUES('506','2016-11-21','339');
INSERT INTO olala3w_online_daily VALUES('507','2016-11-22','489');
INSERT INTO olala3w_online_daily VALUES('508','2016-11-23','283');
INSERT INTO olala3w_online_daily VALUES('509','2016-11-24','246');
INSERT INTO olala3w_online_daily VALUES('510','2016-11-25','276');
INSERT INTO olala3w_online_daily VALUES('511','2016-11-26','288');
INSERT INTO olala3w_online_daily VALUES('512','2016-11-27','268');
INSERT INTO olala3w_online_daily VALUES('513','2016-11-28','504');
INSERT INTO olala3w_online_daily VALUES('514','2016-11-29','478');
INSERT INTO olala3w_online_daily VALUES('515','2016-11-30','694');
INSERT INTO olala3w_online_daily VALUES('516','2016-12-01','524');
INSERT INTO olala3w_online_daily VALUES('517','2016-12-02','456');
INSERT INTO olala3w_online_daily VALUES('518','2016-12-03','450');
INSERT INTO olala3w_online_daily VALUES('519','2016-12-04','248');
INSERT INTO olala3w_online_daily VALUES('520','2016-12-05','99');
INSERT INTO olala3w_online_daily VALUES('521','2016-12-06','406');
INSERT INTO olala3w_online_daily VALUES('522','2016-12-07','508');
INSERT INTO olala3w_online_daily VALUES('523','2016-12-08','343');
INSERT INTO olala3w_online_daily VALUES('524','2016-12-09','452');
INSERT INTO olala3w_online_daily VALUES('525','2016-12-10','356');
INSERT INTO olala3w_online_daily VALUES('526','2016-12-11','415');
INSERT INTO olala3w_online_daily VALUES('527','2016-12-12','405');
INSERT INTO olala3w_online_daily VALUES('528','2016-12-13','260');
INSERT INTO olala3w_online_daily VALUES('529','2016-12-14','328');
INSERT INTO olala3w_online_daily VALUES('530','2016-12-15','697');
INSERT INTO olala3w_online_daily VALUES('531','2016-12-16','506');
INSERT INTO olala3w_online_daily VALUES('532','2016-12-17','388');
INSERT INTO olala3w_online_daily VALUES('533','2016-12-18','289');
INSERT INTO olala3w_online_daily VALUES('534','2016-12-19','312');
INSERT INTO olala3w_online_daily VALUES('535','2016-12-20','345');
INSERT INTO olala3w_online_daily VALUES('536','2016-12-21','349');
INSERT INTO olala3w_online_daily VALUES('537','2016-12-22','228');
INSERT INTO olala3w_online_daily VALUES('538','2016-12-23','374');
INSERT INTO olala3w_online_daily VALUES('539','2016-12-24','270');
INSERT INTO olala3w_online_daily VALUES('540','2016-12-25','201');
INSERT INTO olala3w_online_daily VALUES('541','2016-12-26','163');
INSERT INTO olala3w_online_daily VALUES('542','2016-12-27','178');
INSERT INTO olala3w_online_daily VALUES('543','2016-12-28','204');
INSERT INTO olala3w_online_daily VALUES('544','2016-12-29','244');
INSERT INTO olala3w_online_daily VALUES('545','2016-12-30','291');
INSERT INTO olala3w_online_daily VALUES('546','2016-12-31','535');
INSERT INTO olala3w_online_daily VALUES('547','2017-01-01','432');
INSERT INTO olala3w_online_daily VALUES('548','2017-01-02','383');
INSERT INTO olala3w_online_daily VALUES('549','2017-01-03','456');
INSERT INTO olala3w_online_daily VALUES('550','2017-01-04','324');
INSERT INTO olala3w_online_daily VALUES('551','2017-01-05','269');
INSERT INTO olala3w_online_daily VALUES('552','2017-01-06','117');
INSERT INTO olala3w_online_daily VALUES('553','2017-01-07','211');
INSERT INTO olala3w_online_daily VALUES('554','2017-01-08','282');
INSERT INTO olala3w_online_daily VALUES('555','2017-01-09','259');
INSERT INTO olala3w_online_daily VALUES('556','2017-01-10','270');
INSERT INTO olala3w_online_daily VALUES('557','2017-01-11','287');
INSERT INTO olala3w_online_daily VALUES('558','2017-01-12','287');
INSERT INTO olala3w_online_daily VALUES('559','2017-01-13','310');
INSERT INTO olala3w_online_daily VALUES('560','2017-01-14','96');
INSERT INTO olala3w_online_daily VALUES('561','2017-01-15','138');
INSERT INTO olala3w_online_daily VALUES('562','2017-01-16','173');
INSERT INTO olala3w_online_daily VALUES('563','2017-01-17','120');
INSERT INTO olala3w_online_daily VALUES('564','2017-01-18','206');
INSERT INTO olala3w_online_daily VALUES('565','2017-01-19','179');
INSERT INTO olala3w_online_daily VALUES('566','2017-01-20','136');
INSERT INTO olala3w_online_daily VALUES('567','2017-01-21','152');
INSERT INTO olala3w_online_daily VALUES('568','2017-01-22','257');
INSERT INTO olala3w_online_daily VALUES('569','2017-01-23','206');
INSERT INTO olala3w_online_daily VALUES('570','2017-01-24','226');
INSERT INTO olala3w_online_daily VALUES('571','2017-01-25','291');
INSERT INTO olala3w_online_daily VALUES('572','2017-01-26','154');
INSERT INTO olala3w_online_daily VALUES('573','2017-01-27','64');
INSERT INTO olala3w_online_daily VALUES('574','2017-01-28','118');
INSERT INTO olala3w_online_daily VALUES('575','2017-01-29','61');
INSERT INTO olala3w_online_daily VALUES('576','2017-01-30','89');
INSERT INTO olala3w_online_daily VALUES('577','2017-01-31','121');
INSERT INTO olala3w_online_daily VALUES('578','2017-02-01','98');
INSERT INTO olala3w_online_daily VALUES('579','2017-02-02','229');
INSERT INTO olala3w_online_daily VALUES('580','2017-02-03','310');
INSERT INTO olala3w_online_daily VALUES('581','2017-02-04','219');
INSERT INTO olala3w_online_daily VALUES('582','2017-02-05','254');
INSERT INTO olala3w_online_daily VALUES('583','2017-02-06','348');
INSERT INTO olala3w_online_daily VALUES('584','2017-02-07','279');
INSERT INTO olala3w_online_daily VALUES('585','2017-02-08','249');
INSERT INTO olala3w_online_daily VALUES('586','2017-02-09','215');
INSERT INTO olala3w_online_daily VALUES('587','2017-02-10','155');
INSERT INTO olala3w_online_daily VALUES('588','2017-02-11','140');
INSERT INTO olala3w_online_daily VALUES('589','2017-02-12','120');
INSERT INTO olala3w_online_daily VALUES('590','2017-02-13','154');
INSERT INTO olala3w_online_daily VALUES('591','2017-02-14','327');
INSERT INTO olala3w_online_daily VALUES('592','2017-02-15','314');
INSERT INTO olala3w_online_daily VALUES('593','2017-02-16','292');
INSERT INTO olala3w_online_daily VALUES('594','2017-02-17','183');
INSERT INTO olala3w_online_daily VALUES('595','2017-02-18','276');
INSERT INTO olala3w_online_daily VALUES('596','2017-02-19','211');
INSERT INTO olala3w_online_daily VALUES('597','2017-02-20','247');
INSERT INTO olala3w_online_daily VALUES('598','2017-02-21','141');
INSERT INTO olala3w_online_daily VALUES('599','2017-02-22','138');
INSERT INTO olala3w_online_daily VALUES('600','2017-02-23','166');
INSERT INTO olala3w_online_daily VALUES('601','2017-02-24','100');
INSERT INTO olala3w_online_daily VALUES('602','2017-02-25','175');
INSERT INTO olala3w_online_daily VALUES('603','2017-02-26','163');
INSERT INTO olala3w_online_daily VALUES('604','2017-02-27','6');
INSERT INTO olala3w_online_daily VALUES('605','2017-02-28','1');
INSERT INTO olala3w_online_daily VALUES('606','2017-03-01','3');
INSERT INTO olala3w_online_daily VALUES('607','2017-03-05','6');
INSERT INTO olala3w_online_daily VALUES('608','2017-03-06','1');
INSERT INTO olala3w_online_daily VALUES('609','2017-03-07','4');
INSERT INTO olala3w_online_daily VALUES('610','2017-03-08','97');
INSERT INTO olala3w_online_daily VALUES('611','2017-03-09','6');
INSERT INTO olala3w_online_daily VALUES('612','2017-03-10','1');
INSERT INTO olala3w_online_daily VALUES('613','2017-03-11','1');
INSERT INTO olala3w_online_daily VALUES('614','2017-03-11','1');
INSERT INTO olala3w_online_daily VALUES('615','2017-03-13','2');
INSERT INTO olala3w_online_daily VALUES('616','2017-03-14','2');
INSERT INTO olala3w_online_daily VALUES('617','2017-03-15','3');
INSERT INTO olala3w_online_daily VALUES('618','2017-03-20','3');
INSERT INTO olala3w_online_daily VALUES('619','2017-03-21','2');
INSERT INTO olala3w_online_daily VALUES('620','2017-04-16','1');
INSERT INTO olala3w_online_daily VALUES('621','2017-04-17','5');
INSERT INTO olala3w_online_daily VALUES('622','2017-04-21','3');
INSERT INTO olala3w_online_daily VALUES('623','2017-04-22','1');
INSERT INTO olala3w_online_daily VALUES('624','2017-04-26','1');
INSERT INTO olala3w_online_daily VALUES('625','2017-04-28','6');
INSERT INTO olala3w_online_daily VALUES('626','2017-04-29','3');
INSERT INTO olala3w_online_daily VALUES('627','2017-05-03','4');
INSERT INTO olala3w_online_daily VALUES('628','2017-05-04','2');
INSERT INTO olala3w_online_daily VALUES('629','2017-05-05','7');
INSERT INTO olala3w_online_daily VALUES('630','2017-05-07','9');
INSERT INTO olala3w_online_daily VALUES('631','2017-05-08','1');
INSERT INTO olala3w_online_daily VALUES('632','2017-05-09','6');
INSERT INTO olala3w_online_daily VALUES('633','2017-05-10','6');
INSERT INTO olala3w_online_daily VALUES('634','2017-05-12','1');
INSERT INTO olala3w_online_daily VALUES('635','2017-05-16','2');
INSERT INTO olala3w_online_daily VALUES('636','2017-05-17','11');
INSERT INTO olala3w_online_daily VALUES('637','2017-05-18','30');
INSERT INTO olala3w_online_daily VALUES('638','2017-05-19','10');
INSERT INTO olala3w_online_daily VALUES('639','2017-05-20','8');
INSERT INTO olala3w_online_daily VALUES('640','2017-05-21','20');
INSERT INTO olala3w_online_daily VALUES('641','2017-05-22','3');
INSERT INTO olala3w_online_daily VALUES('642','2017-05-23','3');
INSERT INTO olala3w_online_daily VALUES('0','2017-05-27','3');
INSERT INTO olala3w_online_daily VALUES('643','2017-05-28','2');
INSERT INTO olala3w_online_daily VALUES('644','2017-05-29','6');
INSERT INTO olala3w_online_daily VALUES('645','2017-05-30','2');
INSERT INTO olala3w_online_daily VALUES('646','2017-06-02','3');
INSERT INTO olala3w_online_daily VALUES('647','2017-06-03','4');
INSERT INTO olala3w_online_daily VALUES('648','2017-06-05','1');
INSERT INTO olala3w_online_daily VALUES('649','2017-06-06','3');
INSERT INTO olala3w_online_daily VALUES('650','2017-06-07','26');
INSERT INTO olala3w_online_daily VALUES('651','2017-06-08','20');
INSERT INTO olala3w_online_daily VALUES('652','2017-06-09','31');
INSERT INTO olala3w_online_daily VALUES('653','2017-06-10','9');
INSERT INTO olala3w_online_daily VALUES('654','2017-06-11','2');
INSERT INTO olala3w_online_daily VALUES('655','2017-06-12','14');
INSERT INTO olala3w_online_daily VALUES('656','2017-06-13','9');
INSERT INTO olala3w_online_daily VALUES('657','2017-06-14','13');
INSERT INTO olala3w_online_daily VALUES('658','2017-06-15','13');
INSERT INTO olala3w_online_daily VALUES('659','2017-06-16','28');
INSERT INTO olala3w_online_daily VALUES('660','2017-06-17','7');
INSERT INTO olala3w_online_daily VALUES('661','2017-06-19','16');
INSERT INTO olala3w_online_daily VALUES('662','2017-06-20','20');
INSERT INTO olala3w_online_daily VALUES('663','2017-06-21','12');
INSERT INTO olala3w_online_daily VALUES('664','2017-06-22','5');
INSERT INTO olala3w_online_daily VALUES('665','2017-06-29','1');
INSERT INTO olala3w_online_daily VALUES('666','2017-07-06','1');
INSERT INTO olala3w_online_daily VALUES('667','2017-07-17','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `ip` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'fa-shopping-cart',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_others` (
  `others_id` int(11) NOT NULL AUTO_INCREMENT,
  `others_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `p_from` bigint(20) NOT NULL DEFAULT '0',
  `p_to` bigint(20) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`others_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_others_menu` (
  `others_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`others_menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_page` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `content` longtext NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_page VALUES('27','copyright','Copyright','','<p>Copyright © 2017 Member of V.Startup. All right reserved.</p>\r\n','1','1','1496815665','1');
INSERT INTO olala3w_page VALUES('100','contact_maps','Bản đồ trang liên hệ','','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.713723661704!2d108.21956131441821!3d16.080338688874107!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3142183b8dc2697d%3A0xc105565d68b6ad90!2zMTYgTMO9IFRoxrDhu51uZyBLaeG7h3QsIEjhuqNpIENow6J1LCDEkMOgIE7hurVuZywgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1496907656248\" width=\"100%\" height=\"250\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>','1','1','1496907710','1');
INSERT INTO olala3w_page VALUES('101','contact_page','Thông tin liên hệ','','<p><span style=\"color:#2fb6cc;\"><strong>CÔNG TY CỔ PHẦN ĐẦU TƯ TỔNG HỢP KHỞI NGHIỆP VIỆT</strong></span><br />\r\nĐịa chỉ : 16 Lý Thường Kiệt, phường Thạch Thang, quận Hải Châu, Tp Đà Nẵng, Việt Nam<br />\r\nĐiện thoại : (+84) 236 3888 626<br />\r\nFax :<br />\r\nEmail : info@vstartup.com.vn<br />\r\nWebsite : vstartup.com.vn</p>\r\n','1','1','1496907788','1');
INSERT INTO olala3w_page VALUES('104','info_bottom','V Startup','','<h4>Công ty CP Đầu tư Tổng hợp Khởi nghiệp Việt - V.Startup</h4>\r\n\r\n<p>Địa chỉ: 16 Lý Thường Kiệt, Phường Thạch Thang, Quận Hải Châu,&nbsp;Tp Đà Nẵng, Việt Nam<br />\r\nĐiện thoại: (+84) 236 3888 626<br />\r\nEmail: info@vstartup.com.vn</p>\r\n','1','1','1496908123','1');

-- --------------------------------------------------------

CREATE TABLE `olala3w_prjname` (
  `prjname_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`prjname_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_menu_id` int(11) NOT NULL,
  `owner` int(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `upload_id` bigint(20) NOT NULL DEFAULT '0',
  `acreage` double NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `price_unit` varchar(255) NOT NULL,
  `direction` varchar(255) NOT NULL,
  `direction_2` varchar(255) NOT NULL,
  `road` varchar(255) NOT NULL,
  `road_2` varchar(255) NOT NULL,
  `bedroom` int(11) NOT NULL DEFAULT '0',
  `bathroom` int(11) NOT NULL DEFAULT '0',
  `city` varchar(255) NOT NULL,
  `city_2` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `district_2` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `type_2` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `content` text NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `pin` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=638 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_product_menu` (
  `product_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `plus` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=253 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `content` longtext NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_project_menu` (
  `project_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `comment` text NOT NULL,
  `project_type` int(11) NOT NULL DEFAULT '0',
  `price_max` bigint(20) NOT NULL DEFAULT '0',
  `price_min` bigint(20) NOT NULL DEFAULT '0',
  `legal` int(1) NOT NULL DEFAULT '0',
  `location` int(11) NOT NULL DEFAULT '0',
  `geo_radius` int(11) NOT NULL DEFAULT '0',
  `project_use` varchar(255) NOT NULL,
  `project_hot` varchar(255) NOT NULL,
  `project_involve` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`project_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=217 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_register_email` (
  `register_email_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`register_email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_register_try` (
  `register_try_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL DEFAULT 'no-name',
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`register_try_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_road` (
  `road_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`road_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_street` (
  `street_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`street_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_tour` (
  `tour_id` int(11) NOT NULL AUTO_INCREMENT,
  `tour_menu_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `img_note` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `tour_keys` varchar(255) NOT NULL,
  `price` bigint(15) NOT NULL DEFAULT '0',
  `date_schedule` varchar(255) NOT NULL,
  `date_departure` int(11) NOT NULL DEFAULT '0',
  `means` varchar(255) NOT NULL,
  `tour_type` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `sale` int(3) NOT NULL DEFAULT '0',
  `schedule` text NOT NULL,
  `price_list_service` text NOT NULL,
  `upload_id` bigint(20) NOT NULL,
  `maps` text NOT NULL,
  `video` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `pin` int(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tour_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_tour_menu` (
  `tour_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '1',
  `is_active` int(1) NOT NULL DEFAULT '1',
  `hot` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT 'no',
  `created_time` int(11) NOT NULL DEFAULT '0',
  `modified_time` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tour_menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE `olala3w_uploads_tmp` (
  `upload_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` int(1) NOT NULL DEFAULT '0',
  `list_img` text NOT NULL,
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`upload_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1932 DEFAULT CHARSET=utf8;

INSERT INTO olala3w_uploads_tmp VALUES('1606','0','','1494148567');
INSERT INTO olala3w_uploads_tmp VALUES('1607','0','','1494148608');
INSERT INTO olala3w_uploads_tmp VALUES('1608','0','','1494148724');
INSERT INTO olala3w_uploads_tmp VALUES('1628','0','','1494522106');
INSERT INTO olala3w_uploads_tmp VALUES('1619','1','','1494180762');
INSERT INTO olala3w_uploads_tmp VALUES('1622','0','','1494183294');
INSERT INTO olala3w_uploads_tmp VALUES('1616','0','','1494180652');
INSERT INTO olala3w_uploads_tmp VALUES('1627','0','','1494217625');
INSERT INTO olala3w_uploads_tmp VALUES('1629','0','','1494953260');
INSERT INTO olala3w_uploads_tmp VALUES('1630','0','','1494955327');
INSERT INTO olala3w_uploads_tmp VALUES('1631','0','','1494956909');
INSERT INTO olala3w_uploads_tmp VALUES('1632','0','','1494956952');
INSERT INTO olala3w_uploads_tmp VALUES('1633','0','','1494957143');
INSERT INTO olala3w_uploads_tmp VALUES('1634','0','','1494957148');
INSERT INTO olala3w_uploads_tmp VALUES('1635','0','','1494957283');
INSERT INTO olala3w_uploads_tmp VALUES('1636','0','','1494957291');
INSERT INTO olala3w_uploads_tmp VALUES('1637','0','','1494957477');
INSERT INTO olala3w_uploads_tmp VALUES('1638','0','','1494957571');
INSERT INTO olala3w_uploads_tmp VALUES('1639','0','','1494957620');
INSERT INTO olala3w_uploads_tmp VALUES('1640','0','','1494957740');
INSERT INTO olala3w_uploads_tmp VALUES('1641','0','','1494957784');
INSERT INTO olala3w_uploads_tmp VALUES('1642','0','','1494957897');
INSERT INTO olala3w_uploads_tmp VALUES('1643','0','','1494957911');
INSERT INTO olala3w_uploads_tmp VALUES('1644','0','','1494957928');
INSERT INTO olala3w_uploads_tmp VALUES('1645','0','','1494957938');
INSERT INTO olala3w_uploads_tmp VALUES('1646','0','','1494957963');
INSERT INTO olala3w_uploads_tmp VALUES('1647','0','','1494958319');
INSERT INTO olala3w_uploads_tmp VALUES('1648','0','','1494958338');
INSERT INTO olala3w_uploads_tmp VALUES('1649','0','','1494958380');
INSERT INTO olala3w_uploads_tmp VALUES('1650','0','','1494964431');
INSERT INTO olala3w_uploads_tmp VALUES('1651','0','','1494964594');
INSERT INTO olala3w_uploads_tmp VALUES('1652','0','','1494964628');
INSERT INTO olala3w_uploads_tmp VALUES('1653','0','','1494964706');
INSERT INTO olala3w_uploads_tmp VALUES('1654','0','','1494964720');
INSERT INTO olala3w_uploads_tmp VALUES('1655','0','','1494964728');
INSERT INTO olala3w_uploads_tmp VALUES('1656','0','','1494965079');
INSERT INTO olala3w_uploads_tmp VALUES('1657','0','','1494965086');
INSERT INTO olala3w_uploads_tmp VALUES('1658','0','','1494965100');
INSERT INTO olala3w_uploads_tmp VALUES('1659','0','','1494965108');
INSERT INTO olala3w_uploads_tmp VALUES('1660','0','','1494965195');
INSERT INTO olala3w_uploads_tmp VALUES('1661','0','','1494965197');
INSERT INTO olala3w_uploads_tmp VALUES('1662','0','','1494965321');
INSERT INTO olala3w_uploads_tmp VALUES('1663','0','','1494965622');
INSERT INTO olala3w_uploads_tmp VALUES('1664','0','','1494965634');
INSERT INTO olala3w_uploads_tmp VALUES('1665','0','','1494965702');
INSERT INTO olala3w_uploads_tmp VALUES('1666','0','','1494965808');
INSERT INTO olala3w_uploads_tmp VALUES('1667','0','','1494965898');
INSERT INTO olala3w_uploads_tmp VALUES('1668','0','','1494965988');
INSERT INTO olala3w_uploads_tmp VALUES('1669','0','','1495042897');
INSERT INTO olala3w_uploads_tmp VALUES('1670','0','','1495042931');
INSERT INTO olala3w_uploads_tmp VALUES('1671','0','','1495042992');
INSERT INTO olala3w_uploads_tmp VALUES('1672','0','','1495043043');
INSERT INTO olala3w_uploads_tmp VALUES('1673','0','','1495043080');
INSERT INTO olala3w_uploads_tmp VALUES('1674','0','','1495043121');
INSERT INTO olala3w_uploads_tmp VALUES('1675','0','','1495043181');
INSERT INTO olala3w_uploads_tmp VALUES('1676','0','','1495043969');
INSERT INTO olala3w_uploads_tmp VALUES('1677','0','','1495071652');
INSERT INTO olala3w_uploads_tmp VALUES('1678','0','','1495073071');
INSERT INTO olala3w_uploads_tmp VALUES('1679','0','','1495077827');
INSERT INTO olala3w_uploads_tmp VALUES('1680','0','','1495077935');
INSERT INTO olala3w_uploads_tmp VALUES('1681','0','','1495077944');
INSERT INTO olala3w_uploads_tmp VALUES('1682','0','','1495078243');
INSERT INTO olala3w_uploads_tmp VALUES('1683','0','','1495078255');
INSERT INTO olala3w_uploads_tmp VALUES('1684','0','','1495080039');
INSERT INTO olala3w_uploads_tmp VALUES('1685','0','','1495080041');
INSERT INTO olala3w_uploads_tmp VALUES('1686','0','','1495080128');
INSERT INTO olala3w_uploads_tmp VALUES('1687','0','','1495080264');
INSERT INTO olala3w_uploads_tmp VALUES('1688','0','','1495081141');
INSERT INTO olala3w_uploads_tmp VALUES('1689','0','','1495081156');
INSERT INTO olala3w_uploads_tmp VALUES('1690','0','','1495081196');
INSERT INTO olala3w_uploads_tmp VALUES('1691','0','','1495081212');
INSERT INTO olala3w_uploads_tmp VALUES('1692','0','','1495081253');
INSERT INTO olala3w_uploads_tmp VALUES('1693','0','','1495081273');
INSERT INTO olala3w_uploads_tmp VALUES('1694','0','','1495081338');
INSERT INTO olala3w_uploads_tmp VALUES('1695','0','','1495081368');
INSERT INTO olala3w_uploads_tmp VALUES('1696','0','','1495081388');
INSERT INTO olala3w_uploads_tmp VALUES('1697','0','','1495081414');
INSERT INTO olala3w_uploads_tmp VALUES('1698','0','','1495081426');
INSERT INTO olala3w_uploads_tmp VALUES('1699','0','','1495082018');
INSERT INTO olala3w_uploads_tmp VALUES('1700','0','','1495082099');
INSERT INTO olala3w_uploads_tmp VALUES('1701','0','','1495082263');
INSERT INTO olala3w_uploads_tmp VALUES('1702','0','','1495090079');
INSERT INTO olala3w_uploads_tmp VALUES('1703','0','','1495090087');
INSERT INTO olala3w_uploads_tmp VALUES('1704','0','','1495090095');
INSERT INTO olala3w_uploads_tmp VALUES('1705','0','','1495090509');
INSERT INTO olala3w_uploads_tmp VALUES('1706','0','','1495091563');
INSERT INTO olala3w_uploads_tmp VALUES('1707','0','','1495091622');
INSERT INTO olala3w_uploads_tmp VALUES('1708','0','','1495091681');
INSERT INTO olala3w_uploads_tmp VALUES('1709','0','','1495091842');
INSERT INTO olala3w_uploads_tmp VALUES('1710','0','','1495092033');
INSERT INTO olala3w_uploads_tmp VALUES('1711','0','','1495092064');
INSERT INTO olala3w_uploads_tmp VALUES('1712','0','','1495092066');
INSERT INTO olala3w_uploads_tmp VALUES('1713','0','','1495092142');
INSERT INTO olala3w_uploads_tmp VALUES('1714','0','','1495092189');
INSERT INTO olala3w_uploads_tmp VALUES('1715','0','','1495092205');
INSERT INTO olala3w_uploads_tmp VALUES('1716','0','','1495092208');
INSERT INTO olala3w_uploads_tmp VALUES('1717','0','','1495092245');
INSERT INTO olala3w_uploads_tmp VALUES('1718','0','','1495092309');
INSERT INTO olala3w_uploads_tmp VALUES('1719','0','','1495092339');
INSERT INTO olala3w_uploads_tmp VALUES('1720','0','','1495092354');
INSERT INTO olala3w_uploads_tmp VALUES('1721','0','','1495092390');
INSERT INTO olala3w_uploads_tmp VALUES('1722','0','','1495092406');
INSERT INTO olala3w_uploads_tmp VALUES('1723','0','','1495092453');
INSERT INTO olala3w_uploads_tmp VALUES('1724','0','','1495092462');
INSERT INTO olala3w_uploads_tmp VALUES('1725','0','','1495092683');
INSERT INTO olala3w_uploads_tmp VALUES('1726','0','','1495092730');
INSERT INTO olala3w_uploads_tmp VALUES('1727','0','','1495092796');
INSERT INTO olala3w_uploads_tmp VALUES('1728','0','','1495092880');
INSERT INTO olala3w_uploads_tmp VALUES('1729','0','','1495093352');
INSERT INTO olala3w_uploads_tmp VALUES('1730','0','','1495093880');
INSERT INTO olala3w_uploads_tmp VALUES('1731','0','','1495094500');
INSERT INTO olala3w_uploads_tmp VALUES('1732','0','','1495094582');
INSERT INTO olala3w_uploads_tmp VALUES('1733','0','','1495094601');
INSERT INTO olala3w_uploads_tmp VALUES('1734','0','','1495094603');
INSERT INTO olala3w_uploads_tmp VALUES('1735','0','','1495094640');
INSERT INTO olala3w_uploads_tmp VALUES('1736','0','','1495094707');
INSERT INTO olala3w_uploads_tmp VALUES('1737','0','','1495094808');
INSERT INTO olala3w_uploads_tmp VALUES('1738','0','','1495094867');
INSERT INTO olala3w_uploads_tmp VALUES('1739','0','','1495094913');
INSERT INTO olala3w_uploads_tmp VALUES('1740','0','','1495095142');
INSERT INTO olala3w_uploads_tmp VALUES('1741','0','','1495095336');
INSERT INTO olala3w_uploads_tmp VALUES('1742','0','','1495096192');
INSERT INTO olala3w_uploads_tmp VALUES('1743','0','','1495097070');
INSERT INTO olala3w_uploads_tmp VALUES('1744','0','','1495097239');
INSERT INTO olala3w_uploads_tmp VALUES('1745','0','','1495097275');
INSERT INTO olala3w_uploads_tmp VALUES('1746','0','','1495097289');
INSERT INTO olala3w_uploads_tmp VALUES('1747','0','','1495098068');
INSERT INTO olala3w_uploads_tmp VALUES('1748','0','','1495098188');
INSERT INTO olala3w_uploads_tmp VALUES('1749','0','','1495098424');
INSERT INTO olala3w_uploads_tmp VALUES('1750','0','','1495098682');
INSERT INTO olala3w_uploads_tmp VALUES('1751','0','','1495102772');
INSERT INTO olala3w_uploads_tmp VALUES('1752','0','','1495103096');
INSERT INTO olala3w_uploads_tmp VALUES('1753','0','','1495103191');
INSERT INTO olala3w_uploads_tmp VALUES('1754','0','','1495103200');
INSERT INTO olala3w_uploads_tmp VALUES('1755','0','','1495103240');
INSERT INTO olala3w_uploads_tmp VALUES('1756','0','','1495126834');
INSERT INTO olala3w_uploads_tmp VALUES('1757','0','','1495126842');
INSERT INTO olala3w_uploads_tmp VALUES('1758','0','','1495179895');
INSERT INTO olala3w_uploads_tmp VALUES('1759','0','','1495186231');
INSERT INTO olala3w_uploads_tmp VALUES('1760','0','','1495204220');
INSERT INTO olala3w_uploads_tmp VALUES('1761','0','','1495214441');
INSERT INTO olala3w_uploads_tmp VALUES('1762','0','','1495214502');
INSERT INTO olala3w_uploads_tmp VALUES('1763','0','','1495214510');
INSERT INTO olala3w_uploads_tmp VALUES('1764','0','','1495214557');
INSERT INTO olala3w_uploads_tmp VALUES('1765','0','','1495214574');
INSERT INTO olala3w_uploads_tmp VALUES('1766','0','','1495214615');
INSERT INTO olala3w_uploads_tmp VALUES('1767','0','','1495214627');
INSERT INTO olala3w_uploads_tmp VALUES('1777','0','','1495222079');
INSERT INTO olala3w_uploads_tmp VALUES('1769','0','','1495218917');
INSERT INTO olala3w_uploads_tmp VALUES('1770','0','','1495218918');
INSERT INTO olala3w_uploads_tmp VALUES('1771','0','','1495218930');
INSERT INTO olala3w_uploads_tmp VALUES('1772','0','','1495219014');
INSERT INTO olala3w_uploads_tmp VALUES('1780','0','','1495222936');
INSERT INTO olala3w_uploads_tmp VALUES('1781','0','','1495225687');
INSERT INTO olala3w_uploads_tmp VALUES('1782','0','','1495225695');
INSERT INTO olala3w_uploads_tmp VALUES('1783','0','','1495225709');
INSERT INTO olala3w_uploads_tmp VALUES('1784','0','','1495225783');
INSERT INTO olala3w_uploads_tmp VALUES('1785','0','','1495225788');
INSERT INTO olala3w_uploads_tmp VALUES('1786','0','','1495225795');
INSERT INTO olala3w_uploads_tmp VALUES('1787','0','','1495225921');
INSERT INTO olala3w_uploads_tmp VALUES('1788','0','','1495225980');
INSERT INTO olala3w_uploads_tmp VALUES('1790','0','','1495226209');
INSERT INTO olala3w_uploads_tmp VALUES('1791','0','','1495226270');
INSERT INTO olala3w_uploads_tmp VALUES('1792','0','','1495226279');
INSERT INTO olala3w_uploads_tmp VALUES('1919','1','','1497932534');
INSERT INTO olala3w_uploads_tmp VALUES('1870','1','','1496803875');
INSERT INTO olala3w_uploads_tmp VALUES('1920','1','','1497932553');
INSERT INTO olala3w_uploads_tmp VALUES('1868','0','','1496801685');
INSERT INTO olala3w_uploads_tmp VALUES('1867','1','','1496795533');
INSERT INTO olala3w_uploads_tmp VALUES('1866','1','','1496795502');
INSERT INTO olala3w_uploads_tmp VALUES('1865','1','','1496795446');
INSERT INTO olala3w_uploads_tmp VALUES('1819','0','','1496087689');
INSERT INTO olala3w_uploads_tmp VALUES('1874','1','','1496816461');
INSERT INTO olala3w_uploads_tmp VALUES('1833','0','','1496444532');
INSERT INTO olala3w_uploads_tmp VALUES('1922','1','','1497932588');
INSERT INTO olala3w_uploads_tmp VALUES('1872','1','','1496816089');
INSERT INTO olala3w_uploads_tmp VALUES('1847','0','','1496445380');
INSERT INTO olala3w_uploads_tmp VALUES('1798','0','1495358188_1798_668c88252cb9e162b36d6713cb174c0d.jpg;1495358191_1798_a0d5434b0d5b08def83572649240c0d0.jpg;1495358193_1798_38a1905ecf631d468fddb233ee51b363.jpg;1495358196_1798_76764969447e3dbec7c38db97a6ad7ac.jpg;1495358198_1798_41556e4e12791ab26815bba9270fb00e.jpg;1495358201_1798_a9b7093b799d6d1af3f0f36140a99b00.jpg;1495358312_1798_4a1f7b9a6eaa938287d515789d6ce165.jpg;1495358597_1798_877678f580798b55d2ba436ed981e43f.jpg;1495358713_1798_98a69e0f2b0f255debde85fec5527457.jpg;1495359221_1798_30b32757c538d89ad60fc821bffaf712.jpg;','1495357896');
INSERT INTO olala3w_uploads_tmp VALUES('1799','0','','1495378192');
INSERT INTO olala3w_uploads_tmp VALUES('1862','0','','1496719005');
INSERT INTO olala3w_uploads_tmp VALUES('1863','0','','1496761820');
INSERT INTO olala3w_uploads_tmp VALUES('1864','0','','1496761832');
INSERT INTO olala3w_uploads_tmp VALUES('1801','0','','1495380859');
INSERT INTO olala3w_uploads_tmp VALUES('1805','0','','1495383166');
INSERT INTO olala3w_uploads_tmp VALUES('1803','0','','1495381092');
INSERT INTO olala3w_uploads_tmp VALUES('1804','0','','1495381176');
INSERT INTO olala3w_uploads_tmp VALUES('1806','0','','1495383327');
INSERT INTO olala3w_uploads_tmp VALUES('1807','0','','1495438809');
INSERT INTO olala3w_uploads_tmp VALUES('1808','0','','1495564220');
INSERT INTO olala3w_uploads_tmp VALUES('1875','1','','1496821346');
INSERT INTO olala3w_uploads_tmp VALUES('1876','1','','1496821662');
INSERT INTO olala3w_uploads_tmp VALUES('1877','1','','1496822074');
INSERT INTO olala3w_uploads_tmp VALUES('1878','1','','1496822263');
INSERT INTO olala3w_uploads_tmp VALUES('1879','1','','1496822705');
INSERT INTO olala3w_uploads_tmp VALUES('1880','1','','1496822846');
INSERT INTO olala3w_uploads_tmp VALUES('1881','1','','1496823870');
INSERT INTO olala3w_uploads_tmp VALUES('1882','1','','1496823960');
INSERT INTO olala3w_uploads_tmp VALUES('1883','1','','1496824000');
INSERT INTO olala3w_uploads_tmp VALUES('1884','1','','1496824029');
INSERT INTO olala3w_uploads_tmp VALUES('1885','1','','1496824105');
INSERT INTO olala3w_uploads_tmp VALUES('1886','1','','1496909749');
INSERT INTO olala3w_uploads_tmp VALUES('1887','0','','1496910000');
INSERT INTO olala3w_uploads_tmp VALUES('1888','1','','1496910004');
INSERT INTO olala3w_uploads_tmp VALUES('1889','1','','1496910191');
INSERT INTO olala3w_uploads_tmp VALUES('1890','0','','1496910577');
INSERT INTO olala3w_uploads_tmp VALUES('1891','1','','1496910920');
INSERT INTO olala3w_uploads_tmp VALUES('1892','1','','1496911083');
INSERT INTO olala3w_uploads_tmp VALUES('1893','1','','1496912531');
INSERT INTO olala3w_uploads_tmp VALUES('1921','1','','1497932574');
INSERT INTO olala3w_uploads_tmp VALUES('1899','1','','1496913481');
INSERT INTO olala3w_uploads_tmp VALUES('1918','1','','1497932516');
INSERT INTO olala3w_uploads_tmp VALUES('1917','1','','1497932492');
INSERT INTO olala3w_uploads_tmp VALUES('1905','1','','1496992237');
INSERT INTO olala3w_uploads_tmp VALUES('1906','1','','1496992996');
INSERT INTO olala3w_uploads_tmp VALUES('1907','0','','1496996083');
INSERT INTO olala3w_uploads_tmp VALUES('1909','0','','1497932115');
INSERT INTO olala3w_uploads_tmp VALUES('1910','1','','1497932136');
INSERT INTO olala3w_uploads_tmp VALUES('1911','1','','1497932163');
INSERT INTO olala3w_uploads_tmp VALUES('1912','1','','1497932255');
INSERT INTO olala3w_uploads_tmp VALUES('1913','1','','1497932298');
INSERT INTO olala3w_uploads_tmp VALUES('1914','1','','1497932333');
INSERT INTO olala3w_uploads_tmp VALUES('1915','1','','1497932393');
INSERT INTO olala3w_uploads_tmp VALUES('1916','1','','1497932411');
INSERT INTO olala3w_uploads_tmp VALUES('1923','1','','1497932601');
INSERT INTO olala3w_uploads_tmp VALUES('1924','0','1498034045_1924_814e5ce177d0689575376f0e7dbbeb77.jpg;','1498033944');
INSERT INTO olala3w_uploads_tmp VALUES('1925','0','','1498033977');
INSERT INTO olala3w_uploads_tmp VALUES('1926','0','','1498033979');
INSERT INTO olala3w_uploads_tmp VALUES('1927','0','','1498033980');
INSERT INTO olala3w_uploads_tmp VALUES('1928','0','','1498033980');
INSERT INTO olala3w_uploads_tmp VALUES('1929','0','','1498033980');
INSERT INTO olala3w_uploads_tmp VALUES('1930','0','','1498033981');
INSERT INTO olala3w_uploads_tmp VALUES('1931','0','','1498033984');

-- --------------------------------------------------------

CREATE TABLE `olala3w_vote` (
  `vote_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `session` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `vote` int(1) NOT NULL DEFAULT '0',
  `created_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vote_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

